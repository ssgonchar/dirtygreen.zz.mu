-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 26.11.2012 18:42:28
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list_for_report_audit$$
CREATE PROCEDURE sp_steelitem_get_list_for_report_audit(param_stock_date TIMESTAMP)
BEGIN

    DECLARE ITEM_STATUS_UNDEFINED   TINYINT DEFAULT 0;
    DECLARE ITEM_STATUS_PRODUCTION  TINYINT DEFAULT 1;
    DECLARE ITEM_STATUS_TRANSFER    TINYINT DEFAULT 2;
    DECLARE ITEM_STATUS_STOCK       TINYINT DEFAULT 3;
    DECLARE ITEM_STATUS_ORDERED     TINYINT DEFAULT 4;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 5;


    SELECT
        
        id AS steelitem_id,

        YEAR(NOW()) - YEAR(in_ddt_date) AS in_ddt_date_diff,

        CASE WHEN status_id IN (ITEM_STATUS_ORDERED, ITEM_STATUS_RELEASED)
        THEN IFNULL((SELECT price FROM order_positions WHERE order_id = steelitems.order_id AND position_id = steelitems.steelposition_id), price)
        ELSE price
        END AS real_price,

        IFNULL((SELECT invoice_id FROM invoice_items WHERE steelitem_id = steelitems.id), 0) AS invoice_id

    FROM steelitems
    WHERE is_virtual = 0
    AND is_deleted = 0
    AND in_ddt_date < param_stock_date
    AND status_id IN (ITEM_STATUS_UNDEFINED, ITEM_STATUS_PRODUCTION, ITEM_STATUS_TRANSFER, ITEM_STATUS_STOCK, ITEM_STATUS_ORDERED, ITEM_STATUS_RELEASED);

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list_for_report_current$$
CREATE PROCEDURE sp_steelitem_get_list_for_report_current()
BEGIN

    SELECT
        id AS steelitem_id
    FROM steelitems
    WHERE is_available = 1
    AND is_virtual = 0
    AND is_deleted = 0
    AND order_id = 0;

END
$$

DELIMITER ;
