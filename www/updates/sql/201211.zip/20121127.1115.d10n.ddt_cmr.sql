delimiter $$

DROP PROCEDURE IF EXISTS `sp_cmr_get_items`$$
CREATE PROCEDURE `sp_cmr_get_items`(IN param_cmr_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM cmr
	WHERE id = param_cmr_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		AND si.owner_id = var_owner_id
	;

END$$


DROP PROCEDURE IF EXISTS `sp_cmr_save`$$
CREATE PROCEDURE `sp_cmr_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_attachment_id INT,
	IN param_product_name VARCHAR(50)
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO cmr
		SET
			#`number`		= IFNULL((SELECT MAX(cmr2.`number`)+1 FROM cmr AS cmr2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_num,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM cmr WHERE created_by = param_user_id);
	ELSE
		IF param_num <= 0
		THEN
			SELECT owner_id, date_year
			INTO var_owner_id, var_date_year
			FROM cmr
			WHERE id = param_id;

			SET param_num = IFNULL((SELECT MAX(`number`) FROM cmr WHERE owner_id = var_owner_id AND date_year = var_date_year LIMIT 1), 0) + 1;
		END IF;

		UPDATE cmr
		SET
			ra_id			= param_ra_id,
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
    SELECT param_id AS cmr_id;

COMMIT;
END$$


DROP PROCEDURE IF EXISTS `sp_ddt_get_items`$$
CREATE PROCEDURE `sp_ddt_get_items`(IN param_ddt_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM ddt
	WHERE id = param_ddt_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		AND si.owner_id = var_owner_id
	;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_save`$$
CREATE PROCEDURE `sp_ddt_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_iva VARCHAR(20),
	IN param_paymenttype_id INT,
	IN param_causale_id INT,
	IN param_porto_id INT,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_attachment_id INT,
	IN param_dest_type_id TINYINT
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO ddt
		SET
			#`number`		= IFNULL((SELECT MAX(ddt2.`number`)+1 FROM ddt AS ddt2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_num,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by = param_user_id);
	ELSE
		IF param_num <= 0
		THEN
			SELECT owner_id, date_year
			INTO var_owner_id, var_date_year
			FROM ddt
			WHERE
				id = param_id
			;

			SET param_num = IFNULL((
					SELECT MAX(`number`)
					FROM ddt
					WHERE
							owner_id = var_owner_id
						AND date_year = var_date_year
					LIMIT 1
				), 0) + 1;
		END IF;

		UPDATE ddt
		SET
			ra_id			= param_ra_id,
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
	
    
    SELECT param_id AS ddt_id;

COMMIT;
END$$


delimiter ;
