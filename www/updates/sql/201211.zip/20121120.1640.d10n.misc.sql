ALTER TABLE `ddt` ADD COLUMN `is_deleted` TINYINT NOT NULL DEFAULT 0  AFTER `dest_type_id` ;

ALTER TABLE `cmr`
    ADD COLUMN `is_deleted` TINYINT NOT NULL DEFAULT 0 AFTER `attachment_id`,
    ADD COLUMN `product_name` VARCHAR(50) NULL  AFTER `is_deleted`;
    
    

DROP procedure IF EXISTS `sp_cmr_save`;

DELIMITER $$
CREATE PROCEDURE `sp_cmr_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_weighed_weight DECIMAL(10,4),
	IN param_attachment_id INT,
	IN param_product_name VARCHAR(50)
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO cmr
		SET
			#`number`		= IFNULL((SELECT MAX(cmr2.`number`)+1 FROM cmr AS cmr2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_num,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM cmr WHERE created_by = param_user_id);
	ELSE
		IF param_num <= 0
		THEN
			SELECT owner_id, date_year
			INTO var_owner_id, var_date_year
			FROM cmr
			WHERE id = param_id;

			SET param_num = IFNULL((SELECT MAX(`number`) FROM cmr WHERE owner_id = var_owner_id AND date_year = var_date_year LIMIT 1), 0) + 1;
		END IF;

		UPDATE cmr
		SET
			ra_id			= param_ra_id,
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
    SELECT param_id AS cmr_id;

COMMIT;
END$$

DELIMITER ;
