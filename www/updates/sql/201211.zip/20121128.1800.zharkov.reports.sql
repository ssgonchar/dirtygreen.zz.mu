-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 28.11.2012 18:00:00
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list_for_report_audit$$
CREATE PROCEDURE sp_steelitem_get_list_for_report_audit(param_stockholder_id INT, param_owner_id INT, param_stock_date TIMESTAMP)
BEGIN

    DECLARE ITEM_STATUS_UNDEFINED   TINYINT DEFAULT 0;
    DECLARE ITEM_STATUS_PRODUCTION  TINYINT DEFAULT 1;
    DECLARE ITEM_STATUS_TRANSFER    TINYINT DEFAULT 2;
    DECLARE ITEM_STATUS_STOCK       TINYINT DEFAULT 3;
    DECLARE ITEM_STATUS_ORDERED     TINYINT DEFAULT 4;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 5;


    SET @var_stmt = CONCAT("
        SELECT
            
            id AS steelitem_id,
    
            stockholder_id,
            owner_id,
    
            steelgrade_id,
            thickness,
            width,
            `length`,
            unitweight,
            DATEDIFF(NOW(), in_ddt_date) AS days_on_stock,
            YEAR(NOW()) - YEAR(in_ddt_date) AS years_on_stock,
            status_id,
    
            in_ddt_company_id,
            in_ddt_number,
            in_ddt_date,
    
            supplier_id,
            supplier_invoice_no,
            supplier_invoice_date,
    
            CASE WHEN status_id IN (", ITEM_STATUS_ORDERED, ",", ITEM_STATUS_RELEASED, ")
            THEN IFNULL((SELECT price FROM order_positions WHERE order_id = steelitems.order_id AND position_id = steelitems.steelposition_id), price)
            ELSE price
            END AS real_price,
    
            IFNULL((SELECT invoice_id FROM invoice_items WHERE steelitem_id = steelitems.id), 0) AS invoice_id
    
        FROM steelitems
        WHERE is_virtual = 0
        AND is_deleted = 0
        AND YEAR(in_ddt_date) not in (0)
        AND in_ddt_date < '", param_stock_date, "' 
        AND status_id IN (", ITEM_STATUS_UNDEFINED, ",", ITEM_STATUS_PRODUCTION, ",", ITEM_STATUS_TRANSFER, ",", ITEM_STATUS_STOCK, ",", ITEM_STATUS_ORDERED, ",", ITEM_STATUS_RELEASED, ") ", 
        IF(param_stockholder_id > 0, CONCAT(" AND stockholder_id = ", param_stockholder_id), ""), 
        IF(param_owner_id > 0, CONCAT(" AND owner_id = ", param_owner_id), ""),         
    ";");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DELIMITER ;
