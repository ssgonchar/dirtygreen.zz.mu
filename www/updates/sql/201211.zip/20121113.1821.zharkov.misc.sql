ALTER TABLE `steelitems` ADD INDEX `ix-order_id-status_id` ( `order_id` , `status_id` );
ALTER TABLE `invoices` ADD `due_date` TIMESTAMP NULL , ADD `status_id` TINYINT NULL , ADD `amount_received` DECIMAL( 10, 4 ) NULL;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_order_get_list$$
CREATE PROCEDURE sp_order_get_list(param_user_id INT, param_order_for CHAR(5), param_biz_id INT, param_company_id INT, 
                                   param_period_from TIMESTAMP, param_period_to TIMESTAMP, param_status CHAR(2), 
                                   param_steelgrade_id INT, param_thickness_from DECIMAL(10,4), 
                                   param_thickness_to DECIMAL(10,4), param_width_from DECIMAL(10,4), 
                                   param_width_to DECIMAL(10,4), param_keyword VARCHAR(100), param_type CHAR(2), 
                                   param_from INT, param_count INT)
sp:
BEGIN

    DECLARE var_where       VARCHAR(4000) DEFAULT '';
    DECLARE var_prefix      VARCHAR(100) DEFAULT '';
    DECLARE var_order_ids   VARCHAR(4000) DEFAULT '';
    

    IF param_steelgrade_id > 0 OR param_thickness_from > 0 OR param_thickness_to > 0 OR param_width_from > 0 OR param_width_to > 0
    THEN

        SET var_where = '';
        
        IF param_steelgrade_id > 0
        THEN 
            SET var_where = CONCAT(var_where, "steelgrade_id = ", param_steelgrade_id); 
        END IF;


        IF param_thickness_from > 0 OR param_thickness_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");
            
            IF param_thickness_from > 0 AND param_thickness_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(thickness_mm >= ", param_thickness_from, " AND thickness_mm <= ", param_thickness_to, ")"); 
            ELSEIF param_thickness_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm >= ", param_thickness_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm <= ", param_thickness_to); 
            END IF;
                    
        END IF;
        
        IF param_width_from > 0 OR param_width_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");

            IF param_width_from > 0 AND param_width_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(width_mm >= ", param_width_from, " AND width_mm <= ", param_width_to, ")"); 
            ELSEIF param_width_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "width_mm >= ", param_width_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "width_mm <= ", param_width_to); 
            END IF;
                    
        END IF;
    
    
        DROP TEMPORARY TABLE IF EXISTS t_orders;
        CREATE TEMPORARY TABLE t_orders(id INT);
        
        SET @var_stmt := CONCAT("   
            INSERT INTO t_orders(id)
            SELECT DISTINCT 
                order_id
            FROM order_positions 
        ", IF(var_where = "", "", " WHERE "), var_where);

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
        SET var_order_ids = IFNULL((SELECT GROUP_CONCAT(id SEPARATOR ",") FROM t_orders), '');

    END IF;

    
    SET var_where = '';
    
    
    IF TRIM(param_order_for) != ''
    THEN        
        SET var_where = CONCAT("o.order_for = '", param_order_for, "'");
    END IF;
    
    IF param_biz_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.biz_id = ", param_biz_id);
    END IF;

    IF param_company_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.company_id = ", param_company_id);
    END IF;

    IF TRIM(param_order_for) = '' AND param_biz_id = 0 AND param_company_id = 0 AND year(param_period_from) <= 1900
        AND year(param_period_to) <= 1900 AND TRIM(param_status) = '' AND param_steelgrade_id = 0 AND param_thickness_from = 0
        AND param_thickness_to = 0 AND param_width_from = 0 AND param_width_to = 0 AND TRIM(param_keyword) = '' AND TRIM(param_type) = ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status IN ('nw', 'ip', 'de')");
    ELSEIF TRIM(param_status) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status = '", param_status, "'");        
    END IF;

    IF TRIM(param_type) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.type = '", param_type, "'");
    END IF;

    IF year(param_period_from) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at >= ", param_period_from, "'");
    END IF;

    IF year(param_period_to) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at <= '", param_period_to, "'");

    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET param_keyword   = CONCAT('%', param_keyword, '%');
        SET var_prefix      = IF(var_where = "", "", " AND ");
        SET var_where       = CONCAT(var_where, var_prefix, "(o.buyer_ref LIKE '", param_keyword, "' OR o.supplier_ref LIKE '", param_keyword, "' OR o.description LIKE '", param_keyword, "')");
    END IF;
    
    SET @stmt_from  = param_from;
    SET @stmt_count = param_count;    
    SET @var_stmt   = CONCAT("
        SELECT
            o.id AS order_id
        FROM orders AS o ", 
        IF(TRIM(var_order_ids) = '', "", " JOIN t_orders USING (id)"), 
        IF(var_where = "", "", " WHERE "), var_where, 
        " ORDER BY id LIMIT ?, ?;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @stmt_from, @stmt_count;


    SET @var_stmt   = CONCAT("
        SELECT
            COUNT(*) AS rows
        FROM orders AS o ", 
        IF(TRIM(var_order_ids) = '', "", " JOIN t_orders USING (id)"), 
        IF(var_where = "", "", " WHERE "), var_where, 
        " ORDER BY id;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_quick_by_ids$$
CREATE PROCEDURE sp_order_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    DECLARE ITEM_STATUS_DELIVERED TINYINT DEFAULT 5;
    DECLARE ITEM_STATUS_INVOICED TINYINT DEFAULT 6;


    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM steelitems WHERE order_id = orders.id) AS qtty,
            (SELECT COUNT(*) FROM steelitems WHERE order_id = orders.id AND status_id IN (", ITEM_STATUS_DELIVERED, ",", ITEM_STATUS_INVOICED, ")) AS qtty_delivered,
            (SELECT SUM(unitweight) FROM steelitems WHERE order_id = orders.id) AS weight,
            IFNULL((SELECT SUM(unitweight) FROM steelitems WHERE order_id = orders.id AND status_id IN (", ITEM_STATUS_DELIVERED, ",", ITEM_STATUS_INVOICED, ")), 0) AS weight_delivered,
            (SELECT SUM(value) FROM order_positions WHERE order_id = orders.id) AS value,
            TIMESTAMPDIFF(DAY, CONCAT(YEAR(NOW()), '-', MONTH(NOW()), '-', DAY(NOW())), alert_date) AS days_to_alert
        FROM orders
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list$$
CREATE PROCEDURE sp_steelitem_get_list(param_user_id INT, param_stock_id INT, param_locations VARCHAR(100), param_deliverytimes VARCHAR(100), 
                                        param_is_real TINYINT, param_is_virtual TINYINT, param_is_twin TINYINT, param_is_cut TINYINT, 
                                        param_steelgrade_id INT, 
                                        param_thickness_from DECIMAL(10,4), param_thickness_to DECIMAL(10,4), 
                                        param_width_from DECIMAL(10,4), param_width_to DECIMAL(10,4), 
                                        param_length_from DECIMAL(10,4), param_length_to DECIMAL(10,4), 
                                        param_weight_from DECIMAL(10,4), param_weight_to DECIMAL(10,4), 
                                        param_keyword VARCHAR(50), param_plateid VARCHAR(32), param_available TINYINT, param_revision VARCHAR(12))
sp:
BEGIN
    
    DECLARE var_where       VARCHAR(4000) DEFAULT '';
    DECLARE var_type        VARCHAR(1000) DEFAULT '';
    DECLARE var_rev         VARCHAR(50) DEFAULT '';
    DECLARE var_order_ids   VARCHAR(1000) DEFAULT '';
    

    IF param_stock_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_get_list' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_rev     = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");
    SET var_where   = " WHERE si.is_deleted = 0 ";  

    
    IF TRIM(param_locations) = '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.stockholder_id IN (SELECT company_id FROM stock_locations", var_rev, " WHERE stock_id = ", param_stock_id, ")");     
    ELSE
        SET var_where = CONCAT(var_where, " AND si.stockholder_id IN (", param_locations, ")");     
    END IF;

    IF TRIM(param_deliverytimes) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.deliverytime_id IN (", param_deliverytimes, ")"); 
    END IF;

    IF param_steelgrade_id > 0 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.steelgrade_id = ", param_steelgrade_id); 
    END IF;

    IF param_is_real > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "si.is_virtual = 0"); 
    END IF;

    IF param_is_virtual > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.is_virtual = 1 AND si.parent_id = 0)"); 
    END IF;

    IF param_is_twin > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.parent_id > 0 AND rel = 't')"); 
    END IF;

    IF param_is_cut > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.parent_id > 0 AND rel = 'c')"); 
    END IF;

    IF TRIM(var_type) != ''
    THEN
        SET var_where = CONCAT(var_where, " AND (", var_type, ")"); 
    END IF;


    IF TRIM(param_plateid) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.guid LIKE '%", param_plateid, "%'"); 
    END IF;

    IF param_available > 0
    THEN
        SET var_where = CONCAT(var_where, " AND si.is_available = 1"); 
    ELSE
        SET var_order_ids   = IFNULL((SELECT GROUP_CONCAT(id SEPARATOR ",") FROM orders WHERE `status` = 'ip'), '0');
        SET var_where       = CONCAT(var_where, " AND si.is_available = 1 OR (si.order_id NOT IN (0) AND order_id IN (", var_order_ids, " ))"); 
    END IF;

    

    IF param_thickness_from > 0 OR param_thickness_to > 0
    THEN 
        
        IF param_thickness_from > 0 AND param_thickness_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.thickness_mm >= ", param_thickness_from, " AND si.thickness_mm <= ", param_thickness_to, ")"); 
        ELSEIF param_thickness_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.thickness_mm >= ", param_thickness_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.thickness_mm <= ", param_thickness_to); 
        END IF;
                
    END IF;
    
    IF param_width_from > 0 OR param_width_to > 0
    THEN 
        
        IF param_width_from > 0 AND param_width_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.width_mm >= ", param_width_from, " AND si.width_mm <= ", param_width_to, ")"); 
        ELSEIF param_width_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.width_mm >= ", param_width_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.width_mm <= ", param_width_to); 
        END IF;
                
    END IF;

    IF param_length_from > 0 OR param_length_to > 0
    THEN 
        
        IF param_length_from > 0 AND param_length_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.length_mm >= ", param_length_from, " AND si.length_mm <= ", param_length_to, ")"); 
        ELSEIF param_length_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.length_mm >= ", param_length_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.length_mm <= ", param_length_to); 
        END IF;
                
    END IF;

    IF param_weight_from > 0 OR param_weight_to > 0
    THEN 
        
        IF param_weight_from > 0 AND param_weight_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.unitweight_ton >= ", param_weight_from, " AND si.unitweight_ton <= ", param_weight_to, ")"); 
        ELSEIF param_weight_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.unitweight_ton >= ", param_weight_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.unitweight_ton <= ", param_weight_to); 
        END IF;
                
    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET var_where = CONCAT(var_where, " AND (si.notes LIKE '%", param_keyword, "%' OR si.internal_notes LIKE '%", param_keyword, "%')"); 
    END IF;

    
    DROP TEMPORARY TABLE IF EXISTS t_items;
    CREATE TEMPORARY TABLE t_items(id INT, steelgrade VARCHAR(50), thickness DECIMAL(10,4), width DECIMAL(10, 4), `length` DECIMAL(10,4));
        
    SET @var_stmt := CONCAT("   INSERT INTO t_items(id, steelgrade, thickness, width, `length`)
                                SELECT 
                                    si.id,
                                    (SELECT alias FROM steelgrades WHERE id = si.steelgrade_id),
                                    si.thickness_mm,
                                    si.width_mm,
                                    si.length_mm
                                FROM steelitems", var_rev, " AS si", var_where);

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

    SELECT 
        id AS steelitem_id 
    FROM t_items
    ORDER BY steelgrade, thickness, width, `length`;


    DROP TEMPORARY TABLE IF EXISTS t_items;


END
$$

DELIMITER ;
