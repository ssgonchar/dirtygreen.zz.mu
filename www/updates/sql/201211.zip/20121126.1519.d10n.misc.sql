drop table if exists `cmr_items`;
drop table if exists `ddt_items`;

#ALTER TABLE `cmr` DROP COLUMN `weighed_weight`;
#ALTER TABLE `ddt` DROP COLUMN `weighed_weight`;

#ALTER TABLE `ra_items` ADD COLUMN `weight` DECIMAL(10,4) NOT NULL DEFAULT 0  AFTER `steelitem_id`;
#ALTER TABLE `ra_items` ADD COLUMN `weighed_weight` DECIMAL(10,4) NOT NULL DEFAULT 0  AFTER `weight`;

#ALTER TABLE `steelitems_history` ADD COLUMN `in_ddt_company_id` INT NULL  AFTER `in_ddt_date`;
#ALTER TABLE `steelitems_history` ADD COLUMN `ddt_company_id` INT NULL  AFTER `ddt_date`;




delimiter $$

DROP procedure IF EXISTS `sp_cmr_get_items`$$
CREATE PROCEDURE `sp_cmr_get_items`(IN param_cmr_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM cmr
	WHERE id = param_ddt_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		AND si.owner_id = var_owner_id
	;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_get_items`$$
CREATE PROCEDURE `sp_ddt_get_items`(IN param_cmr_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM ddt
	WHERE id = param_ddt_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		AND si.owner_id = var_owner_id
	;

END$$


DROP PROCEDURE IF EXISTS `sp_ra_item_add`$$
CREATE PROCEDURE `sp_ra_item_add`(
	IN param_user_id INT,
	IN param_parent_id INT,
	IN param_ra_id INT,
	IN param_steelitem_id INT,
	IN param_status_id TINYINT
)
sp:
BEGIN
	DECLARE var_steelitem_owner_id INT DEFAULT 0;
	DECLARE var_ddt_id INT DEFAULT 0;
	DECLARE var_cmr_id INT DEFAULT 0;

	DECLARE var_ra_weighed_weight 				DECIMAL(10,4) DEFAULT 0;
	DECLARE var_ra_item_weighed_weight			DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_unitweight_ton		DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_sum_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

    START TRANSACTION;

	SET var_ra_weighed_weight 		= IFNULL((SELECT weighed_weight FROM ra WHERE id = param_ra_id), 0);
	SET var_steelitem_unitweight_ton= IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);

	IF var_ra_weighed_weight > 0
	THEN
		SET var_steelitem_sum_unitweight_ton= IFNULL((
			SELECT SUM(si.unitweight_ton)
			FROM ra_items AS ra_i
			JOIN steelitems AS si ON ra_i.steelitem_id = si.id
			WHERE ra_i.ra_id = param_ra_id
		), 0);
		SET var_ra_item_weighed_weight	= var_steelitem_unitweight_ton * ((var_ra_weighed_weight * 100 / var_steelitem_sum_unitweight_ton)) / 100;
	ELSE
		SET var_ra_item_weighed_weight = var_steelitem_unitweight_ton;
	END IF;


        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_steelitem_id, 
			weight    		= IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0),
			weighed_weight	= var_ra_item_weighed_weight,
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_steelitem_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_steelitem_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;
        
        END IF;
    
    COMMIT;

END$$


DROP PROCEDURE IF EXISTS `sp_ra_items_recalculate_ww`$$
CREATE PROCEDURE `sp_ra_items_recalculate_ww`(IN param_ra_id INT)
BEGIN
	UPDATE ra_items
	SET
		weighed_weight = sf_ra_item_recalculate_ww(id)
	WHERE
			ra_id		= param_ra_id
		AND parent_id	= 0
	;
END$$


DROP FUNCTION IF EXISTS `sf_ra_item_recalculate_ww`$$
CREATE FUNCTION `sf_ra_item_recalculate_ww`(param_ra_item_id INT) RETURNS decimal(10,4)
BEGIN
	DECLARE var_ra_id 					INT 			DEFAULT 0;
	DECLARE var_ra_weighed_weight		DECIMAL(10,4) 	DEFAULT 0;

	DECLARE var_ra_item_parent_id		INT 			DEFAULT 0;
	DECLARE var_ra_item_steelitem_id 	INT 			DEFAULT 0;
	DECLARE var_ra_item_weight			DECIMAL(10,4) 	DEFAULT 0;
	DECLARE var_ra_item_weighed_weight	DECIMAL(10,4) 	DEFAULT 0;
	DECLARE var_ra_items_weight_sum		DECIMAL(10,4) 	DEFAULT 0;

	DECLARE var_steelitem_owner_id	INT 		DEFAULT 0;
	
	SELECT
		IFNULL(ra_id, 0),
		IFNULL(parent_id, 0),
		IFNULL(steelitem_id, 0),
		IFNULL(weight, 0),
		IFNULL(weighed_weight, 0)
	INTO
		var_ra_id,
		var_ra_item_parent_id,
		var_ra_item_steelitem_id,
		var_ra_item_weight,
		var_ra_item_weighed_weight
	FROM ra_items
	WHERE id = param_ra_item_id;

	IF var_ra_item_steelitem_id = 0 OR var_ra_id = 0 OR var_ra_item_parent_id > 0
	THEN
		RETURN 0;
	END IF;
	
	SELECT IFNULL(weighed_weight, 0)
	INTO var_ra_weighed_weight
	FROM ra
	WHERE id = var_ra_id;

	IF var_ra_weighed_weight = 0
	THEN
		RETURN var_ra_item_weighed_weight;
	END IF;

    SET var_steelitem_owner_id	= IFNULL((SELECT owner_id FROM steelitems WHERE id = var_ra_item_steelitem_id), 0);

    IF var_steelitem_owner_id = 0
	THEN
		RETURN var_ra_item_weighed_weight;
	END IF;

	SET var_ra_items_weight_sum = IFNULL((
		SELECT SUM(rai.weight)
		FROM ra_items AS rai
		LEFT JOIN steelitems AS si ON si.id = rai.steelitem_id
		WHERE
				rai.ra_id = var_ra_id
			AND rai.parent_id = 0
			AND si.owner_id = var_steelitem_owner_id
	), 0);
	
	IF var_ra_items_weight_sum = 0
	THEN
		RETURN var_ra_item_weighed_weight;
	END IF;

	RETURN var_ra_item_weight * ((var_ra_weighed_weight * 100) / var_ra_items_weight_sum) / 100;
END$$


delimiter ;
