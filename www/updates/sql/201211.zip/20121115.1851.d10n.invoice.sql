delimiter $$

DROP PROCEDURE IF EXISTS `sp_invoice_save`$$
CREATE PROCEDURE `sp_invoice_save`(param_user_id INT, param_id INT, param_order_id INT, param_biz_id INT, param_company_id INT, param_owner_id INT, 
                                    param_number VARCHAR(20), param_date TIMESTAMP,
	IN param_due_date TIMESTAMP,
	IN param_status_id TINYINT,
	IN param_amount_received DECIMAL(10,4)
)
BEGIN

    DECLARE var_iva_number  INT DEFAULT 0;
    DECLARE var_year4       INT DEFAULT 0;
    DECLARE var_year2       INT DEFAULT 0;
    
    SET var_year4 = DATE_FORMAT(NOW(), '%Y');
    SET var_year2 = DATE_FORMAT(NOW(), '%y');

    IF param_id > 0
    THEN

        UPDATE invoices
        SET
            biz_id      		= param_biz_id,
            company_id  		= param_company_id,
            number      		= param_number,
            `date`      		= param_date,
			`due_date`  		= param_due_date,
			`status_id`			= param_status_id,
			`amount_received`  	= param_amount_received,
            modified_at 		= NOW(),
            modified_by 		= param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
        
            SET var_iva_number = IFNULL((SELECT MAX(iva_number) FROM invoices WHERE owner_id = param_owner_id AND iva_year = var_year4), 0) + 1;
            
            INSERT invoices
            SET
                order_id        	= param_order_id,
                biz_id          	= param_biz_id,
                company_id      	= param_company_id,
                owner_id        	= param_owner_id,
                number          	= param_number,
                `date`          	= param_date,
				`due_date`  		= param_due_date,
				`status_id`			= param_status_id,
				`amount_received`  	= param_amount_received,
                iva_number      	= var_iva_number,
                iva_number_full 	= CONCAT(var_iva_number, '/', var_year4),
                iva_year        	= var_year4,
                created_at      	= NOW(),
                created_by      	= param_user_id;

            SET param_id = (SELECT MAX(id) FROM invoices WHERE created_by  = param_user_id);

        COMMIT;

    END IF;

    
    SELECT param_id AS id;    
    
    SELECT * FROM invoice_items WHERE invoice_id = param_id;
    
    DELETE FROM invoice_items WHERE invoice_id = param_id;

END$$

delimiter ;
