DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_cmr_save`$$
CREATE PROCEDURE `sp_cmr_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_number INT,
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_attachment_id INT,
	IN param_product_name VARCHAR(50)
)
sp:
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO cmr
		SET
			#`number`		= IFNULL((SELECT MAX(cmr2.`number`)+1 FROM cmr AS cmr2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_number,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM cmr WHERE created_by = param_user_id);
	ELSE

		IF param_number <= 0
		THEN
			SELECT owner_id, YEAR(param_date)
			INTO var_owner_id, var_date_year
			FROM cmr
			WHERE id = param_id;
			
			SET param_number = IFNULL((SELECT MAX(`number`) FROM cmr WHERE owner_id = var_owner_id AND date_year = var_date_year LIMIT 1), 0) + 1;
		END IF;

		UPDATE cmr
		SET
			ra_id			= param_ra_id,
			`number`		= param_number,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			product_name	= param_product_name,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
    SELECT param_id AS cmr_id;

COMMIT;
END$$


DROP PROCEDURE IF EXISTS `sp_ddt_save`$$
CREATE PROCEDURE `sp_ddt_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_number INT,
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_iva VARCHAR(20),
	IN param_paymenttype_id INT,
	IN param_causale_id INT,
	IN param_porto_id INT,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_attachment_id INT,
	IN param_dest_type_id TINYINT
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO ddt
		SET
			#`number`		= IFNULL((SELECT MAX(ddt2.`number`)+1 FROM ddt AS ddt2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_number,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by = param_user_id);
	ELSE
		IF param_number <= 0
		THEN
			SELECT owner_id, YEAR(param_date)
			INTO var_owner_id, var_date_year
			FROM ddt
			WHERE id = param_id;

			SET param_number = IFNULL((SELECT MAX(`number`) FROM ddt WHERE owner_id = var_owner_id AND date_year = var_date_year LIMIT 1), 0) + 1;
		END IF;

		UPDATE ddt
		SET
			ra_id			= param_ra_id,
			`number`		= param_number,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
	
    
    SELECT param_id AS ddt_id;

COMMIT;
END$$


DROP FUNCTION IF EXISTS `sf_ra_item_recalculate_ww`$$
CREATE FUNCTION `sf_ra_item_recalculate_ww`(param_ra_item_id INT) RETURNS decimal(10,4)
BEGIN
	DECLARE var_ra_id 					INT 			DEFAULT 0;
	DECLARE var_ra_weighed_weight		DECIMAL(10,4) 	DEFAULT 0;

	DECLARE var_ra_item_parent_id		INT 			DEFAULT 0;
	DECLARE var_ra_item_steelitem_id 	INT 			DEFAULT 0;
	DECLARE var_ra_item_weight			DECIMAL(10,4) 	DEFAULT 0;
	DECLARE var_ra_item_weighed_weight	DECIMAL(10,4) 	DEFAULT 0;
	DECLARE var_ra_items_weight_sum		DECIMAL(10,4) 	DEFAULT 0;

	DECLARE var_steelitem_owner_id	INT 		DEFAULT 0;
	
	SELECT
		IFNULL(ra_id, 0),
		IFNULL(parent_id, 0),
		IFNULL(steelitem_id, 0),
		IFNULL(weight, 0),
		IFNULL(weighed_weight, 0)
	INTO
		var_ra_id,
		var_ra_item_parent_id,
		var_ra_item_steelitem_id,
		var_ra_item_weight,
		var_ra_item_weighed_weight
	FROM ra_items
	WHERE id = param_ra_item_id;

	IF var_ra_item_steelitem_id = 0 OR var_ra_id = 0 OR var_ra_item_parent_id > 0
	THEN
		RETURN 0;
	END IF;
	
	SELECT IFNULL(weighed_weight, 0)
	INTO var_ra_weighed_weight
	FROM ra
	WHERE id = var_ra_id;

	IF var_ra_weighed_weight = 0
	THEN
		RETURN var_ra_item_weighed_weight;
	END IF;

	#SET var_steelitem_owner_id	= IFNULL((SELECT owner_id FROM steelitems WHERE id = var_ra_item_steelitem_id), 0);

	#IF var_steelitem_owner_id = 0
	#THEN
		#RETURN var_ra_item_weighed_weight;
	#END IF;

	SET var_ra_items_weight_sum = IFNULL((
		SELECT SUM(rai.weight)
		FROM ra_items AS rai
		#LEFT JOIN steelitems AS si ON si.id = rai.steelitem_id
		WHERE
				rai.ra_id = var_ra_id
			AND rai.parent_id = 0
			#AND si.owner_id = var_steelitem_owner_id
	), 0);
	
	IF var_ra_items_weight_sum = 0
	THEN
		RETURN var_ra_item_weighed_weight;
	END IF;

	RETURN var_ra_item_weight * ((var_ra_weighed_weight * 100) / var_ra_items_weight_sum) / 100;
END$$


DROP PROCEDURE IF EXISTS `sp_steelitem_save_ddt`$$
CREATE PROCEDURE `sp_steelitem_save_ddt`(param_user_id INT, param_steelitem_id INT, param_ddt_number VARCHAR(50), 
                                        param_ddt_date TIMESTAMP, param_ddt_company_id INT,
                                        param_source_alias VARCHAR(20), param_source_id INT)
sp:
BEGIN

    DECLARE var_ddt_id          INT DEFAULT 0;
    DECLARE var_ddt_company_id  INT DEFAULT 0;
    DECLARE var_source_alias    VARCHAR(20) DEFAULT '';
    DECLARE var_source_id       INT DEFAULT 0;

    
    SELECT
        id,
        ddt_company_id,
        source_alias,
        source_id
    INTO
        var_ddt_id,
        var_ddt_company_id,
        var_source_alias,
        var_source_id
    FROM steelitem_ddts
    WHERE steelitem_id = param_steelitem_id
    ORDER BY created_at DESC
    LIMIT 1;


    IF var_source_alias != param_source_alias 
        OR var_source_id != param_source_id
        OR var_ddt_company_id != param_ddt_company_id 
    THEN
        
        INSERT INTO steelitem_ddts
        SET
            steelitem_id    = param_steelitem_id,
            ddt_number      = param_ddt_number,
            ddt_date        = param_ddt_date,
            ddt_company_id  = param_ddt_company_id,
            source_alias    = param_source_alias,
            source_id       = param_source_id,
            created_at      = NOW(),
            created_by      = param_user_id;            

    ELSE

        UPDATE steelitem_ddts
        SET
            steelitem_id    = param_steelitem_id,
            ddt_number      = param_ddt_number,
            ddt_date        = param_ddt_date,
            ddt_company_id  = param_ddt_company_id,
            source_alias    = param_source_alias,
            source_id       = param_source_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = var_ddt_id;

    END IF;


END$$


DROP PROCEDURE IF EXISTS `sp_ra_items_recalculate_ww`$$
CREATE PROCEDURE `sp_ra_items_recalculate_ww`(IN param_ra_id INT)
BEGIN
	UPDATE ra_items
	SET
		weighed_weight = sf_ra_item_recalculate_ww(id)
	WHERE
			ra_id		= param_ra_id
		AND parent_id	= 0
	;
END$$


DROP PROCEDURE IF EXISTS `sp_ra_item_add`$$
CREATE PROCEDURE `sp_ra_item_add`(
	IN param_user_id INT,
	IN param_parent_id INT,
	IN param_ra_id INT,
	IN param_steelitem_id INT,
	IN param_status_id TINYINT
)
sp:
BEGIN
	DECLARE var_ddt_id INT DEFAULT 0;
	DECLARE var_cmr_id INT DEFAULT 0;

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

	DECLARE var_ra_stockholder_id 			INT DEFAULT 0;
	DECLARE var_steelitem_stockholder_id	INT DEFAULT 0;
	DECLARE var_steelitem_owner_id 			INT DEFAULT 0;

    START TRANSACTION;
		SET var_ra_stockholder_id = IFNULL((SELECT stockholder_id FROM ra WHERE id = param_ra_id), 0);
		
		SELECT IFNULL(stockholder_id, 0), IFNULL(owner_id, 0)
		INTO var_steelitem_stockholder_id, var_steelitem_owner_id
		FROM steelitems
		WHERE id = param_steelitem_id;

		IF var_steelitem_stockholder_id != var_ra_stockholder_id
			OR var_steelitem_owner_id = 0
		THEN
			LEAVE sp;
		END IF;


        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;

		SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_steelitem_id, 
			weight    		= var_steelitem_unitweight_ton,
			weighed_weight	= var_steelitem_unitweight_ton,
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_steelitem_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_steelitem_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;
        
        END IF;
    
    COMMIT;

END$$


DROP PROCEDURE IF EXISTS `sp_ra_set_primary_item`$$
CREATE PROCEDURE `sp_ra_set_primary_item`(param_user_id INT, param_ra_id INT, param_ra_item_id INT)
sp:
BEGIN

    DECLARE var_parent_id           INT DEFAULT 0;
    DECLARE var_prev_steelitem_id   INT DEFAULT 0;
    DECLARE var_new_steelitem_id    INT DEFAULT 0;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

    IF NOT EXISTS (SELECT * FROM ra_items WHERE ra_id = param_ra_id AND id = param_ra_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    SET var_parent_id = (SELECT parent_id FROM ra_items WHERE id = param_ra_item_id);

    IF var_parent_id = 0 
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;        
    END IF;


    SET var_prev_steelitem_id   = (SELECT steelitem_id FROM ra_items WHERE id = var_parent_id);
    SET var_new_steelitem_id    = (SELECT steelitem_id FROM ra_items WHERE id = param_ra_item_id);

	SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = var_new_steelitem_id), 0);    

    UPDATE ra_items
    SET 
        parent_id		= 0,
		weight			= var_steelitem_unitweight_ton,
		weighed_weight	= var_steelitem_unitweight_ton
    WHERE id = param_ra_item_id;
    
    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE id = var_parent_id;

    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE parent_id = var_parent_id
    AND ra_id = param_ra_id;

    SET var_attachment_ids = (
        SELECT 
            GROUP_CONCAT(attachment_id SEPARATOR ",") 
        FROM attachment_objects 
        WHERE object_alias = 'ra'
        AND object_id = param_ra_id
    );

    SET @var_stmt := CONCAT("
        DELETE FROM attachment_objects 
        WHERE object_alias = 'steelitem'
        AND object_id = " , var_prev_steelitem_id, 
        " AND attachment_id IN (", var_attachment_ids, ")
    ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

    INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
    SELECT
        attachment_id, 
        `type`,
        'steelitem',
        var_new_steelitem_id,
        NOW(),
        param_user_id
    FROM attachment_objects
    WHERE object_alias = 'ra'
    AND object_id = param_ra_id;

    
    SELECT 
        var_prev_steelitem_id   AS prev_steelitem_id,
        var_new_steelitem_id    AS new_steelitem_id;

END$$

DELIMITER ;
