delimiter $$

DROP PROCEDURE IF EXISTS `sp_ra_set_primary_item`$$
CREATE PROCEDURE `sp_ra_set_primary_item`(param_user_id INT, param_ra_id INT, param_ra_item_id INT)
sp:
BEGIN

    DECLARE var_parent_id           INT DEFAULT 0;
    DECLARE var_prev_steelitem_id   INT DEFAULT 0;
    DECLARE var_new_steelitem_id    INT DEFAULT 0;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

    IF NOT EXISTS (SELECT * FROM ra_items WHERE ra_id = param_ra_id AND id = param_ra_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    SET var_parent_id = (SELECT parent_id FROM ra_items WHERE id = param_ra_item_id);

    IF var_parent_id = 0 
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;        
    END IF;


    SET var_prev_steelitem_id   = (SELECT steelitem_id FROM ra_items WHERE id = var_parent_id);
    SET var_new_steelitem_id    = (SELECT steelitem_id FROM ra_items WHERE id = param_ra_item_id);

	SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = var_new_steelitem_id), 0);    

    UPDATE ra_items
    SET 
        parent_id		= 0,
		weight			= var_steelitem_unitweight_ton,
		weighed_weight	= var_steelitem_unitweight_ton
    WHERE id = param_ra_item_id;
    
    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE id = var_parent_id;

    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE parent_id = var_parent_id
    AND ra_id = param_ra_id;

    SET var_attachment_ids = (
        SELECT 
            GROUP_CONCAT(attachment_id SEPARATOR ",") 
        FROM attachment_objects 
        WHERE object_alias = 'ra'
        AND object_id = param_ra_id
    );

    SET @var_stmt := CONCAT("
        DELETE FROM attachment_objects 
        WHERE object_alias = 'steelitem'
        AND object_id = " , var_prev_steelitem_id, 
        " AND attachment_id IN (", var_attachment_ids, ")
    ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

    INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
    SELECT
        attachment_id, 
        `type`,
        'steelitem',
        var_new_steelitem_id,
        NOW(),
        param_user_id
    FROM attachment_objects
    WHERE object_alias = 'ra'
    AND object_id = param_ra_id;

    
    SELECT 
        var_prev_steelitem_id   AS prev_steelitem_id,
        var_new_steelitem_id    AS new_steelitem_id;

END$$

delimiter ;
