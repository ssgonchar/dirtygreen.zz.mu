ALTER TABLE `cmr` ADD COLUMN `is_outdated` TINYINT NOT NULL DEFAULT 0  AFTER `product_name`;
ALTER TABLE `ddt` ADD COLUMN `is_outdated` TINYINT NOT NULL DEFAULT 0  AFTER `is_deleted`;
