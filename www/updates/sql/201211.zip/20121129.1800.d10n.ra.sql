ALTER TABLE `ra_items` ADD COLUMN `owner_id` INT NULL  AFTER `steelitem_id`;


DELIMITER $$

DROP procedure IF EXISTS `sp_cmr_item_save`$$
DROP procedure IF EXISTS `sp_ddt_item_save`$$


DROP procedure IF EXISTS `sp_cmr_get_items`$$
CREATE PROCEDURE `sp_cmr_get_items`(IN param_cmr_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM cmr
	WHERE id = param_cmr_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	#JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		#AND si.owner_id = var_owner_id
		AND ra_i.owner_id = var_owner_id
	;

END$$


DROP procedure IF EXISTS `sp_ddt_get_items`$$
CREATE PROCEDURE `sp_ddt_get_items`(IN param_ddt_id INT)
BEGIN

	DECLARE var_ra_id INT DEFAULT 0;
	DECLARE var_owner_id INT DEFAULT 0;

	SELECT ra_id, owner_id
	INTO var_ra_id, var_owner_id
	FROM ddt
	WHERE id = param_ddt_id;

	SELECT 
		ra_i.steelitem_id, 
		ra_i.weighed_weight 
	FROM ra_items AS ra_i
	#JOIN steelitems AS si ON si.id = ra_i.steelitem_id
	WHERE
			ra_i.ra_id = var_ra_id
		AND ra_i.parent_id = 0
		#AND si.owner_id = var_owner_id
		AND ra_i.owner_id = var_owner_id
	;

END$$


DROP procedure IF EXISTS `sp_ra_update_related_docs`$$
CREATE PROCEDURE `sp_ra_update_related_docs`(param_user_id INT, param_ra_id INT)
sp:
BEGIN
    
    DECLARE var_ra_item_ids VARCHAR(4000) DEFAULT '';

    SET var_ra_item_ids = (
        SELECT
            #GROUP_CONCAT(DISTINCT steelitems.owner_id SEPARATOR ",")            
			GROUP_CONCAT(owner_id SEPARATOR ",")
        FROM ra_items
        #JOIN steelitems ON ra_items.steelitem_id = steelitems.id
        WHERE ra_items.ra_id = param_ra_id
        AND ra_items.parent_id = 0
		AND owner_id NOT IN (11980)
    );

    
    IF EXISTS (SELECT * FROM cmr WHERE ra_id = param_ra_id)
    THEN

        UPDATE cmr
        SET
            is_outdated = 1
        WHERE ra_id = param_ra_id;

        
        SET @var_stmt = CONCAT("
            UPDATE cmr
            SET
                is_deleted = 0
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            UPDATE cmr
            SET
                is_deleted = 1
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id NOT IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            INSERT IGNORE INTO cmr(ra_id, owner_id, number, is_outdated, created_at, created_by)
            SELECT
                ", param_ra_id, ",
                id,
                0,
                1,
                NOW(),
                ", param_user_id, "
            FROM companies
            WHERE id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
    END IF;


    IF EXISTS (SELECT * FROM ddt WHERE ra_id = param_ra_id)
    THEN

        UPDATE ddt
        SET
            is_outdated = 1
        WHERE ra_id = param_ra_id;

        
        SET @var_stmt = CONCAT("
            UPDATE ddt
            SET
                is_deleted = 0
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id IN (", var_ra_item_ids, ");
        ");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            UPDATE ddt
            SET
                is_deleted = 1
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id NOT IN (", var_ra_item_ids, ");
        ");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;

        SET @var_stmt = CONCAT("
            INSERT IGNORE INTO ddt(ra_id, owner_id, number, is_outdated, created_at, created_by)
            SELECT
                ", param_ra_id, ",
                id,
                0,
                1,
                NOW(),
                ", param_user_id, "
            FROM companies
            WHERE id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
    END IF;

END$$


DROP procedure IF EXISTS `sp_ra_item_add`$$
CREATE PROCEDURE `sp_ra_item_add`(
	IN param_user_id INT,
	IN param_parent_id INT,
	IN param_ra_id INT,
	IN param_steelitem_id INT,
	IN param_status_id TINYINT
)
sp:
BEGIN
	DECLARE var_ddt_id INT DEFAULT 0;
	DECLARE var_cmr_id INT DEFAULT 0;

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

	DECLARE var_ra_stockholder_id 			INT DEFAULT 0;
	DECLARE var_steelitem_stockholder_id	INT DEFAULT 0;
	DECLARE var_steelitem_owner_id 			INT DEFAULT 0;

    START TRANSACTION;
		
        SET var_ra_stockholder_id = IFNULL((SELECT stockholder_id FROM ra WHERE id = param_ra_id), 0);
		
		SELECT 
            IFNULL(stockholder_id, 0), 
            IFNULL(owner_id, 0)
		INTO 
            var_steelitem_stockholder_id, 
            var_steelitem_owner_id
		FROM steelitems
		WHERE id = param_steelitem_id;

		IF var_steelitem_stockholder_id != var_ra_stockholder_id OR var_steelitem_owner_id = 0
		THEN
			LEAVE sp;
		END IF;


        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;

		SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_steelitem_id, 
			owner_id    	= var_steelitem_owner_id,
			weight    		= var_steelitem_unitweight_ton,
			weighed_weight	= var_steelitem_unitweight_ton,
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_steelitem_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_steelitem_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;


            CALL sp_ra_item_save_ddt(param_user_id, param_steelitem_id, param_ra_id);
            CALL sp_ra_items_recalculate_ww(param_ra_id);
            CALL sp_ra_update_related_docs(param_user_id, param_ra_id);
        
        END IF;
    
    COMMIT;

END$$

DELIMITER ;
