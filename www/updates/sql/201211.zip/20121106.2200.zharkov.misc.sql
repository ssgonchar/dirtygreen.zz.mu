#ALTER TABLE `users` ADD `phone` VARCHAR( 50 ) NULL, ADD `skype` VARCHAR( 50 ) NULL ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_user_update_profile$$
CREATE PROCEDURE sp_user_update_profile(param_user_id INT, param_title CHAR(5), param_first_name VARCHAR(50), param_last_name VARCHAR(50), 
                                        param_phone VARCHAR(50), param_skype VARCHAR(50))
BEGIN

    DECLARE var_person_id INT DEFAULT 0;
    SET var_person_id = IFNULL((SELECT person_id FROM users WHERE id = param_user_id), 0);

    IF var_person_id = 0
    THEN

        INSERT INTO persons
        SET
            title       = param_title,
            first_name  = param_first_name,
            last_name   = param_last_name,
            created_at  = NOW(),
            created_by  = param_user_id;

        SET var_person_id = (SELECT MAX(id) FROM persons WHERE created_by = param_user_id);
        
    ELSE

        UPDATE persons
        SET
            title       = param_title,
            first_name  = param_first_name,
            last_name   = param_last_name,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = var_person_id;

    END IF;


    UPDATE users
    SET
        phone   	= param_phone,
        skype   	= param_skype,
		person_id	= var_person_id,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_user_id;
    

    SELECT 
        param_user_id   AS user_id,
        var_person_id   AS person_id;

END
$$

DELIMITER ;
