-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 16.11.2012 0:47:04
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_company_save$$
CREATE PROCEDURE sp_company_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_title_native VARCHAR(250), 
                    param_title_short VARCHAR(50), param_title_trade VARCHAR(50), param_parent_id INT, IN param_type_id TINYINT(4), IN param_status_id TINYINT(4),
                    IN param_relation_id TINYINT(4), param_key_contact INT, param_mam_genius INT, param_country_id INT, param_region_id INT, param_city_id INT, 
                    param_zip VARCHAR(20), param_address VARCHAR(100), param_pobox VARCHAR(20), param_delivery_address TEXT, param_data_labels TEXT, 
                    param_notes TEXT, param_bank_data TEXT, param_reg_data TEXT, param_rail_access VARCHAR(250),
                    param_vat VARCHAR(50), param_albo VARCHAR(50))
sp:
BEGIN

    DECLARE var_is_mam TINYINT DEFAULT 0;


    IF EXISTS (SELECT * FROM companies WHERE id != param_id AND title = param_title)
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_save' AS ErrorAt;
        LEAVE sp;    
    END IF;

    IF param_parent_id > 0
    THEN
        SET var_is_mam = (SELECT is_mam FROM companies WHERE id = param_parent_id);
    END IF;


    IF param_id > 0
    THEN

        IF param_parent_id = 0
        THEN
            SET var_is_mam = (SELECT is_mam FROM companies WHERE id = param_id);
        END IF;

        UPDATE companies
        SET
            title               = param_title,
            title_native        = param_title_native,
            title_short         = param_title_short,
            title_trade         = param_title_trade,
            parent_id           = param_parent_id,
            type_id             = param_type_id,
            status_id           = param_status_id,
            relation_id         = param_relation_id,
            key_contact_id      = param_key_contact,
            mam_genius_id       = param_mam_genius,
            country_id          = param_country_id,
            region_id           = param_region_id,
            city_id             = param_city_id,
            zip                 = param_zip,
            address             = param_address,
            pobox               = param_pobox,
            delivery_address    = param_delivery_address,
            data_labels         = param_data_labels,
            notes               = param_notes,
            bank_data           = param_bank_data,
            reg_data            = param_reg_data,
            rail_access         = param_rail_access,
            vat                 = param_vat,
            albo                = param_albo,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

    ELSE
        
        START TRANSACTION;

            INSERT companies
            SET
                title               = param_title,
                title_native        = param_title_native,
                title_short         = param_title_short,
                title_trade         = param_title_trade,
                parent_id           = param_parent_id,
                type_id             = param_type_id,
                status_id           = param_status_id,
                relation_id         = param_relation_id,
                key_contact_id      = param_key_contact,
                mam_genius_id       = param_mam_genius,
                country_id          = param_country_id,
                region_id           = param_region_id,
                city_id             = param_city_id,
                zip                 = param_zip,
                address             = param_address,
                pobox               = param_pobox,
                delivery_address    = param_delivery_address,
                data_labels         = param_data_labels,
                notes               = param_notes,
                bank_data           = param_bank_data,
                reg_data            = param_reg_data,
                rail_access         = param_rail_access,
                vat                 = param_vat,
                albo                = param_albo,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id;

            SET param_id = (SELECT MAX(id) FROM companies WHERE created_by = param_user_id);
        
        COMMIT;
                
    END IF;

    SELECT param_id AS id;

END
$$

DELIMITER ;
