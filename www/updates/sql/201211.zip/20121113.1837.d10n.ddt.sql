delimiter $$

DROP PROCEDURE IF EXISTS `sp_ddt_item_save`$$
CREATE PROCEDURE `sp_ddt_item_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ddt_id INT,
	IN param_steelitem_id INT
)
sp:
BEGIN
	DECLARE var_ddt_weighed_weight 		DECIMAL(10,4) DEFAULT 0;
	DECLARE var_ddt_item_weighed_weight DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_unitweight 	DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_sum_unitweight 	DECIMAL(10,4) DEFAULT 0;
	

START TRANSACTION;

#это сумма весов всех айтемов входящих в ddt
#считается: select SUM(unitweight) FROM ddt_items JOIN steelitems ON ddt_items.item_id = steelitems.id WHERE ddt_id = param_ddt_id
#Когда стокагент присылает свой DDT, он там указывает взвешенный вес, но не по каждому листу, а на всю отгруженную пачку.
#Нам в нашем DDT нам нужно тоже указать взвешенный вес, для этого мы изменяем теоритический вес по каждому листу пропорционально взвешанному,
#полученному от стокагента

	SET var_ddt_weighed_weight 		= IFNULL((SELECT weighed_weight FROM ddt WHERE id = param_ddt_id), 0);
	SET var_steelitem_unitweight	= IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);

	IF var_ddt_weighed_weight > 0
	THEN
		
		SET var_steelitem_sum_unitweight= IFNULL((
			SELECT SUM(si.unitweight_ton)
			FROM ddt_items AS ddt_i
			JOIN steelitems AS si ON ddt_i.steelitem_id = si.id
			WHERE ddt_i.ddt_id = param_ddt_id
		), 0);
		SET var_ddt_item_weighed_weight	= var_steelitem_unitweight * ((var_ddt_weighed_weight * 100 / var_steelitem_sum_unitweight)) / 100;
	ELSE
		SET var_ddt_item_weighed_weight = var_steelitem_unitweight;
	END IF;
	
	IF param_id = 0
	THEN
		INSERT INTO ddt_items
		SET
			`ddt_id`		= param_ddt_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_ddt_item_weighed_weight,
			`created_at`	= NOW(),
			`created_by`	= param_user_id,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		;

		SET param_id = (SELECT MAX(id) FROM ddt_items WHERE `created_by` = param_user_id);
	ELSE
		UPDATE ddt_items
		SET
			`ddt_id`		= param_ddt_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_ddt_item_weighed_weight,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ddt_item_id;
COMMIT;
END$$

delimiter ;
