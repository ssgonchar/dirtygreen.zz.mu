ALTER TABLE `steelitems` ADD `in_ddt_company_id` INT NOT NULL AFTER `in_ddt_date`;
ALTER TABLE `steelitems` ADD `ddt_company_id` INT NOT NULL AFTER `ddt_date`;