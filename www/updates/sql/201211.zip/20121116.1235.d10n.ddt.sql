ALTER TABLE `ddt`
    ADD COLUMN `ra_id` INT NULL  AFTER `id`,
    CHANGE COLUMN `number` `number` INT NULL DEFAULT NULL,
    ADD COLUMN `owner_id` INT NULL  AFTER `ra_id`,
    ADD COLUMN `date_year` INT NULL  AFTER `date`,
    ADD COLUMN `dest_type_id` TINYINT NULL AFTER `attachment_id`;
    
    
delimiter $$

DROP PROCEDURE IF EXISTS `sp_ddt_get_list`$$
CREATE PROCEDURE `sp_ddt_get_list`(
	IN param_ra_id INT,
	IN param_from INT,
	IN param_count INT
)
sp:
BEGIN

    PREPARE stmt FROM
    "SELECT 
        id AS ddt_id 
    FROM ddt
	WHERE
		(ra_id = ? OR ? = -1)
    ORDER BY modified_at DESC 
    LIMIT ?, ?;";

    SET
		@stmt_param_ra_id = param_ra_id,

		@stmt_from  = param_from,
		@stmt_count	= param_count
	;
    
    EXECUTE stmt
	USING
		@stmt_param_ra_id,
		@stmt_param_ra_id,

		@stmt_from,
		@stmt_count
	;

   
    SELECT
		COUNT(*) AS rows_count
	FROM ddt
	WHERE
		(ra_id = param_ra_id OR param_ra_id = -1)
	;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_save`$$
CREATE PROCEDURE `sp_ddt_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_iva VARCHAR(20),
	IN param_paymenttype_id INT,
	IN param_causale_id INT,
	IN param_porto_id INT,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_weighed_weight DECIMAL(10,4),
	IN param_attachment_id INT,
	IN param_dest_type_id TINYINT
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO ddt
		SET
			#`number`		= IFNULL((SELECT MAX(ddt2.`number`)+1 FROM ddt AS ddt2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_num,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by = param_user_id);
	ELSE
		IF param_num <= 0
		THEN
			SELECT owner_id, date_year
			INTO var_owner_id, var_date_year
			FROM ddt
			WHERE
				id = param_id
			;

			SET param_num = IFNULL((
					SELECT MAX(`number`)
					FROM ddt
					WHERE
							owner_id = var_owner_id
						AND date_year = var_date_year
					LIMIT 1
				), 0) + 1;
		END IF;

		UPDATE ddt
		SET
			ra_id			= param_ra_id,
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			dest_type_id	= param_dest_type_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
	
    
    SELECT param_id AS ddt_id;

COMMIT;
END$$



delimiter ;
