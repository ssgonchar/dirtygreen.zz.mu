ALTER TABLE `steelitems` CHANGE COLUMN `ddt_company_id` `ddt_company_id` INT(11) NOT NULL DEFAULT 0;
