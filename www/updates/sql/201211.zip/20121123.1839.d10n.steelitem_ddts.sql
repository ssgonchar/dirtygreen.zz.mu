delimiter $$

DROP TABLE IF EXISTS `steelitem_ddts`$$
CREATE TABLE `steelitem_ddts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `steelitem_id` int(11) DEFAULT NULL,
  `ddt_number` varchar(50) DEFAULT NULL,
  `ddt_date` timestamp NULL DEFAULT NULL,
  `ddt_company_id` int(11) DEFAULT NULL,
  `source_alias` varchar(20) NOT NULL,
  `source_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Для регистрации изменений ddt'$$
