DROP TABLE IF EXISTS `ddt`;
CREATE TABLE `ddt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(20) DEFAULT NULL,
  `buyer` varchar(500) DEFAULT NULL,
  `delivery_point` varchar(500) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `iva` varchar(20) DEFAULT NULL,
  `paymenttype_id` int(11) DEFAULT NULL,
  `causale_id` int(11) DEFAULT NULL,
  `porto_id` int(11) DEFAULT NULL,
  `truck_number` varchar(20) DEFAULT NULL,
  `transporter_id` int(11) DEFAULT NULL,
  `weighed_weight` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `attachment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `ddt_items`;
CREATE TABLE `ddt_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ddt_id` int(11) DEFAULT NULL,
  `steelitem_id` int(11) DEFAULT NULL,
  `weighed_weight` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


delimiter $$

DROP PROCEDURE IF EXISTS `sp_ddt_get_items`$$
CREATE PROCEDURE `sp_ddt_get_items`(IN param_ddt_id INT)
BEGIN

    SELECT
        *
    FROM ddt_items
    WHERE ddt_id = param_ddt_id;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_get_list`$$
CREATE PROCEDURE `sp_ddt_get_list`(
	IN param_from INT,
	IN param_count INT
)
sp:
BEGIN

    PREPARE stmt FROM
    "SELECT 
        id AS ddt_id 
    FROM ddt
    ORDER BY modified_at DESC 
    LIMIT ?, ?;";

    SET
		@stmt_from  = param_from,
		@stmt_count	= param_count
	;
    
    EXECUTE stmt
	USING
		@stmt_from,
		@stmt_count
	;

   
    SELECT COUNT(*) AS rows_count FROM ddt;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_get_list_by_ids`$$
CREATE PROCEDURE `sp_ddt_get_list_by_ids`(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_ddt_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt = CONCAT(  
        "SELECT * 
        FROM ddt
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_item_save`$$
CREATE PROCEDURE `sp_ddt_item_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ddt_id INT,
	IN param_steelitem_id INT
)
sp:
BEGIN
	DECLARE var_ddt_weighed_weight 		DECIMAL(10,4) DEFAULT 0;
	DECLARE var_ddt_item_weighed_weight DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_unitweight 	DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_sum_unitweight 	DECIMAL(10,4) DEFAULT 0;
	

START TRANSACTION;
	SET var_ddt_weighed_weight = IFNULL((SELECT weighed_weight FROM ddt WHERE id = param_ddt_id), 0);

	IF var_ddt_weighed_weight > 0
	THEN
		SET var_steelitem_unitweight	= IFNULL((SELECT unitweight FROM steelitems WHERE id = param_steelitem_id), 0);
		SET var_steelitem_sum_unitweight= IFNULL((
			SELECT SUM(unitweight)
			FROM ddt_items AS ddt_i
			JOIN steelitems AS si ON ddt_i.steelitem_id = si.id
			WHERE ddt_i.ddt_id = param_ddt_id
		), 0);
		SET var_ddt_item_weighed_weight	= var_steelitem_unitweight * ((var_ddt_weighed_weight * 100 / var_steelitem_sum_unitweight)) / 100;
	END IF;

	IF param_id = 0
	THEN
		INSERT INTO ddt_items
		SET
			`ddt_id`		= param_ddt_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_ddt_item_weighed_weight,
			`created_at`	= NOW(),
			`created_by`	= param_user_id,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		;

		SET param_id = (SELECT MAX(id) FROM ddt_items WHERE `created_by` = param_user_id);
	ELSE
		UPDATE ddt_items
		SET
			`ddt_id`		= param_ddt_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_ddt_item_weighed_weight,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ddt_item_id;
COMMIT;
END$$


DROP PROCEDURE IF EXISTS `sp_ddt_remove`$$
CREATE PROCEDURE `sp_ddt_remove`(IN param_id INT)
BEGIN

    DELETE FROM ddt WHERE id = param_id;

END$$


DROP PROCEDURE IF EXISTS `sp_ddt_save`$$
CREATE PROCEDURE `sp_ddt_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_iva VARCHAR(20),
	IN param_paymenttype_id INT,
	IN param_causale_id INT,
	IN param_porto_id INT,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_weighed_weight DECIMAL(10,4),
	IN param_attachment_id INT
)
BEGIN
START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO ddt
		SET
			`number`		= IFNULL((SELECT MAX(ddt2.`number`)+1 FROM ddt AS ddt2 LIMIT 1), 1),
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by = param_user_id);
	ELSE
		UPDATE ddt
		SET
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
	
    
    SELECT param_id AS ddt_id;

COMMIT;
END$$


delimiter ;
