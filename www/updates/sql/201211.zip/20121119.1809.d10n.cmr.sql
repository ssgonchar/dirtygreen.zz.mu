delimiter $$

CREATE TABLE `cmr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ra_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `date_year` int(11) DEFAULT NULL,
  `buyer` varchar(500) DEFAULT NULL,
  `delivery_point` varchar(500) DEFAULT NULL,
  `truck_number` varchar(20) DEFAULT NULL,
  `transporter_id` int(11) DEFAULT NULL,
  `weighed_weight` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `attachment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8$$


delimiter $$

CREATE TABLE `cmr_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmr_id` int(11) DEFAULT NULL,
  `steelitem_id` int(11) DEFAULT NULL,
  `weighed_weight` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8$$





delimiter $$

DROP PROCEDURE IF EXISTS `sp_cmr_get_items`$$
CREATE PROCEDURE `sp_cmr_get_items`(IN param_cmr_id INT)
BEGIN

    SELECT
        *
    FROM cmr_items
    WHERE cmr_id = param_cmr_id;

END$$


DROP PROCEDURE IF EXISTS `sp_cmr_get_list`$$
CREATE PROCEDURE `sp_cmr_get_list`(
	IN param_ra_id INT,
	IN param_from INT,
	IN param_count INT
)
sp:
BEGIN

    PREPARE stmt FROM
    "SELECT 
        id AS cmr_id 
    FROM cmr
	WHERE
		(ra_id = ? OR ? = -1)
    ORDER BY modified_at DESC 
    LIMIT ?, ?;";

    SET
		@stmt_param_ra_id = param_ra_id,

		@stmt_from  = param_from,
		@stmt_count	= param_count
	;
    
    EXECUTE stmt
	USING
		@stmt_param_ra_id,
		@stmt_param_ra_id,

		@stmt_from,
		@stmt_count
	;

   
    SELECT
		COUNT(*) AS rows_count
	FROM cmr
	WHERE
		(ra_id = param_ra_id OR param_ra_id = -1)
	;

END$$


DROP PROCEDURE IF EXISTS `sp_cmr_get_list_by_ids`$$
CREATE PROCEDURE `sp_cmr_get_list_by_ids`(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_cmr_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt = CONCAT(  
        "SELECT * 
        FROM cmr
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END$$



DROP PROCEDURE IF EXISTS `sp_cmr_item_save`$$
CREATE PROCEDURE `sp_cmr_item_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_cmr_id INT,
	IN param_steelitem_id INT
)
sp:
BEGIN
	DECLARE var_cmr_weighed_weight 		DECIMAL(10,4) DEFAULT 0;
	DECLARE var_cmr_item_weighed_weight DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_unitweight 	DECIMAL(10,4) DEFAULT 0;
	DECLARE var_steelitem_sum_unitweight 	DECIMAL(10,4) DEFAULT 0;
	

START TRANSACTION;

#это сумма весов всех айтемов входящих в cmr
#считается: select SUM(unitweight) FROM cmr_items JOIN steelitems ON cmr_items.item_id = steelitems.id WHERE cmr_id = param_cmr_id
#Когда стокагент присылает свой cmr, он там указывает взвешенный вес, но не по каждому листу, а на всю отгруженную пачку.
#Нам в нашем cmr нам нужно тоже указать взвешенный вес, для этого мы изменяем теоритический вес по каждому листу пропорционально взвешанному,
#полученному от стокагента

	SET var_cmr_weighed_weight 		= IFNULL((SELECT weighed_weight FROM cmr WHERE id = param_cmr_id), 0);
	SET var_steelitem_unitweight	= IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);

	IF var_cmr_weighed_weight > 0
	THEN
		
		SET var_steelitem_sum_unitweight= IFNULL((
			SELECT SUM(si.unitweight_ton)
			FROM cmr_items AS cmr_i
			JOIN steelitems AS si ON cmr_i.steelitem_id = si.id
			WHERE cmr_i.cmr_id = param_cmr_id
		), 0);
		SET var_cmr_item_weighed_weight	= var_steelitem_unitweight * ((var_cmr_weighed_weight * 100 / var_steelitem_sum_unitweight)) / 100;
	ELSE
		SET var_cmr_item_weighed_weight = var_steelitem_unitweight;
	END IF;
	
	IF param_id = 0
	THEN
		INSERT INTO cmr_items
		SET
			`cmr_id`		= param_cmr_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_cmr_item_weighed_weight,
			`created_at`	= NOW(),
			`created_by`	= param_user_id,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		;

		SET param_id = (SELECT MAX(id) FROM cmr_items WHERE `created_by` = param_user_id);
	ELSE
		UPDATE cmr_items
		SET
			`cmr_id`		= param_cmr_id,
			`steelitem_id`	= param_steelitem_id,
			`weighed_weight`= var_cmr_item_weighed_weight,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS cmr_item_id;
COMMIT;
END$$


DROP PROCEDURE IF EXISTS `sp_cmr_remove`$$
CREATE PROCEDURE `sp_cmr_remove`(IN param_id INT)
BEGIN

    DELETE FROM cmr WHERE id = param_id;

END$$



DROP PROCEDURE IF EXISTS `sp_cmr_save`$$
CREATE PROCEDURE `sp_cmr_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_id INT,
	IN param_owner_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_weighed_weight DECIMAL(10,4),
	IN param_attachment_id INT
)
BEGIN
	DECLARE var_owner_id INT DEFAULT 0;
	DECLARE var_date_year INT DEFAULT 0;

START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO cmr
		SET
			#`number`		= IFNULL((SELECT MAX(cmr2.`number`)+1 FROM cmr AS cmr2 LIMIT 1), 1),
			ra_id			= param_ra_id,
			#`number`		= param_num,
			`number`		= 0,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM cmr WHERE created_by = param_user_id);
	ELSE
		IF param_num <= 0
		THEN
			SELECT owner_id, date_year
			INTO var_owner_id, var_date_year
			FROM cmr
			WHERE
				id = param_id
			;

			SET param_num = IFNULL((
					SELECT MAX(`number`)
					FROM cmr
					WHERE
							owner_id = var_owner_id
						AND date_year = var_date_year
					LIMIT 1
				), 0) + 1;
		END IF;

		UPDATE cmr
		SET
			ra_id			= param_ra_id,
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			owner_id		= param_owner_id,
			date_year		= YEAR(param_date),
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
    SELECT param_id AS cmr_id;

COMMIT;
END$$


delimiter ;
