
DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_save$$
CREATE PROCEDURE sp_steelitem_save(param_user_id INT, param_id INT, param_position_id INT, param_guid VARCHAR(32), param_alias VARCHAR(32),
                                    param_product_id INT(11), param_biz_id INT(11), param_stockholder_id INT(11), param_dimension_unit CHAR(10), 
                                    param_weight_unit CHAR(10), param_currency CHAR(10), param_steelgrade_id INT, 
                                    param_thickness CHAR(10), param_thickness_mm DECIMAL(10, 4), param_thickness_measured CHAR(10), 
                                    param_width CHAR(10), param_width_mm DECIMAL(10, 4), param_width_measured CHAR(10), param_width_max CHAR(10), 
                                    param_length CHAR(10), param_length_mm DECIMAL(10, 4), param_length_measured CHAR(10), param_length_max CHAR(10), 
                                    param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10, 4), param_price DECIMAL(10, 4), 
                                    param_value DECIMAL(10, 4), param_supplier_id INT(11), param_supplier_invoice_no VARCHAR(50), 
                                    param_supplier_invoice_date TIMESTAMP, param_purchase_price DECIMAL(10, 4), param_purchase_value DECIMAL(10, 4), 
                                    param_in_ddt_number VARCHAR(50), param_in_ddt_date TIMESTAMP, 
                                    param_out_ddt_number VARCHAR(50), param_out_ddt_date TIMESTAMP, 
                                    param_deliverytime_id INT, param_notes TEXT, 
                                    param_internal_notes TEXT, param_owner_id INT(11), param_status_id TINYINT, param_is_virtual TINYINT(4), 
                                    param_mill VARCHAR(50), param_system VARCHAR(50), param_unitweight_measured DECIMAL(10, 4),
                                    param_unitweight_weighed DECIMAL(10, 4), param_current_cost DECIMAL(10,4),
                                    param_pl DECIMAL(10,4), param_load_ready VARCHAR(50), param_purchase_currency CHAR(10),
                                    param_in_ddt_company_id INT, param_ddt_company_id INT)
sp:
BEGIN

    DECLARE var_location_id INT DEFAULT 0;

    IF TRIM(param_guid) != '' AND EXISTS (SELECT * FROM steelitems WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'steelitem_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SET param_is_virtual    = IF(TRIM(param_guid) != '', 0, param_is_virtual);
    SET var_location_id     = (SELECT location_id FROM companies WHERE id = param_stockholder_id);
        

    IF param_id > 0
    THEN

        IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'steelitem_save' AS ErrorAt;
            LEAVE sp;
        END IF;
    
        UPDATE steelitems
        SET
            guid                    = param_guid,
            alias                   = param_alias,
            product_id              = param_product_id,
            biz_id                  = param_biz_id,
            stockholder_id          = param_stockholder_id,
            location_id             = var_location_id,
            dimension_unit          = param_dimension_unit,
            weight_unit             = param_weight_unit,
            currency                = param_currency,            
            steelgrade_id           = param_steelgrade_id,
            thickness               = param_thickness,
            thickness_mm            = param_thickness_mm,
            thickness_measured      = param_thickness_measured,
            width                   = param_width,
            width_mm                = param_width_mm,
            width_measured          = param_width_measured,
            width_max               = param_width_max,
            `length`                = param_length,
            length_mm               = param_length_mm,
            length_measured         = param_length_measured,
            length_max              = param_length_max,
            unitweight              = param_unitweight,
            unitweight_ton          = param_unitweight_ton,
            price                   = param_price,
            `value`                 = param_value,
            supplier_id             = param_supplier_id,
            supplier_invoice_no     = param_supplier_invoice_no,
            supplier_invoice_date   = IF(param_supplier_invoice_date AND param_supplier_invoice_date != '', param_supplier_invoice_date, NULL),
            purchase_price          = param_purchase_price,
            purchase_value          = param_purchase_value,
            purchase_currency       = param_purchase_currency,
            in_ddt_number           = param_in_ddt_number,
            in_ddt_date             = IF(param_in_ddt_date AND param_in_ddt_date != '', param_in_ddt_date, NULL),
            in_ddt_company_id       = param_in_ddt_company_id,
            ddt_number              = param_out_ddt_number,
            ddt_date                = IF(param_out_ddt_date AND param_out_ddt_date != '', param_out_ddt_date, NULL),
            ddt_company_id          = param_ddt_company_id,
            deliverytime_id         = param_deliverytime_id,
            notes                   = param_notes,
            internal_notes          = param_internal_notes,
            owner_id                = param_owner_id,
            status_id               = param_status_id,
            is_virtual              = param_is_virtual,
            mill                    = param_mill,
            system                  = param_system,
            unitweight_measured     = param_unitweight_measured,
            unitweight_weighed      = param_unitweight_weighed,
            current_cost            = param_current_cost,
            pl                      = param_pl,
            load_ready              = param_load_ready,
            modified_at             = NOW(),
            modified_by             = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
            
            INSERT INTO steelitems
            SET
                steelposition_id        = param_position_id,
                guid                    = param_guid,
                alias                   = param_alias,
                product_id              = param_product_id,
                biz_id                  = param_biz_id,
                stockholder_id          = param_stockholder_id,
                location_id             = var_location_id,
                dimension_unit          = param_dimension_unit,
                weight_unit             = param_weight_unit,
                currency                = param_currency,
                parent_id               = 0,
                rel                     = '',
                steelgrade_id           = param_steelgrade_id,
                thickness               = param_thickness,
                thickness_mm            = param_thickness_mm,
                thickness_measured      = param_thickness_measured,
                width                   = param_width,
                width_mm                = param_width_mm,
                width_measured          = param_width_measured,
                width_max               = param_width_max,
                `length`                = param_length,
                length_mm               = param_length_mm,
                length_measured         = param_length_measured,
                length_max              = param_length_max,
                unitweight              = param_unitweight,
                unitweight_ton          = param_unitweight_ton,
                price                   = param_price,
                `value`                 = param_value,
                supplier_id             = param_supplier_id,
                supplier_invoice_no     = param_supplier_invoice_no,
                supplier_invoice_date   = null,
                purchase_price          = param_purchase_price,
                purchase_value          = param_purchase_value,
                purchase_currency       = param_purchase_currency,
                in_ddt_number           = '',
                in_ddt_date             = null,
                in_ddt_company_id       = param_in_ddt_company_id,
                ddt_number              = '',
                ddt_date                = null,
                ddt_company_id          = param_ddt_company_id,
                deliverytime_id         = param_deliverytime_id,
                notes                   = param_notes,
                internal_notes          = param_internal_notes,
                owner_id                = param_owner_id,
                status_id               = param_status_id,
                is_virtual              = param_is_virtual,
                is_available            = 1,
                is_deleted              = 0,
                is_conflicted           = 0,
                is_locked               = 0,
                mill                    = param_mill,
                system                  = param_system,
                unitweight_measured     = param_unitweight_measured,
                unitweight_weighed      = param_unitweight_weighed,
                current_cost            = param_current_cost,
                pl                      = param_pl,
                load_ready              = param_load_ready,
                is_from_order           = IF(param_stockholder_id > 0, 0, 1),
                order_id                = 0,
                tech_action             = '',
                created_at              = NOW(),
                created_by              = param_user_id,
                modified_at             = NOW(),
                modified_by             = param_user_id;
        
            SET param_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);
        
        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DELIMITER ;
