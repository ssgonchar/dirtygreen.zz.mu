delimiter $$

DROP PROCEDURE IF EXISTS `sp_ra_item_add`$$
CREATE PROCEDURE `sp_ra_item_add`(
	IN param_user_id INT,
	IN param_parent_id INT,
	IN param_ra_id INT,
	IN param_steelitem_id INT,
	IN param_status_id TINYINT
)
sp:
BEGIN
	DECLARE var_steelitem_owner_id INT DEFAULT 0;
	DECLARE var_ddt_id INT DEFAULT 0;
	DECLARE var_cmr_id INT DEFAULT 0;

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

    START TRANSACTION;

        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;

		SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_steelitem_id, 
			weight    		= var_steelitem_unitweight_ton,
			weighed_weight	= var_steelitem_unitweight_ton,
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_steelitem_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_steelitem_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;
        
        END IF;
    
    COMMIT;

END$$

delimiter ;
