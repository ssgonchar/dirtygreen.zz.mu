ALTER TABLE `ddt` ADD UNIQUE `ix-ra-owner` ( `ra_id` , `owner_id` ) ;
ALTER TABLE `cmr` ADD UNIQUE `ix-ra-owner` ( `ra_id` , `owner_id` ) ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_ra_item_add$$
CREATE PROCEDURE sp_ra_item_add(
	IN param_user_id INT,
	IN param_parent_id INT,
	IN param_ra_id INT,
	IN param_steelitem_id INT,
	IN param_status_id TINYINT
)
sp:
BEGIN
	DECLARE var_ddt_id INT DEFAULT 0;
	DECLARE var_cmr_id INT DEFAULT 0;

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

	DECLARE var_ra_stockholder_id 			INT DEFAULT 0;
	DECLARE var_steelitem_stockholder_id	INT DEFAULT 0;
	DECLARE var_steelitem_owner_id 			INT DEFAULT 0;

    START TRANSACTION;
		
        SET var_ra_stockholder_id = IFNULL((SELECT stockholder_id FROM ra WHERE id = param_ra_id), 0);
		
		SELECT 
            IFNULL(stockholder_id, 0), 
            IFNULL(owner_id, 0)
		INTO 
            var_steelitem_stockholder_id, 
            var_steelitem_owner_id
		FROM steelitems
		WHERE id = param_steelitem_id;

		IF var_steelitem_stockholder_id != var_ra_stockholder_id OR var_steelitem_owner_id = 0
		THEN
			LEAVE sp;
		END IF;


        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;

		SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = param_steelitem_id), 0);
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_steelitem_id, 
			weight    		= var_steelitem_unitweight_ton,
			weighed_weight	= var_steelitem_unitweight_ton,
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_steelitem_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_steelitem_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;


            CALL sp_ra_item_save_ddt(param_user_id, param_steelitem_id, param_ra_id);
            CALL sp_ra_items_recalculate_ww(param_ra_id);
            CALL sp_ra_update_related_docs(param_user_id, param_ra_id);
        
        END IF;
    
    COMMIT;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_item_remove$$
CREATE PROCEDURE sp_ra_item_remove(param_user_id INT, param_ra_id INT, param_ra_item_id INT, param_status_id TINYINT)
sp:
BEGIN
	DECLARE var_parent_id 			INT 	DEFAULT 0;
	DECLARE var_steelitem_id 		INT 	DEFAULT 0;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT 0;
	DECLARE var_steelitem_order_id	INT		DEFAULT 0;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 5;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';


    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT
        *
    FROM ra_items
    WHERE id = param_ra_item_id;


	SELECT
		parent_id,
		steelitem_id
	INTO
		var_parent_id,
		var_steelitem_id
	FROM ra_items
	WHERE id = param_ra_item_id;

    IF var_parent_id = 0
    THEN
    
        DELETE FROM ra_items 
        WHERE ra_id = param_ra_id 
        AND parent_id = param_ra_item_id;

        
        UPDATE steelitems
        SET
            status_id   = param_status_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = var_steelitem_id
        AND order_id > 0
        AND status_id = ITEM_STATUS_RELEASED;

        
        SET var_attachment_ids = (
            SELECT 
                GROUP_CONCAT(attachment_id SEPARATOR ",") 
            FROM attachment_objects 
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id
        );

        SET @var_stmt := CONCAT("
            DELETE FROM attachment_objects 
            WHERE object_alias = 'steelitem'
            AND object_id = " , var_steelitem_id, 
            " AND attachment_id IN (", var_attachment_ids, ")
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;    

        CALL sp_ra_item_remove_ddt(param_user_id, var_steelitem_id, param_ra_id);
        CALL sp_ra_items_recalculate_ww(param_ra_id);

    END IF;
    
    DELETE FROM ra_items 
    WHERE id = param_ra_item_id;

    CALL sp_ra_update_related_docs(param_user_id, param_ra_id);
    
END
$$

DROP PROCEDURE IF EXISTS sp_ra_save$$
CREATE PROCEDURE sp_ra_save(
	IN param_user_id INT,
	IN param_id INT,
	IN param_stockholder_id INT,
	IN param_company_id INT,
	IN param_truck_number VARCHAR(50),
	IN param_destination VARCHAR(200),
	IN param_loading_date VARCHAR(200),
	IN param_marking TEXT,
	IN param_dunnaging TEXT,
	IN param_status_id TINYINT,
	IN param_max_weight DECIMAL(10,4),
	IN param_weighed_weight DECIMAL(10,4),
	IN param_ddt_number VARCHAR(50),
	IN param_ddt_date TIMESTAMP,
    IN param_ddt_instructions TEXT,
	IN param_coupon TEXT,
	IN param_notes TEXT,
	IN param_consignee TEXT,
	IN param_consignee_ref VARCHAR(200),
    IN param_mm_dimensions TINYINT
)
sp:
BEGIN
	
    DECLARE var_weighed_weight  DECIMAL(10, 4) DEFAULT 0;
    DECLARE var_destination     VARCHAR(200) DEFAULT '';

    
    IF param_id = 0
	THEN
		START TRANSACTION;

			INSERT INTO ra
			SET
				`number`			= IFNULL((SELECT MAX(ra2.`number`)+1 FROM ra AS ra2 LIMIT 1), 1),
				`stockholder_id`	= param_stockholder_id,
				`company_id`		= param_company_id,
				`truck_number`		= param_truck_number,
				`destination`		= param_destination,
				`loading_date`		= param_loading_date,
				`marking`			= param_marking,
				`dunnaging`			= param_dunnaging,
				`status_id`			= param_status_id,
				`max_weight`		= param_max_weight,
				`weighed_weight`	= param_weighed_weight,
				`ddt_number`		= param_ddt_number,
				`ddt_date`			= param_ddt_date,
                `ddt_instructions`  = param_ddt_instructions,
				`coupon`  			= param_coupon,
				`notes`  			= param_notes,
				`consignee`  		= param_consignee,
				`consignee_ref`		= param_consignee_ref,
				`mm_dimensions`     = param_mm_dimensions,
				`created_at`		= NOW(),
				`created_by`		= param_user_id,
				`modified_at`		= NOW(),
				`modified_by`		= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra WHERE `created_by` = param_user_id);

		COMMIT;
	ELSE
		
        SELECT 
            weighed_weight,
            destination
        INTO
            var_weighed_weight,
            var_destination
        FROM ra 
        WHERE id = param_id;


        UPDATE ra
		SET
			`company_id`		= param_company_id,
			`truck_number`		= param_truck_number,
			`destination`		= param_destination,
			`loading_date`		= param_loading_date,
			`marking`			= param_marking,
			`dunnaging`			= param_dunnaging,
			`max_weight`		= param_max_weight,
			`weighed_weight`	= param_weighed_weight,
			`ddt_number`		= param_ddt_number,
			`ddt_date`			= param_ddt_date,
            `ddt_instructions`  = param_ddt_instructions,
			`coupon`  			= param_coupon,
			`notes`  			= param_notes,
			`consignee`  		= param_consignee,
			`consignee_ref`		= param_consignee_ref,
			`mm_dimensions`     = param_mm_dimensions,
			`modified_at`		= NOW(),
			`modified_by`		= param_user_id
		WHERE id = param_id;


        IF var_weighed_weight != param_weighed_weight
        THEN
            CALL sp_ra_items_recalculate_ww(param_id);
        END IF;

        IF var_destination != param_destination
        THEN
            CALL sp_ra_update_related_docs(param_user_id, param_id);
        END IF;
        
	END IF;

	SELECT param_id AS ra_id;
END
$$

DROP PROCEDURE IF EXISTS sp_ra_set_primary_item$$
CREATE PROCEDURE sp_ra_set_primary_item(param_user_id INT, param_ra_id INT, param_ra_item_id INT)
sp:
BEGIN

    DECLARE var_parent_id           INT DEFAULT 0;
    DECLARE var_prev_steelitem_id   INT DEFAULT 0;
    DECLARE var_new_steelitem_id    INT DEFAULT 0;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';

	DECLARE var_steelitem_unitweight_ton	DECIMAL(10,4) DEFAULT 0;

    IF NOT EXISTS (SELECT * FROM ra_items WHERE ra_id = param_ra_id AND id = param_ra_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    SET var_parent_id = (SELECT parent_id FROM ra_items WHERE id = param_ra_item_id);

    IF var_parent_id = 0 
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;        
    END IF;


    SET var_prev_steelitem_id   = (SELECT steelitem_id FROM ra_items WHERE id = var_parent_id);
    SET var_new_steelitem_id    = (SELECT steelitem_id FROM ra_items WHERE id = param_ra_item_id);

	SET var_steelitem_unitweight_ton = IFNULL((SELECT unitweight_ton FROM steelitems WHERE id = var_new_steelitem_id), 0);    

    UPDATE ra_items
    SET 
        parent_id		= 0,
		weight			= var_steelitem_unitweight_ton,
		weighed_weight	= var_steelitem_unitweight_ton
    WHERE id = param_ra_item_id;
    
    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE id = var_parent_id;

    UPDATE ra_items 
    SET 
        parent_id		= param_ra_item_id,
		weight			= 0,
		weighed_weight	= 0
    WHERE parent_id = var_parent_id
    AND ra_id = param_ra_id;

    SET var_attachment_ids = (
        SELECT 
            GROUP_CONCAT(attachment_id SEPARATOR ",") 
        FROM attachment_objects 
        WHERE object_alias = 'ra'
        AND object_id = param_ra_id
    );

    SET @var_stmt := CONCAT("
        DELETE FROM attachment_objects 
        WHERE object_alias = 'steelitem'
        AND object_id = " , var_prev_steelitem_id, 
        " AND attachment_id IN (", var_attachment_ids, ")
    ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

    INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
    SELECT
        attachment_id, 
        `type`,
        'steelitem',
        var_new_steelitem_id,
        NOW(),
        param_user_id
    FROM attachment_objects
    WHERE object_alias = 'ra'
    AND object_id = param_ra_id;


    CALL sp_ra_item_remove_ddt(param_user_id, var_prev_steelitem_id, param_ra_id);
    CALL sp_ra_items_recalculate_ww(param_ra_id);
    CALL sp_ra_update_related_docs(param_user_id, param_ra_id);

    
    SELECT 
        var_prev_steelitem_id   AS prev_steelitem_id,
        var_new_steelitem_id    AS new_steelitem_id;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_update_related_docs$$
CREATE PROCEDURE sp_ra_update_related_docs(param_user_id INT, param_ra_id INT)
sp:
BEGIN
    
    DECLARE var_ra_item_ids VARCHAR(4000) DEFAULT '';

    SET var_ra_item_ids = (
        SELECT
            GROUP_CONCAT(DISTINCT steelitems.owner_id SEPARATOR ",")            
        FROM ra_items
        JOIN steelitems ON ra_items.steelitem_id = steelitems.id
        WHERE ra_items.ra_id = param_ra_id
        AND ra_items.parent_id = 0
    );

    
    IF EXISTS (SELECT * FROM cmr WHERE ra_id = param_ra_id)
    THEN

        UPDATE cmr
        SET
            is_outdated = 1
        WHERE ra_id = param_ra_id;

        
        SET @var_stmt = CONCAT("
            UPDATE cmr
            SET
                is_deleted = 0
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            UPDATE cmr
            SET
                is_deleted = 1
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id NOT IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            INSERT IGNORE INTO cmr(ra_id, owner_id, number, is_outdated, created_at, created_by)
            SELECT
                ", param_ra_id, ",
                id,
                0,
                1,
                NOW(),
                ", param_user_id, "
            FROM companies
            WHERE id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
    END IF;


    IF EXISTS (SELECT * FROM ddt WHERE ra_id = param_ra_id)
    THEN

        UPDATE ddt
        SET
            is_outdated = 1
        WHERE ra_id = param_ra_id;

        
        SET @var_stmt = CONCAT("
            UPDATE ddt
            SET
                is_deleted = 0
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id IN (", var_ra_item_ids, ");
        ");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET @var_stmt = CONCAT("
            UPDATE ddt
            SET
                is_deleted = 1
            WHERE ra_id = ", param_ra_id, " 
            AND owner_id NOT IN (", var_ra_item_ids, ");
        ");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;

        SET @var_stmt = CONCAT("
            INSERT IGNORE INTO ddt(ra_id, owner_id, number, is_outdated, created_at, created_by)
            SELECT
                ", param_ra_id, ",
                id,
                0,
                1,
                NOW(),
                ", param_user_id, "
            FROM companies
            WHERE id IN (", var_ra_item_ids, ");
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
    END IF;

END
$$

DELIMITER ;
