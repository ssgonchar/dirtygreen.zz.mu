-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 29.11.2012 3:18:01
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_ra_item_save_ddt$$
CREATE PROCEDURE sp_ra_item_save_ddt(param_user_id INT, param_steelitem_id INT, param_ra_id INT)
sp:
BEGIN

    DECLARE var_ddt_number      CHAR(50) DEFAULT '';
    DECLARE var_ddt_date        TIMESTAMP DEFAULT NULL;
    DECLARE var_ddt_company_id  INT DEFAULT 0;

    
    IF NOT EXISTS (SELECT * FROM ra WHERE id = param_ra_id)
    THEN
        LEAVE sp;
    END IF;


    SELECT 
        ddt_number,
        ddt_date,
        stockholder_id
    INTO
        var_ddt_number,
        var_ddt_date,
        var_ddt_company_id
    FROM ra 
    WHERE id = param_ra_id;


    IF TRIM(var_ddt_number) = ''
    THEN
        
        DELETE FROM steelitem_ddts
        WHERE source_alias = 'ra' 
        AND source_id = param_ra_id
        AND steelitem_id = param_steelitem_id;

    ELSEIF EXISTS (SELECT * FROM steelitem_ddts WHERE source_alias = 'ra' AND source_id = param_ra_id AND steelitem_id = param_steelitem_id)
    THEN

        UPDATE steelitem_ddts
        SET
            ddt_number  = var_ddt_number,
            ddt_date    = var_ddt_date,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE source_alias = 'ra' 
        AND source_id = param_ra_id
        AND steelitem_id = param_steelitem_id;

    ELSE

        INSERT INTO steelitem_ddts
        SET
            source_alias    = 'ra',
            source_id       = param_ra_id,
            steelitem_id    = param_steelitem_id,
            ddt_number      = var_ddt_number,
            ddt_date        = var_ddt_date,
            ddt_company_id  = var_ddt_company_id,
            created_at      = NOW(),
            created_by      = param_user_id;
        
    END IF;


    CALL sp_steelitem_update_ddt(param_user_id, param_steelitem_id);

END
$$

DROP PROCEDURE IF EXISTS sp_ra_save$$
CREATE PROCEDURE sp_ra_save(
	IN param_user_id INT,
	IN param_id INT,
	IN param_stockholder_id INT,
	IN param_company_id INT,
	IN param_truck_number VARCHAR(50),
	IN param_destination VARCHAR(200),
	IN param_loading_date VARCHAR(200),
	IN param_marking TEXT,
	IN param_dunnaging TEXT,
	IN param_status_id TINYINT,
	IN param_max_weight DECIMAL(10,4),
	IN param_weighed_weight DECIMAL(10,4),
	IN param_ddt_number VARCHAR(50),
	IN param_ddt_date TIMESTAMP,
    IN param_ddt_instructions TEXT,
	IN param_coupon TEXT,
	IN param_notes TEXT,
	IN param_consignee TEXT,
	IN param_consignee_ref VARCHAR(200),
    IN param_mm_dimensions TINYINT
)
sp:
BEGIN
	
    DECLARE var_weighed_weight  DECIMAL(10, 4) DEFAULT 0;
    DECLARE var_destination     VARCHAR(200) DEFAULT '';

    
    IF param_id = 0
	THEN
		START TRANSACTION;

			INSERT INTO ra
			SET
				`number`			= IFNULL((SELECT MAX(ra2.`number`)+1 FROM ra AS ra2 LIMIT 1), 1),
				`stockholder_id`	= param_stockholder_id,
				`company_id`		= param_company_id,
				`truck_number`		= param_truck_number,
				`destination`		= param_destination,
				`loading_date`		= param_loading_date,
				`marking`			= param_marking,
				`dunnaging`			= param_dunnaging,
				`status_id`			= param_status_id,
				`max_weight`		= param_max_weight,
				`weighed_weight`	= param_weighed_weight,
				`ddt_number`		= param_ddt_number,
				`ddt_date`			= param_ddt_date,
                `ddt_instructions`  = param_ddt_instructions,
				`coupon`  			= param_coupon,
				`notes`  			= param_notes,
				`consignee`  		= param_consignee,
				`consignee_ref`		= param_consignee_ref,
				`mm_dimensions`     = param_mm_dimensions,
				`created_at`		= NOW(),
				`created_by`		= param_user_id,
				`modified_at`		= NOW(),
				`modified_by`		= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra WHERE `created_by` = param_user_id);

		COMMIT;
	ELSE
		
        SELECT 
            weighed_weight,
            destination
        INTO
            var_weighed_weight,
            var_destination
        FROM ra 
        WHERE id = param_id;


        UPDATE ra
		SET
			`company_id`		= param_company_id,
			`truck_number`		= param_truck_number,
			`destination`		= param_destination,
			`loading_date`		= param_loading_date,
			`marking`			= param_marking,
			`dunnaging`			= param_dunnaging,
			`max_weight`		= param_max_weight,
			`weighed_weight`	= param_weighed_weight,
			`ddt_number`		= param_ddt_number,
			`ddt_date`			= param_ddt_date,
            `ddt_instructions`  = param_ddt_instructions,
			`coupon`  			= param_coupon,
			`notes`  			= param_notes,
			`consignee`  		= param_consignee,
			`consignee_ref`		= param_consignee_ref,
			`mm_dimensions`     = param_mm_dimensions,
			`modified_at`		= NOW(),
			`modified_by`		= param_user_id
		WHERE id = param_id;


        IF var_weighed_weight != param_weighed_weight
        THEN
            CALL sp_ra_items_recalculate_ww(param_id);
        END IF;

        IF var_destination != param_destination
        THEN
            CALL sp_ra_update_related_docs(param_id);
        END IF;
        
	END IF;

	SELECT param_id AS ra_id;
END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_update_ddt$$
CREATE PROCEDURE sp_steelitem_update_ddt(IN param_user_id INT, IN param_steelitem_id INT)
BEGIN

    DECLARE var_ddt_number      CHAR(50) DEFAULT '';
    DECLARE var_ddt_date        TIMESTAMP DEFAULT NULL;
    DECLARE var_ddt_company_id  INT DEFAULT 0;


    SELECT 
        ddt_number,
        ddt_date,
        ddt_company_id
    INTO
        var_ddt_number,
        var_ddt_date,
        var_ddt_company_id
    FROM steelitem_ddts
    WHERE steelitem_id = param_steelitem_id
    ORDER BY id DESC
    LIMIT 1;


    UPDATE steelitems
    SET
        ddt_number      = var_ddt_number,
        ddt_date        = var_ddt_date,
        ddt_company_id  = var_ddt_company_id,
        modified_at     = NOW(),
        modified_by     = param_user_id        
    WHERE id = param_steelitem_id;

END
$$

DELIMITER ;
