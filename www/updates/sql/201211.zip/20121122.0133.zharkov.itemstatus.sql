-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 22.11.2012 1:32:28
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_order_get_quick_by_ids$$
CREATE PROCEDURE sp_order_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    DECLARE ITEM_STATUS_DELIVERED   TINYINT DEFAULT 6;
    DECLARE ITEM_STATUS_INVOICED    TINYINT DEFAULT 7;


    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM steelitems WHERE order_id = orders.id) AS qtty,
            (SELECT COUNT(*) FROM steelitems WHERE order_id = orders.id AND status_id IN (", ITEM_STATUS_DELIVERED, ",", ITEM_STATUS_INVOICED, ")) AS qtty_delivered,
            (SELECT SUM(unitweight) FROM steelitems WHERE order_id = orders.id) AS weight,
            IFNULL((SELECT SUM(unitweight) FROM steelitems WHERE order_id = orders.id AND status_id IN (", ITEM_STATUS_DELIVERED, ",", ITEM_STATUS_INVOICED, ")), 0) AS weight_delivered,
            (SELECT SUM(value) FROM order_positions WHERE order_id = orders.id) AS value,
            TIMESTAMPDIFF(DAY, CONCAT(YEAR(NOW()), '-', MONTH(NOW()), '-', DAY(NOW())), alert_date) AS days_to_alert
        FROM orders
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove_item$$
CREATE PROCEDURE sp_order_remove_item(param_user_id INT, param_order_id INT, param_item_id INT, param_leave_history BOOLEAN)
sp:
BEGIN


    DECLARE var_position_id     INT DEFAULT 0;
    DECLARE var_parent_id       INT DEFAULT 0;
    DECLARE var_is_from_order   INT DEFAULT 0;
    DECLARE ITEM_STATUS_STOCK   TINYINT DEFAULT 3;


    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND order_id = param_order_id)
    THEN
        SELECT -2 AS ErrorCode, 'sp_order_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SELECT 
        steelposition_id,
        parent_id,
        is_from_order
    INTO
        var_position_id,
        var_parent_id,
        var_is_from_order
    FROM steelitems 
    WHERE id = param_item_id;


    IF var_is_from_order > 0
    THEN
        
        
        SELECT
            id AS steelitem_id,
            steelposition_id
        FROM steelitems
        WHERE id = param_item_id;


        UPDATE steelitem_properties SET modified_at = NOW(), modified_by = param_user_id WHERE item_id = param_item_id;
        DELETE FROM steelitem_properties WHERE item_id = param_item_id;
            
        UPDATE steelitems SET modified_at = NOW(), modified_by = param_user_id WHERE id = param_item_id;
        DELETE FROM steelitems WHERE id = param_item_id;

    ELSE
        
        UPDATE steelitems
        SET
            is_available    = 1,
            order_id        = 0,
            status_id       = ITEM_STATUS_STOCK,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_item_id;


        IF var_parent_id = 0
        THEN

            IF NOT EXISTS (SELECT * FROM steelitems WHERE parent_id = param_item_id AND order_id > 0)
            THEN
                
                UPDATE steelitems
                SET
                    is_locked       = sf_item_check_lock(id, parent_id),
                    is_conflicted   = sf_item_check_conflict(id, parent_id)
                WHERE id = param_item_id
                OR parent_id = param_item_id;


                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id
                OR parent_id = param_item_id;

            END IF;

        ELSE

            IF NOT EXISTS (SELECT * FROM steelitems WHERE (parent_id = var_parent_id OR id = var_parent_id) AND order_id > 0)
            THEN                
                
                UPDATE steelitems
                SET
                    is_locked       = sf_item_check_lock(id, parent_id),
                    is_conflicted   = sf_item_check_conflict(id, parent_id)
                WHERE parent_id = var_parent_id 
                OR id = var_parent_id;

                
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE parent_id = var_parent_id 
                OR id = var_parent_id;

            END IF;

        END IF;

    END IF;


    IF param_leave_history = FALSE AND NOT EXISTS (SELECT * FROM steelitems WHERE steelposition_id = var_position_id AND order_id = param_order_id)
    THEN

        DELETE FROM order_positions 
        WHERE order_id = param_order_id 
        AND position_id = var_position_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_update_item_status$$
CREATE PROCEDURE sp_order_update_item_status(param_user_id INT, param_order_id INT, param_item_id INT, param_status_id TINYINT)
BEGIN

    DECLARE ITEM_STATUS_DELIVERED   TINYINT DEFAULT 6;
    DECLARE ITEM_STATUS_INVOICED    TINYINT DEFAULT 7;


    UPDATE steelitems
    SET
        status_id   = param_status_id,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_item_id;

    SET param_status_id = IFNULL((SELECT MIN(status_id) FROM steelitems WHERE order_id = param_order_id), 0);

    UPDATE orders
    SET
        `status` =  CASE param_status_id 
                    WHEN ITEM_STATUS_DELIVERED THEN 'de'
                    WHEN ITEM_STATUS_INVOICED THEN 'co'
                    ELSE 'ip' END
    WHERE id = param_order_id;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_item_remove$$
CREATE PROCEDURE sp_ra_item_remove(param_user_id INT, param_ra_id INT, param_ra_item_id INT, param_status_id TINYINT)
sp:
BEGIN
	DECLARE var_parent_id 			INT 	DEFAULT 0;
	DECLARE var_steelitem_id 		INT 	DEFAULT 0;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT 0;
	DECLARE var_steelitem_order_id	INT		DEFAULT 0;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 5;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';


    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT
        *
    FROM ra_items
    WHERE id = param_ra_item_id;


	SELECT
		parent_id,
		steelitem_id
	INTO
		var_parent_id,
		var_steelitem_id
	FROM ra_items
	WHERE id = param_ra_item_id;

    IF var_parent_id = 0
    THEN
    
        DELETE FROM ra_items 
        WHERE ra_id = param_ra_id 
        AND parent_id = param_ra_item_id;

        
        UPDATE steelitems
        SET
            status_id   = param_status_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = var_steelitem_id
        AND order_id > 0
        AND status_id = ITEM_STATUS_RELEASED;

        
        SET var_attachment_ids = (
            SELECT 
                GROUP_CONCAT(attachment_id SEPARATOR ",") 
            FROM attachment_objects 
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id
        );

        SET @var_stmt := CONCAT("
            DELETE FROM attachment_objects 
            WHERE object_alias = 'steelitem'
            AND object_id = " , var_steelitem_id, 
            " AND attachment_id IN (", var_attachment_ids, ")
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;    

    END IF;
    
    DELETE FROM ra_items 
    WHERE id = param_ra_item_id;
    
END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_set_status$$
CREATE PROCEDURE sp_steelitem_set_status(param_user_id INT, param_item_id INT, param_status_id INT)
sp:
BEGIN

    DECLARE var_order_id        INT DEFAULT 0;
    DECLARE ITEM_STATUS_ORDERED INT DEFAULT 4;
    
    
    SET var_order_id = (SELECT order_id FROM steelitems WHERE id = param_item_id);

    IF (var_order_id > 0 AND param_status_id < ITEM_STATUS_ORDERED)
    OR (var_order_id = 0 AND param_status_id >= ITEM_STATUS_ORDERED)
    THEN
        SELECT -1 AS ErrorCode, 'sp_item_set_status' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT * FROM steelitems WHERE id = param_item_id;

    
    IF var_order_id > 0
    THEN

        CALL sp_order_update_item_status(param_user_id, var_order_id, param_item_id, param_status_id);

    ELSE

        UPDATE steelitems
        SET
            status_id   = param_status_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_item_id;

    END IF;

END
$$

DELIMITER ;
