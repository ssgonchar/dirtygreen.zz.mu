ALTER TABLE `steelitems` ADD INDEX `ix-report1` ( `is_available` , `is_virtual` , `is_deleted` , `order_id` , `stockholder_id` ) ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list_for_report$$
CREATE PROCEDURE sp_steelitem_get_list_for_report()
BEGIN

    SELECT
        id,
        stockholder_id,
        location_id,
        owner_id,
        unitweight,
        unitweight_ton,
        price,
        `value`,
        currency,
        weight_unit,
        purchase_price,
        purchase_value,
        purchase_currency
    FROM steelitems
    WHERE is_available = 1
    AND is_virtual = 0
    AND is_deleted = 0
    AND order_id = 0;

END
$$

DELIMITER ;
