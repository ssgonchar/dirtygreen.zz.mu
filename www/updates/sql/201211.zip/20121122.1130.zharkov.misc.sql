DROP TABLE IF EXISTS steelposition_items;
DROP TABLE IF EXISTS steelposition_items_history;

