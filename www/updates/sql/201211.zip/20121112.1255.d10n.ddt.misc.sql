delimiter $$

DROP PROCEDURE IF EXISTS `sp_ddt_save`$$
CREATE PROCEDURE `sp_ddt_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_num VARCHAR(20),
	IN param_buyer VARCHAR(500),
	IN param_delivery_point VARCHAR(500),
	IN param_date TIMESTAMP,
	IN param_iva VARCHAR(20),
	IN param_paymenttype_id INT,
	IN param_causale_id INT,
	IN param_porto_id INT,
	IN param_truck_number VARCHAR(20),
	IN param_transporter_id INT,
	IN param_weighed_weight DECIMAL(10,4),
	IN param_attachment_id INT
)
BEGIN
START TRANSACTION;

	IF param_id = 0
	THEN
		INSERT INTO ddt
		SET
			#`number`		= IFNULL((SELECT MAX(ddt2.`number`)+1 FROM ddt AS ddt2 LIMIT 1), 1),
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			created_at		= NOW(),
			created_by		= param_user_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		;
		SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by = param_user_id);
	ELSE
		UPDATE ddt
		SET
			`number`		= param_num,
			buyer			= param_buyer,
			delivery_point	= param_delivery_point,
			`date`			= param_date,
			iva				= param_iva,
			paymenttype_id	= param_paymenttype_id,
			causale_id		= param_causale_id,
			porto_id		= param_porto_id,
			truck_number	= param_truck_number,
			transporter_id	= param_transporter_id,
			weighed_weight	= param_weighed_weight,
			attachment_id	= param_attachment_id,
			modified_at		= NOW(),
			modified_by		= param_user_id
		WHERE
			id = param_id
		;
	END IF;
    
	
    
    SELECT param_id AS ddt_id;

COMMIT;
END$$

delimiter ;
