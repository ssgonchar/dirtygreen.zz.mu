ALTER TABLE  `ra_items` ADD UNIQUE  `ix-ra_items-items` (  `parent_id` ,  `ra_id` ,  `steelitem_id` );
