DROP TABLE IF EXISTS `email_objects`;
CREATE TABLE `email_objects` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `emails_raw_id` INT DEFAULT NULL COMMENT 'ID (emails_raw.id) письма',
    `object_alias` VARCHAR(20) NULL COMMENT 'ALIAS объекта, для которого прикрепляется письмо [biz,person,company]',
    `object_id` INT NULL COMMENT 'ID объекта, для которого прикрепляется письмо',
    PRIMARY KEY (`id`)
)
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci
COMMENT = 'Таблица для связи email-сообщений с сущностями(BIZ,Persons,)';
