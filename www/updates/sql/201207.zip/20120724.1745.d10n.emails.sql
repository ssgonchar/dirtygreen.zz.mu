SET NAMES 'utf8';

DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_email_raw_get_by_id`$$
CREATE PROCEDURE `sp_email_raw_get_by_id`(IN param_id INT(11))
sp:
BEGIN

    SELECT 
        er.*
    FROM emails_raw AS er
    WHERE
        er.id = param_id
    ;
END$$


DROP PROCEDURE IF EXISTS `sp_email_raw_get_list_by_ids`$$
CREATE PROCEDURE `sp_email_raw_get_list_by_ids`(IN param_ids VARCHAR(2000))
sp:
BEGIN
    IF param_ids = '' 
    THEN
        LEAVE sp;
    END IF;

    SET @var_stmt = CONCAT("
        SELECT 
            er.*
        FROM emails_raw AS er
        WHERE
            er.id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;
END$$


DROP PROCEDURE IF EXISTS `sp_email_raw_save`$$
CREATE PROCEDURE `sp_email_raw_save`(
    IN param_user_id INT,
    IN param_username VARCHAR(200),
    IN param_mailbox_name VARCHAR(200),
    IN param_message_num INT(11),
    IN param_sender_email VARCHAR(200),
    IN param_recipient_email VARCHAR(200),
    IN param_date DATETIME,
    IN param_date_mail DATETIME,
    IN param_udate INT(11),
    IN param_subject VARCHAR(1000),
    IN param_text_plain TEXT,
    IN param_text_html TEXT,
    IN param_size_plain INT(11),
    IN param_size_html INT(11),
    IN param_recent TINYINT(4),
    IN param_unseen TINYINT(4),
    IN param_flagged TINYINT(4),
    IN param_answered TINYINT(4),
    IN param_deleted TINYINT(4),
    IN param_draft TINYINT(4),
    IN param_is_parsed TINYINT(4),
    IN param_has_attachments TINYINT(4),
    IN param_status_id TINYINT(4)
)
sp:
BEGIN
    DECLARE var_id INT DEFAULT 0;

    SET var_id = IFNULL((SELECT id FROM emails_raw WHERE username = param_username AND mailbox_name = param_mailbox_name AND message_num = param_message_num), var_id);
    
    IF var_id = 0
    THEN
        INSERT INTO emails_raw
        SET
            username        = param_username,
            mailbox_name    = param_mailbox_name,
            message_num     = param_message_num,
            sender_email    = param_sender_email,
            recipient_email = param_recipient_email,
            date            = param_date,
            date_mail       = param_date_mail,
            udate           = param_udate,
            subject         = param_subject,
            text_plain      = param_text_plain,
            text_html       = param_text_html,
            size_plain      = param_size_plain,
            size_html       = param_size_html,
            recent          = param_recent,
            unseen          = param_unseen,
            flagged         = param_flagged,
            answered        = param_answered,
            deleted         = param_deleted,
            draft           = param_draft,
            is_parsed       = param_is_parsed,
            has_attachments = param_has_attachments,
            status_id       = param_status_id,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        ;
        SET var_id = (SELECT MAX(id) FROM emails_raw WHERE created_by = param_user_id);
    ELSE
        SELECT -1 AS 'ErrorCode', 'email_raw_save' AS 'ErrorAlias';
        LEAVE sp;

        UPDATE emails_raw
        SET
            -- username        = param_username,
            -- mailbox_name    = param_mailbox_name,
            -- message_num     = param_message_num,
            sender_email    = param_sender_email,
            recipient_email = param_recipient_email,
            date            = param_date,
            date_mail       = param_date_mail,
            udate           = param_udate,
            subject         = param_subject,
            text_plain      = param_text_plain,
            text_html       = param_text_html,
            size_plain      = param_size_plain,
            size_html       = param_size_html,
            recent          = param_recent,
            unseen          = param_unseen,
            flagged         = param_flagged,
            answered        = param_answered,
            deleted         = param_deleted,
            draft           = param_draft,
            is_parsed       = param_is_parsed,
            has_attachments = param_has_attachments,
            status_id       = param_status_id,
            -- created_at      = NOW(),
            -- created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE
            id = var_id
        ;
    END IF;

    CALL sp_email_raw_get_by_id(var_id);
END$$


DELIMITER ;