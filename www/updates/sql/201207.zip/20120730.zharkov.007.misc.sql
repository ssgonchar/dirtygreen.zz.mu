-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 30.07.2012 17:46:41
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_remove$$
CREATE PROCEDURE sp_steelitem_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    DECLARE var_parent_id INT DEFAULT 0;

    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_remove' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM steelitems WHERE id = param_id AND is_locked = 1)
    THEN
        SELECT -2 AS ErrorCode, 'sp_steelitem_remove' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM steelitems WHERE parent_id = param_id AND is_locked = 1)
    THEN
        SELECT -2 AS ErrorCode, 'sp_steelitem_remove' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SET var_parent_id = (SELECT parent_id FROM steelitems WHERE id = param_id);


    IF var_parent_id = 0
    THEN
        
        SELECT 
            id AS steelitem_id,
            steelposition_id,
            order_id
        FROM steelitems
        WHERE parent_id = param_id
        OR id = param_id;

        DELETE FROM steelitems WHERE parent_id = param_id;
        DELETE FROM steelitems WHERE id = param_id;

    ELSE
        
        SELECT 
            id AS steelitem_id,
            steelposition_id,
            order_id 
        FROM steelitems
        WHERE parent_id = var_parent_id 
        OR id = var_parent_id;
        
        DELETE FROM steelitems WHERE id = param_id;

        UPDATE steelitems
        SET
            is_locked       = sf_item_check_lock(id, parent_id),
            is_conflicted   = sf_item_check_conflict(id, parent_id)
        WHERE parent_id = var_parent_id 
        OR id = var_parent_id;

    END IF;

END
$$

DELIMITER ;
