ALTER TABLE `biz_companies` ADD INDEX `ix-biz_companies-biz_id` ( `biz_id` ) ;


DROP TABLE IF EXISTS emails;
CREATE TABLE emails(
    id INT(11) NOT NULL AUTO_INCREMENT,
    email_raw_id INT(11) DEFAULT NULL,
    type_id TINYINT(4) DEFAULT NULL COMMENT '1 - INBOX, 2 - OUTBOX, 3 - DRAFT',
    object_alias CHAR(20) DEFAULT NULL,
    object_id INT(11) DEFAULT NULL,
    sender_address VARCHAR(250) DEFAULT NULL,
    recipient_address VARCHAR(1000) DEFAULT NULL,
    `to` VARCHAR(250) DEFAULT NULL COMMENT 'Company title',
    attention VARCHAR(250) DEFAULT NULL COMMENT 'Person name',
    subject VARCHAR(250) DEFAULT NULL,
    our_ref VARCHAR(250) DEFAULT NULL COMMENT 'Biz ref',
    your_ref VARCHAR(250) DEFAULT NULL COMMENT 'Customer ref',
    title VARCHAR(1000) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    signature VARCHAR(250) DEFAULT NULL,
    number INT(11) DEFAULT NULL COMMENT 'Author email number',
    date_mail TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT NULL,
    created_by INT(11) DEFAULT NULL,
    modified_at TIMESTAMP NULL DEFAULT NULL,
    modified_by INT(11) DEFAULT NULL,
    sent_at TIMESTAMP NULL DEFAULT NULL,
    sent_by INT(11) DEFAULT NULL,
    PRIMARY KEY (id))
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;


DROP TABLE IF EXISTS email_delivered;
CREATE TABLE email_delivered(
    id INT(11) NOT NULL AUTO_INCREMENT,
    email_id INT(11) DEFAULT NULL,
    user_id INT(11) DEFAULT NULL,
    read_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id))
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;


DROP TABLE IF EXISTS email_objects;
CREATE TABLE email_objects(
    id INT(11) NOT NULL AUTO_INCREMENT,
    email_id INT(11) DEFAULT NULL COMMENT 'ID (emails.id) письма',
    object_alias VARCHAR(20) DEFAULT NULL COMMENT 'ALIAS объекта, для которого прикрепляется письмо [biz,person,company]',
    object_id INT(11) DEFAULT NULL COMMENT 'ID объекта, для которого прикрепляется письмо',
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    created_by INT(11) DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE INDEX IX_email_objects (object_id, object_alias, email_id))
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Таблица для связи email-сообщений с сущностями(BIZes,Persons';
