-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 18.07.2012 18:55:16
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS deprecated_sp_active_user_get_list_by_ids$$
CREATE PROCEDURE deprecated_sp_active_user_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_active_user_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(
        "SELECT 
            user_id AS id,
            visited_at,
            online_at,
            last_message_id
        FROM active_users
        WHERE user_id IN (", param_ids, ")
        ORDER BY id
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS deprecated_sp_order_save_positions_from_stock$$
CREATE PROCEDURE deprecated_sp_order_save_positions_from_stock(param_user_id INT, param_order_id INT, param_position_ids VARCHAR(1100))
sp:
BEGIN

    SET @var_stmt := CONCAT(  
        "
        INSERT IGNORE INTO order_positions(
            order_id,
            position_id,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            length,
            length_mm,
            unitweight,
            unitweight_ton,
            qtty,
            weight,
            weight_ton,
            price,
            value,
            notes,
            internal_notes,
            is_saved,
            created_at,
            created_by,
            modified_at,
            modified_by)
        SELECT ", param_order_id, ",  
            id,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            length,
            length_mm,
            unitweight,
            unitweight_ton,
            qtty,
            weight,
            weight_ton,
            price,
            value,
            notes,
            internal_notes,
            0,
            NOW(),
            ", param_user_id, ",
            NOW(),
            ", param_user_id, " 
        FROM steelpositions
        WHERE id IN (", param_position_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_active_user_add$$
CREATE PROCEDURE sp_active_user_add(param_user_id INT(11), param_visited_at INT(11), param_online_at INT(11))
BEGIN

    IF EXISTS (SELECT * FROM active_users WHERE user_id = param_user_id)
    THEN

        SELECT FALSE AS already_active;

    ELSE
        
        SELECT TRUE AS already_active;

        INSERT active_users
        SET 
            user_id         = param_user_id,
            visited_at      = param_visited_at,
            online_at       = param_online_at,
            last_message_id = IFNULL((SELECT last_message_id FROM users WHERE id = param_user_id), 0);

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_active_user_get_last_message$$
CREATE PROCEDURE sp_active_user_get_last_message(param_user_id INT)
BEGIN

    DECLARE var_message_id INT DEFAULT 0;

    
    SET var_message_id = IFNULL((SELECT last_message_id FROM active_users WHERE user_id = param_user_id), 0);
    
    IF var_message_id = 0
    THEN
        
        SET var_message_id = IFNULL((SELECT last_message_id FROM users WHERE id = param_user_id), 0);

    END IF;
    
    IF var_message_id = 0 OR (SELECT created_at FROM messages WHERE id = var_message_id) < CURDATE()
    THEN
        SET var_message_id = sf_chat_get_today_first_message();
    END IF;
    
    
    SELECT var_message_id AS last_message_id;

END
$$

DROP PROCEDURE IF EXISTS sp_active_user_get_list$$
CREATE PROCEDURE sp_active_user_get_list()
BEGIN

    SELECT 
        *
    FROM active_users;

END
$$

DROP PROCEDURE IF EXISTS sp_activity_get_list$$
CREATE PROCEDURE sp_activity_get_list(param_parent_id INT)
BEGIN

    SELECT
        id AS activity_id
    FROM activities
    WHERE (parent_id = param_parent_id OR param_parent_id = -1)
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_activity_get_list_by_ids$$
CREATE PROCEDURE sp_activity_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_activity_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM activities
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_activity_get_quick_by_ids$$
CREATE PROCEDURE sp_activity_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_activity_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            a.id,
            (SELECT COUNT(*) FROM activities WHERE parent_id = a.id) AS activities_count
        FROM activities AS a
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_activity_remove$$
CREATE PROCEDURE sp_activity_remove(IN param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM activities WHERE parent_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_activity_remove' AS ErrorAt;
        LEAVE sp;
    END IF;


    DELETE FROM activities WHERE id = param_id;
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_activity_save$$
CREATE PROCEDURE sp_activity_save(param_user_id INT, param_id INT, param_parent_id INT, param_title VARCHAR(250), param_alias VARCHAR(32))
sp:
BEGIN

    DECLARE var_level INT DEFAULT 0;
    
    IF EXISTS (SELECT * FROM activities WHERE id != param_id AND alias = param_alias)
    THEN
        SELECT -1 AS ErrorCode, 'sp_activity_save' AS ErrorAt;
        LEAVE sp;    
    END IF;
        
    SET var_level = IFNULL((SELECT `level` + 1 FROM activities WHERE id = param_parent_id), 0);
    
    IF param_id > 0
    THEN

        UPDATE activities
        SET
            parent_id   = param_parent_id,
            `level`     = var_level,
            title       = param_title,
            alias       = param_alias,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
        
            INSERT INTO activities
            SET
                parent_id   = param_parent_id,
                `level`     = var_level,
                title       = param_title,
                alias       = param_alias,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET param_id = (SELECT MAX(id) FROM activities WHERE created_by  = param_user_id);
        
        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_album_delete$$
CREATE PROCEDURE sp_album_delete(param_id INT)
BEGIN

    DELETE FROM album_pictures WHERE album_id = param_id;
    DELETE FROM albums WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_album_get_list$$
CREATE PROCEDURE sp_album_get_list()
BEGIN

    SELECT
        id AS album_id
    FROM albums;

END
$$

DROP PROCEDURE IF EXISTS sp_album_get_list_by_ids$$
CREATE PROCEDURE sp_album_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_album_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *,
            (SELECT id FROM attachments WHERE object_alias = 'album' AND object_id = albums.id AND is_main = 1) AS picture_id,
            (SELECT COUNT(*) FROM attachments WHERE object_alias = 'album' AND object_id = albums.id) AS pictures_count
        FROM albums
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_album_save$$
CREATE PROCEDURE sp_album_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_descriptin TEXT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM albums WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_album_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM albums WHERE id = param_id)
    THEN

        UPDATE albums
        SET
            title       = param_title,
            description = param_descriptin,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT albums
        SET
            title       = param_title,
            description = param_descriptin,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;

        SET param_id := (SELECT MAX(id) FROM albums WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_delete$$
CREATE PROCEDURE sp_attachment_delete(param_attachment_id INT)
BEGIN

    DECLARE var_object_alias CHAR(20) DEFAULT '';
    DECLARE var_object_id INT DEFAULT '';

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_by_id$$
CREATE PROCEDURE sp_attachment_get_by_id(param_id INT)
BEGIN

    SELECT

        *,
        (SELECT login FROM users WHERE id = attachments.created_by) AS created_by_login

    FROM attachments
    WHERE attachments.id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_by_secret_name$$
CREATE PROCEDURE sp_attachment_get_by_secret_name(IN param_secret_name CHAR(32))
sp:
BEGIN
    
    DECLARE var_attachment_id INT DEFAULT 0;

    SET var_attachment_id := IFNULL((SELECT id FROM attachments WHERE secret_name = param_secret_name), 0);

    IF var_attachment_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_attachment_get_by_secret_name' AS ErrorAt;
        LEAVE sp;
    END IF;

    SELECT var_attachment_id AS attachment_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_list$$
CREATE PROCEDURE sp_attachment_get_list(param_type CHAR(5), param_object_alias VARCHAR(100), param_object_id INT, param_from INT, param_count INT)
sp:
BEGIN


    SET @statement := CONCAT("
    SELECT
        id AS attachment_id
    FROM attachments 
    WHERE object_alias = ? AND object_id = ? ", 
    IF(param_type != '', "AND `type` = ? ", " "), 
    "ORDER BY created_at DESC 
    LIMIT ?, ?;");
    

    PREPARE stmt FROM @statement;

    SET @stmt_object_alias  = param_object_alias;
    SET @stmt_object_id     = param_object_id;
    SET @stmt_from          = param_from;
    SET @stmt_count         = param_count;

    IF param_type != ''
    THEN
            SET @stmt_type = param_type;
            EXECUTE stmt USING @stmt_object_alias, @stmt_object_id, @stmt_type, @stmt_from, @stmt_count;
    ELSE
            EXECUTE stmt USING @stmt_object_alias, @stmt_object_id, @stmt_from, @stmt_count;
    END IF;


    SELECT 
        COUNT(*) AS rows
    FROM attachments
    WHERE `type` = param_type
    AND object_alias = param_object_alias
    AND object_id = param_object_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_list_by_ids$$
CREATE PROCEDURE sp_attachment_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_attachment_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            a.*
        FROM attachments a
        WHERE a.id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_list_by_object_ids$$
CREATE PROCEDURE sp_attachment_get_list_by_object_ids(IN param_ids VARCHAR(1100), IN param_object_alias CHAR(20))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_message_get_list_by_object_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            object_id AS id,
            id AS attachment_id
        FROM attachments
        WHERE object_alias = '", param_object_alias, "' AND object_id IN (", param_ids, ");");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_list_for_object$$
CREATE PROCEDURE sp_attachment_get_list_for_object(param_object_alias VARCHAR(100), param_object_id INT, param_from INT, param_count INT)
sp:
BEGIN


    SET @statement := CONCAT("
    SELECT
        id AS attachment_id
    FROM attachments 
    WHERE object_alias = ? AND object_id = ? 
    ORDER BY created_at DESC 
    LIMIT ?, ?;");
    

    PREPARE stmt FROM @statement;

    SET @stmt_object_alias  = param_object_alias;
    SET @stmt_object_id     = param_object_id;
    SET @stmt_from          = param_from;
    SET @stmt_count         = param_count;

    EXECUTE stmt USING @stmt_object_alias, @stmt_object_id, @stmt_from, @stmt_count;


    SELECT 
        COUNT(*) AS rows
    FROM attachments
    WHERE attachments.object_alias = param_object_alias
    AND attachments.object_id = param_object_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_save$$
CREATE PROCEDURE sp_attachment_save(param_user_id INT, param_id INT, param_type CHAR(5), param_object_alias CHAR(20), param_object_id INT, param_content_type VARCHAR(50), 
                                    param_original_name VARCHAR(256), param_size INT, param_ext VARCHAR(50), param_status INT, 
                                    param_title VARCHAR(1000), param_description TEXT)
BEGIN

    IF EXISTS (SELECT id FROM attachments WHERE id = param_id)
    THEN
        
        UPDATE attachments
        SET
            content_type    = param_content_type, 
            secret_name     = CASE WHEN original_name != '' THEN CONCAT(sf_gen_secret_code(16), param_id) ELSE secret_name END, 
            original_name   = CASE WHEN original_name != '' THEN param_original_name ELSE original_name END, 
            size            = CASE WHEN original_name != '' THEN param_size ELSE size END, 
            ext             = CASE WHEN original_name != '' THEN param_ext ELSE ext END, 
            title           = param_title,
            description     = param_description,
            `status`        = param_status, 
            status_at       = NOW(),
            status_by       = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT INTO attachments 
        SET
            `type`          = param_type,
            object_alias    = param_object_alias, 
            object_id       = param_object_id, 
            content_type    = param_content_type, 
            secret_name     = '', 
            original_name   = param_original_name, 
            size            = param_size, 
            ext             = param_ext, 
            title           = param_title,
            description     = param_description,
            `status`        = param_status, 
            is_main         = 0,
            status_at       = NOW(),
            status_by       = param_user_id, 
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;
        

        SET param_id := (SELECT MAX(id) FROM attachments WHERE created_by = param_user_id);

        UPDATE attachments
        SET 
            secret_name = CONCAT(sf_gen_secret_code(16), param_id) 
        WHERE id = param_id;

    END IF;

    SELECT param_id AS attachment_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_set_as_main$$
CREATE PROCEDURE sp_attachment_set_as_main(param_id INT)
BEGIN

    DECLARE var_object_alias    CHAR(20) DEFAULT '';
    DECLARE var_object_id       INT DEFAULT 0;
    DECLARE var_type            CHAR(5) DEFAULT '';
    DECLARE var_prev_main_id    INT DEFAULT 0;

    
    SELECT 
        object_alias, 
        object_id, 
        `type` 
    INTO 
        var_object_alias, 
        var_object_id, 
        var_type 
    FROM attachments
    WHERE id = param_id;

    
    SET var_prev_main_id = (SELECT id FROM attachments WHERE object_alias = var_object_alias 
                            AND object_id = var_object_id AND `type` = var_type AND is_main > 0);
    

    UPDATE attachments SET is_main = 0 WHERE id = var_prev_main_id;
    UPDATE attachments SET is_main = 1 WHERE id = param_id;


    SELECT
        var_object_alias    AS object_alias, 
        var_object_id       AS object_id, 
        var_type            AS `type`,
        var_prev_main_id    AS prev_main_id;
        
END
$$

DROP PROCEDURE IF EXISTS sp_basket_add_position$$
CREATE PROCEDURE sp_basket_add_position(param_user_id INT, param_basket_id INT, param_position_id INT, param_qtty INT)
BEGIN

    IF EXISTS (SELECT * FROM basket_positions WHERE basket_id = param_basket_id AND position_id = param_position_id)
    THEN

        UPDATE basket_positions
        SET
            qtty        = qtty + param_qtty,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE basket_id = param_basket_id 
        AND position_id = param_position_id;

    ELSE

        INSERT INTO basket_positions
        SET
            basket_id   = param_basket_id,
            position_id = param_position_id,
            qtty        = param_qtty,
            modified_at = NOW(),
            modified_by = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_clear$$
CREATE PROCEDURE sp_basket_clear(param_user_id INT, param_basket_id INT)
BEGIN

    DELETE FROM baskets WHERE id = param_basket_id;
    DELETE FROM basket_positions WHERE basket_id = param_basket_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_clear_positions$$
CREATE PROCEDURE sp_basket_clear_positions(param_user_id INT, param_basket_id INT)
BEGIN

    DELETE FROM basket_positions WHERE basket_id = param_basket_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_get$$
CREATE PROCEDURE sp_basket_get(param_user_id INT, param_session_id VARCHAR(64), param_stock_id INT)
BEGIN

    IF NOT EXISTS (SELECT * FROM baskets WHERE stock_id = param_stock_id AND session_id = param_session_id)
    THEN

        DELETE FROM basket_positions WHERE basket_id IN (SELECT id FROM baskets WHERE stock_id = param_stock_id AND user_id = param_user_id);
        DELETE FROM baskets WHERE stock_id = param_stock_id AND user_id = param_user_id;

        INSERT INTO baskets
        SET
            stock_id        = param_stock_id,
            session_id      = param_session_id,
            user_id         = param_user_id,
            buyer_ref       = '',
            delivery_point  = '',
            delivery_town   = '',
            delivery_date   = '',
            description     = '',
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

    END IF;


    SELECT 
        *
    FROM baskets
    WHERE stock_id = param_stock_id
    AND session_id = param_session_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_get_positions$$
CREATE PROCEDURE sp_basket_get_positions(param_user_id INT, param_basket_id INT)
BEGIN

    SELECT 
        * 
    FROM basket_positions
    WHERE basket_id = param_basket_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_proceed_order$$
CREATE PROCEDURE sp_basket_proceed_order(param_user_id INT, param_basket_id INT)
BEGIN

    DECLARE var_stock_id            INT DEFAULT 0;

    DECLARE var_company_id          INT DEFAULT 0;
    DECLARE var_person_id           INT DEFAULT 0;
    
    DECLARE var_invoicingtype_id    INT DEFAULT 0;
    DECLARE var_paymenttype_id      INT DEFAULT 0;
    DECLARE var_order_for           CHAR(5) DEFAULT '';
    DECLARE var_dimension_unit      CHAR(5) DEFAULT '';
    DECLARE var_weight_unit         CHAR(5) DEFAULT '';
    DECLARE var_currency            CHAR(3) DEFAULT '';

    SET var_stock_id    = (SELECT stock_id FROM baskets WHERE id = param_basket_id);
    SET var_person_id   = IFNULL((SELECT person_id FROM users WHERE id = param_user_id), 0);
    SET var_company_id  = IFNULL((SELECT company_id FROM persons WHERE id = var_person_id), 0);
    
    SELECT
        dimension_unit,
        weight_unit,
        currency,
        invoicingtype_id,
        paymenttype_id,
        order_for
    INTO
        var_dimension_unit,
        var_weight_unit,
        var_currency,
        var_invoicingtype_id,
        var_paymenttype_id,
        var_order_for
    FROM stocks
    WHERE id = var_stock_id;

    
    START TRANSACTION;

        INSERT INTO orders(
            order_for,
            number,
            biz_id,
            company_id,
            person_id,
            buyer_ref,
            delivery_point,
            delivery_town,
            delivery_date,
            invoicingtype_id,
            paymenttype_id,
            `type`,
            stock_id,
            `status`,
            dimension_unit,
            weight_unit,
            currency,
            description,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            var_order_for,
            0,
            0,
            var_company_id,
            var_person_id,
            buyer_ref,
            delivery_point,
            delivery_town,
            delivery_date,
            var_invoicingtype_id,
            var_paymenttype_id,
            'so',
            var_stock_id,
            'nw',
            var_dimension_unit,
            var_weight_unit,
            var_currency,
            description,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id        
        FROM baskets
        WHERE id = param_basket_id;
    
        SELECT MAX(id) AS order_id FROM orders WHERE created_by = param_user_id;
    
   COMMIT; 

END
$$

DROP PROCEDURE IF EXISTS sp_basket_proceed_order_position$$
CREATE PROCEDURE sp_basket_proceed_order_position(param_user_id INT, param_basket_id INT, param_order_id INT, param_position_id INT)
BEGIN

    DECLARE var_qtty INT DEFAULT 0;
    SET var_qtty = (SELECT qtty FROM basket_positions WHERE basket_id = param_basket_id AND position_id = param_position_id);


    INSERT order_positions(
        order_id,
        position_id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        `length`,
        length_mm,
        unitweight,
        unitweight_ton,
        qtty,
        weight,
        weight_ton,
        price,
        `value`,
        internal_notes,
        created_at,
        created_by,
        modified_at,
        modified_by
    )
    SELECT
        param_order_id,
        param_position_id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        `length`,
        length_mm,
        unitweight,
        unitweight_ton,
        var_qtty,
        unitweight * var_qtty,
        unitweight_ton * var_qtty,
        price,
        unitweight * var_qtty * price,
        internal_notes,
        NOW(),
        param_user_id,
        NOW(),
        param_user_id
    FROM steelpositions 
    WHERE id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_remove_position$$
CREATE PROCEDURE sp_basket_remove_position(param_user_id INT, param_basket_id INT, param_position_id INT)
BEGIN

    DELETE FROM basket_positions
    WHERE basket_id = param_basket_id 
    AND position_id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_save_position$$
CREATE PROCEDURE sp_basket_save_position(param_user_id INT, param_basket_id INT, param_position_id INT, param_qtty INT)
BEGIN

    IF EXISTS (SELECT * FROM basket_positions WHERE basket_id = param_basket_id AND position_id = param_position_id)
    THEN

        UPDATE basket_positions
        SET
            qtty        = param_qtty,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE basket_id = param_basket_id 
        AND position_id = param_position_id;

    ELSE

        INSERT INTO basket_positions
        SET
            basket_id   = param_basket_id,
            position_id = param_position_id,
            qtty        = param_qtty,
            modified_at = NOW(),
            modified_by = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_basket_update_position$$
CREATE PROCEDURE sp_basket_update_position(param_user_id INT, param_basket_id INT, param_position_id INT, param_qtty INT)
BEGIN

    IF EXISTS (SELECT * FROM basket_positions WHERE basket_id = param_basket_id AND position_id = param_position_id)
    THEN

        UPDATE basket_positions
        SET
            qtty        = param_qtty,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE basket_id = param_basket_id 
        AND position_id = param_position_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_by_number$$
CREATE PROCEDURE sp_biz_get_by_number(param_number INT, param_suffix INT)
BEGIN

    SELECT 
        id AS biz_id
    FROM bizes
    WHERE number = param_number
    AND suffix = param_suffix;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_companies$$
CREATE PROCEDURE sp_biz_get_companies(param_biz_id INT)
BEGIN

    SELECT
        *
    FROM biz_companies
    WHERE biz_id = param_biz_id;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_list_by_company$$
CREATE PROCEDURE sp_biz_get_list_by_company(param_company_id INT, param_role CHAR(5))
BEGIN

    SELECT DISTINCT
        bizes.id AS biz_id
    FROM bizes
    JOIN biz_companies ON biz_companies.biz_id = bizes.id
    WHERE biz_companies.company_id = param_company_id
    AND biz_companies.role = param_role;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_list_by_ids$$
CREATE PROCEDURE sp_biz_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_biz_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM bizes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_list_by_team$$
CREATE PROCEDURE sp_biz_get_list_by_team(param_team_id INT)
BEGIN

    SELECT
        id AS biz_id
    FROM bizes
    WHERE team_id = param_team_id
    ORDER BY number, suffix;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_list_by_title$$
CREATE PROCEDURE sp_biz_get_list_by_title(param_title VARCHAR(50), param_rows_count INT)
BEGIN

    DECLARE var_number VARCHAR(50) DEFAULT '';
    SET var_number = REPLACE(LOWER(param_title), 'biz', '');
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id AS biz_id
        FROM bizes
        WHERE number LIKE '%", var_number, "%' OR title LIKE '%", param_title, "%'
        LIMIT ", param_rows_count, ";");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_quick_by_ids$$
CREATE PROCEDURE sp_biz_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_biz_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM bizes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_users$$
CREATE PROCEDURE sp_biz_get_users(param_biz_id INT)
BEGIN

    SELECT
        *
    FROM biz_users
    WHERE biz_id = param_biz_id;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_remove_company$$
CREATE PROCEDURE sp_biz_remove_company(param_biz_id INT, param_company_id INT, param_role CHAR(10))
BEGIN

    DELETE FROM biz_companies
    WHERE biz_id = param_biz_id
    AND company_id = param_company_id
    AND role = param_role;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_remove_user$$
CREATE PROCEDURE sp_biz_remove_user(param_biz_id INT, param_user_id INT)
BEGIN

    DELETE FROM biz_users
    WHERE biz_id = param_biz_id AND user_id = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_save$$
CREATE PROCEDURE sp_biz_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_description TEXT, param_objective_id INT,
                            param_market_id INT, param_team_id INT, param_product_id INT, param_status CHAR(15), param_driver_id INT)
sp:
BEGIN

    DECLARE var_number INT DEFAULT 0;
    DECLARE var_suffix INT DEFAULT 0;


    IF param_id > 0
    THEN

        UPDATE bizes
        SET
            title           = param_title,
            description     = param_description,
            objective_id    = param_objective_id,
            market_id       = param_market_id,
            team_id         = param_team_id,
            product_id      = param_product_id,
            `status`        = param_status,
            driver_id       = param_driver_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE
        
        START TRANSACTION;
            
            SET var_number = IFNULL((SELECT MAX(number) FROM bizes), 0) + 1;

            INSERT bizes
            SET
                number          = var_number,
                title           = param_title,
                description     = param_description,
                objective_id    = param_objective_id,
                market_id       = param_market_id,
                team_id         = param_team_id,
                product_id      = param_product_id,
                `status`        = param_status,
                driver_id       = param_driver_id,
                suffix          = var_suffix,
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;

            SET param_id = (SELECT MAX(id) FROM bizes WHERE created_by = param_user_id);
        
        COMMIT;
                
    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_save_company$$
CREATE PROCEDURE sp_biz_save_company(param_user_id INT, param_biz_id INT, param_company_id INT, param_role CHAR(10))
BEGIN

    INSERT INTO biz_companies
    SET
        biz_id      = param_biz_id,
        company_id  = param_company_id,
        role        = param_role,
        created_at  = param_user_id,
        created_by  = NOW();

END
$$

DROP PROCEDURE IF EXISTS sp_biz_save_user$$
CREATE PROCEDURE sp_biz_save_user(param_author_id INT, param_biz_id INT, param_user_id INT, param_is_driver TINYINT)
BEGIN

    IF NOT EXISTS (SELECT * FROM biz_users WHERE biz_id = param_biz_id AND user_id = param_user_id)
    THEN
        
        INSERT INTO biz_users
        SET
            biz_id      = param_biz_id,
            user_id     = param_user_id,
            is_driver   = param_is_driver,
            created_at  = NOW(),
            created_by  = param_author_id;

    END IF;
END
$$

DROP PROCEDURE IF EXISTS sp_city_get_list$$
CREATE PROCEDURE sp_city_get_list(param_region_id INT)
sp:
BEGIN

    IF param_region_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_city_get_list' AS ErrorAt;
        LEAVE sp;
    END IF;

    SELECT
        id AS city_id
    FROM cities
    WHERE region_id = param_region_id
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_city_get_list_by_ids$$
CREATE PROCEDURE sp_city_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_city_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM cities
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_city_get_quick_by_ids$$
CREATE PROCEDURE sp_city_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_city_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM companies WHERE city_id = cities.id) AS companies_count,
            (SELECT COUNT(*) FROM persons WHERE city_id = cities.id) AS persons_count
        FROM cities
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_city_remove$$
CREATE PROCEDURE sp_city_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM persons WHERE city_id = param_id)
    OR EXISTS (SELECT * FROM companies WHERE city_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_city_remove' AS ErrorAt;
        LEAVE sp;    
    END IF;

    
    DELETE FROM cities WHERE id = param_id;
    SELECT param_id AS id;
        
END
$$

DROP PROCEDURE IF EXISTS sp_city_save$$
CREATE PROCEDURE sp_city_save(param_user_id INT, param_id INT, param_country_id INT, param_region_id INT, param_title VARCHAR(250), param_alias VARCHAR(32), 
                            param_title1 VARCHAR(250), param_title2 VARCHAR(250), param_dialcode VARCHAR(70))
sp:
BEGIN

    IF EXISTS (SELECT * FROM cities WHERE id != param_id AND alias = param_alias)
    THEN
        SELECT -1 AS ErrorCode, 'sp_city_save' AS ErrorAt;
        LEAVE sp;    
    END IF;
    
    IF param_id > 0
    THEN

        IF NOT EXISTS (SELECT * FROM cities WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'sp_city_save' AS ErrorAt;
            LEAVE sp;
        END IF;

        UPDATE cities
        SET
            country_id  = param_country_id,
            region_id   = param_region_id,
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            dialcode    = param_dialcode,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT INTO cities
        SET
            country_id  = param_country_id,
            region_id   = param_region_id,
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            dialcode    = param_dialcode,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;            

        SET param_id = (SELECT MAX(id) FROM cities WHERE created_by  = param_user_id);

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_comment_delete$$
CREATE PROCEDURE sp_comment_delete(param_id INT)
BEGIN

    SELECT * FROM comments WHERE id = param_id;
    DELETE FROM comments WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_comment_get_list$$
CREATE PROCEDURE sp_comment_get_list(param_object_alias CHAR(10), param_object_id INT, param_order CHAR(4), param_from INT, param_count INT)
sp:
BEGIN
    
    DECLARE var_stmt VARCHAR(1000) DEFAULT '';

    SET @var_stmt := 
    CONCAT("SELECT
        id AS comment_id
    FROM comments
    WHERE object_alias = ? AND object_id = ?
    ORDER BY created_at ", param_order, "
    LIMIT ?, ?;");


    PREPARE stmt FROM @var_stmt;

    SET @stmt_object_alias  = param_object_alias;
    SET @stmt_object_id     = param_object_id;    
    SET @stmt_from          = param_from;
    SET @stmt_count         = param_count;
    
    EXECUTE stmt USING @stmt_object_alias, @stmt_object_id, @stmt_from, @stmt_count;


    SELECT 
        COUNT(id) AS rows
    FROM comments
    WHERE object_alias = param_object_alias 
    AND object_id = param_object_id;

END
$$

DROP PROCEDURE IF EXISTS sp_comment_get_list_by_ids$$
CREATE PROCEDURE sp_comment_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_comment_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *,
            IF(object_alias = 'post', (SELECT section FROM posts WHERE id = object_id), object_alias) AS object_section
        FROM comments
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_comment_get_page_no$$
CREATE PROCEDURE sp_comment_get_page_no(param_comment_id INT, param_per_page INT)
BEGIN

    DECLARE var_object_alias    CHAR(10) DEFAULT '';
    DECLARE var_object_id       INT DEFAULT 0;

    
    SELECT
        object_alias,
        object_id
    INTO
        var_object_alias,
        var_object_id
    FROM comments
    WHERE id = param_comment_id;


    SELECT 
        COUNT(*) as comments_count
    FROM comments 
    WHERE object_alias = var_object_alias 
    AND object_id = var_object_id 
    AND id <= param_comment_id;

    

END
$$

DROP PROCEDURE IF EXISTS sp_comment_save$$
CREATE PROCEDURE sp_comment_save(param_user_id INT, param_id INT, param_parent_id INT, 
                                    param_object_alias CHAR(10), param_object_id INT,
                                    param_title VARCHAR(1000), param_text TEXT, param_author VARCHAR(50))
sp:
BEGIN
    
    DECLARE var_parent_id   INT DEFAULT 0;
    DECLARE var_sort_order  INT DEFAULT 0;
    DECLARE var_level       INT DEFAULT 0;

    IF param_id > 0
    THEN


        UPDATE comments
        SET
            title       = param_title,
            `text`      = param_text,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        IF param_parent_id > 0
        THEN

            SELECT 
                object_alias, 
                object_id 
            INTO 
                param_object_alias, 
                param_object_id 
            FROM comments 
            WHERE id = param_parent_id;

        END IF;

        SET var_level = IFNULL((SELECT `level` + 1 FROM comments WHERE id = param_parent_id), 0);
        
        INSERT INTO comments
        SET 
            object_alias    = param_object_alias,
            object_id       = param_object_id,
            parent_id       = param_parent_id,
            `level`         = var_level,
            title           = param_title,
            `text`          = param_text,
            author          = param_author,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id = (SELECT MAX(id) FROM comments WHERE created_by = param_user_id);

    END IF;

    SELECT * FROM comments WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_activities$$
CREATE PROCEDURE sp_company_get_activities(param_company_id INT)
BEGIN

    SELECT 
        *
    FROM company_activities
    WHERE company_id = param_company_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_activities_by_ids$$
CREATE PROCEDURE sp_company_get_activities_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_get_activities_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            company_id AS id,
            activity_id
        FROM company_activities
        WHERE company_id IN (", param_ids, ");");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_bizes$$
CREATE PROCEDURE sp_company_get_bizes(param_company_id INT)
BEGIN

    SELECT
        biz_companies.biz_id,
        GROUP_CONCAT(biz_companies.role SEPARATOR ", ") AS role
    FROM biz_companies
    JOIN bizes ON biz_companies.biz_id = bizes.id
    WHERE company_id = param_company_id
    AND (bizes.`status` = 'admin' 
        OR bizes.`status` = 'marketing' 
        OR bizes.`status` = 'negotiation'
        OR bizes.`status` = 'repeat'
        OR bizes.`status` = 'idea')
    GROUP BY biz_id
    ORDER BY modified_at DESC
    LIMIT 10;


    SELECT 
        COUNT(distinct biz_id) AS `count`
    FROM biz_companies 
    WHERE company_id = param_company_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_by_alias$$
CREATE PROCEDURE sp_company_get_by_alias(param_alias CHAR(5))
BEGIN

    SELECT
        id AS company_id
    FROM companies
    WHERE alias = param_alias;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_contacts_by_ids$$
CREATE PROCEDURE sp_company_get_contacts_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_get_contacts_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            object_id AS id,
            type,
            title,
            description
        FROM contactdata
        WHERE object_alias = 'company'
        AND object_id IN (", param_ids, ");");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_list$$
CREATE PROCEDURE sp_company_get_list()
BEGIN

    SELECT
        id AS company_id
    FROM companies
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_list_by_ids$$
CREATE PROCEDURE sp_company_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM companies
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_list_by_title$$
CREATE PROCEDURE sp_company_get_list_by_title(param_title VARCHAR(50), param_rows_count INT)
BEGIN

    SET param_title = CONCAT('%', param_title, '%');

    SELECT 
        id AS company_id
    FROM companies
    WHERE title LIKE param_title 
    OR title_short LIKE param_title;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_mam_list$$
CREATE PROCEDURE sp_company_get_mam_list()
BEGIN

    SELECT
        id AS company_id
    FROM companies
    WHERE is_mam = 1;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_orders$$
CREATE PROCEDURE sp_company_get_orders(param_user_id INT, param_company_id INT)
BEGIN

    SELECT
        *
    FROM orders
    WHERE company_id = param_company_id
    AND (`status` = 'nw' 
        OR `status` = 'ip' 
        OR `status` = 'de');

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_persons$$
CREATE PROCEDURE sp_company_get_persons(param_user_id INT, param_company_id INT, param_limit INT)
BEGIN

    DROP TEMPORARY TABLE IF EXISTS t_persons;
    CREATE TEMPORARY TABLE t_persons(person_id INT);
        
    
    INSERT INTO t_persons(person_id)
    SELECT 
        id AS person_id
    FROM persons
    WHERE company_id = param_company_id
    ORDER BY modified_at, persons.first_name, persons.last_name;


    SET @var_stmt := CONCAT("   
    SELECT 
        *
    FROM t_persons 
    ", IF(param_limit > 0, CONCAT("LIMIT ", param_limit), ""), ";");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

    SELECT 
        COUNT(*) AS `count`
    FROM t_persons;


    DROP TEMPORARY TABLE IF EXISTS t_persons;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_products$$
CREATE PROCEDURE sp_company_get_products(param_company_id INT, param_alias CHAR(1))
BEGIN

    SELECT 
        *
    FROM company_products
    WHERE company_id = param_company_id
    AND alias = param_alias;

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_quick_by_ids$$
CREATE PROCEDURE sp_company_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM companies
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_company_get_stockholders_list$$
CREATE PROCEDURE sp_company_get_stockholders_list()
BEGIN

    SELECT 
        id AS company_id
    FROM companies
    WHERE location_id > 0;

END
$$

DROP PROCEDURE IF EXISTS sp_company_remove_activity$$
CREATE PROCEDURE sp_company_remove_activity(param_user_id INT, param_id INT)
BEGIN

    DELETE FROM company_activities
    WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_remove_location$$
CREATE PROCEDURE sp_company_remove_location(param_company_id INT)
BEGIN

    UPDATE companies SET location_id = 0 WHERE id = param_company_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_remove_product$$
CREATE PROCEDURE sp_company_remove_product(param_user_id INT, param_id INT)
BEGIN

    DELETE FROM company_products
    WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_save$$
CREATE PROCEDURE sp_company_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_title_native VARCHAR(250), 
                    param_title_short VARCHAR(50), param_title_trade VARCHAR(50), param_parent_id INT, param_location VARCHAR(10), param_status VARCHAR(15),
                    param_relation VARCHAR(15), param_key_contact INT, param_mam_genius INT, param_country_id INT, param_region_id INT, param_city_id INT, 
                    param_zip VARCHAR(20), param_address VARCHAR(100), param_pobox VARCHAR(20), param_delivery_address TEXT, param_data_labels TEXT, 
                    param_notes TEXT, param_bank_data TEXT, param_reg_data TEXT)
sp:
BEGIN

    DECLARE var_is_mam TINYINT DEFAULT 0;


    IF EXISTS (SELECT * FROM companies WHERE id != param_id AND title = param_title)
    THEN
        SELECT -1 AS ErrorCode, 'sp_company_save' AS ErrorAt;
        LEAVE sp;    
    END IF;

    IF param_parent_id > 0
    THEN
        SET var_is_mam = (SELECT is_mam FROM companies WHERE id = param_parent_id);
    END IF;


    IF param_id > 0
    THEN

        IF param_parent_id = 0
        THEN
            SET var_is_mam = (SELECT is_mam FROM companies WHERE id = param_id);
        END IF;

        UPDATE companies
        SET
            title               = param_title,
            title_native        = param_title_native,
            title_short         = param_title_short,
            title_trade         = param_title_trade,
            parent_id           = param_parent_id,
            location            = param_location,
            `status`            = param_status,
            relation            = param_relation,
            key_contact_id      = param_key_contact,
            mam_genius_id       = param_mam_genius,
            country_id          = param_country_id,
            region_id           = param_region_id,
            city_id             = param_city_id,
            zip                 = param_zip,
            address             = param_address,
            pobox               = param_pobox,
            delivery_address    = param_delivery_address,
            data_labels         = param_data_labels,
            notes               = param_notes,
            bank_data           = param_bank_data,
            reg_data            = param_reg_data,
            is_mam              = param_is_mam,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

    ELSE
        
        START TRANSACTION;

            INSERT companies
            SET
                title               = param_title,
                title_native        = param_title_native,
                title_short         = param_title_short,
                title_trade         = param_title_trade,
                parent_id           = param_parent_id,
                location            = param_location,
                `status`            = param_status,
                relation            = param_relation,
                key_contact_id      = param_key_contact,
                mam_genius_id       = param_mam_genius,
                country_id          = param_country_id,
                region_id           = param_region_id,
                city_id             = param_city_id,
                zip                 = param_zip,
                address             = param_address,
                pobox               = param_pobox,
                delivery_address    = param_delivery_address,
                data_labels         = param_data_labels,
                notes               = param_notes,
                bank_data           = param_bank_data,
                reg_data            = param_reg_data,
                is_mam              = param_is_mam,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id;

            SET param_id = (SELECT MAX(id) FROM companies WHERE created_by = param_user_id);
        
        COMMIT;
                
    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_company_save_activity$$
CREATE PROCEDURE sp_company_save_activity(param_user_id INT, param_company_id INT, param_activity_id INT)
BEGIN

    IF NOT EXISTS (SELECT * FROM company_activities WHERE company_id = param_company_id AND activity_id = param_activity_id)
    THEN
    
        INSERT INTO company_activities
        SET 
            company_id  = param_company_id,
            activity_id = param_activity_id,
            ancestors   = sf_get_activity_ancestors(param_activity_id),
            created_at  = NOW(),
            created_by  = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_company_save_location$$
CREATE PROCEDURE sp_company_save_location(param_user_id INT, param_company_id INT, param_location VARCHAR(50))
BEGIN

    DECLARE var_location_id        INT DEFAULT 0;
    DECLARE var_prev_location_id   INT DEFAULT 0;

    SET var_prev_location_id = (SELECT location_id FROM companies WHERE id = param_company_id);
    SET var_location_id = IFNULL((SELECT id FROM locations WHERE title = param_location), 0);

    IF var_location_id = 0
    THEN
    
        START TRANSACTION;

            INSERT INTO locations
            SET 
                title       = param_location,
                description = '',
                is_deleted  = 0,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET var_location_id = (SELECT MAX(id) FROM locations WHERE created_by  = param_user_id);

        COMMIT;        
    
    END IF;

    
    UPDATE companies SET location_id = var_location_id WHERE id = param_company_id;


    IF var_prev_location_id != var_location_id
    THEN
        
        UPDATE steelitems 
        SET 
            location_id = var_location_id 
        WHERE stockholder_id = param_company_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_company_save_product$$
CREATE PROCEDURE sp_company_save_product(param_user_id INT, param_company_id INT, param_alias CHAR(1), param_product_id INT)
BEGIN

    IF NOT EXISTS (SELECT * FROM company_products WHERE company_id = param_company_id AND alias = param_alias AND product_id = param_product_id)
    THEN
    
        INSERT INTO company_products
        SET 
            company_id  = param_company_id,
            product_id  = param_product_id,
            alias       = param_alias,
            created_at  = NOW(),
            created_by  = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_contactdata_get_list$$
CREATE PROCEDURE sp_contactdata_get_list(param_user_id INT, param_object_alias CHAR(20), param_object_id INT)
BEGIN

    SELECT 
        *
    FROM contactdata
    WHERE object_alias = param_object_alias
    AND object_id = param_object_id;

END
$$

DROP PROCEDURE IF EXISTS sp_contactdata_remove$$
CREATE PROCEDURE sp_contactdata_remove(param_user_id INT, param_id INT)
BEGIN

    SELECT * FROM contactdata WHERE id = param_id;    
    DELETE FROM contactdata WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_contactdata_save$$
CREATE PROCEDURE sp_contactdata_save(param_user_id INT, param_id INT, param_object_alias CHAR(20), param_object_id INT, param_type CHAR(20),
                                        param_title VARCHAR(100), param_description VARCHAR(1000), param_is_private TINYINT)
BEGIN

    IF param_id > 0
    THEN

        UPDATE contactdata
        SET
            `type`      = param_type,
            title       = param_title,
            description = param_description,
            is_private  = IF(param_is_private = 2, is_private, param_is_private),
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;


    ELSE

        INSERT INTO contactdata
        SET
            object_alias    = param_object_alias,
            object_id       = param_object_id,
            `type`          = param_type,
            title           = param_title,
            description     = param_description,
            is_private      = param_is_private,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_country_get_list$$
CREATE PROCEDURE sp_country_get_list(param_primary_first BOOLEAN)
BEGIN

    IF param_primary_first
    THEN

        SELECT
            id AS country_id
        FROM countries
        WHERE is_deleted = 0
        ORDER BY is_primary DESC, title;

    ELSE

        SELECT
            id AS country_id
        FROM countries
        WHERE is_deleted = 0
        ORDER BY title;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_country_get_list_by_ids$$
CREATE PROCEDURE sp_country_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_country_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM countries
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_country_get_quick_by_ids$$
CREATE PROCEDURE sp_country_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_country_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM companies WHERE country_id = countries.id) AS companies_count,
            (SELECT COUNT(*) FROM persons WHERE country_id = countries.id) AS persons_count,
            (SELECT COUNT(*) FROM regions WHERE country_id = countries.id) AS regions_count
        FROM countries
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_country_remove$$
CREATE PROCEDURE sp_country_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM regions WHERE country_id = param_id)
    OR EXISTS (SELECT * FROM persons WHERE country_id = param_id)
    OR EXISTS (SELECT * FROM companies WHERE country_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_country_remove' AS ErrorAt;
        LEAVE sp;    
    END IF;

    
    DELETE FROM countries WHERE id = param_id;
    SELECT param_id AS id;
        
END
$$

DROP PROCEDURE IF EXISTS sp_country_save$$
CREATE PROCEDURE sp_country_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_alias VARCHAR(32), param_title1 VARCHAR(250), param_title2 VARCHAR(250),
                    param_alpha2 CHAR(2), param_alpha3 CHAR(3), param_code VARCHAR(10), param_dialcode VARCHAR(10),
                    param_is_primary TINYINT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM countries WHERE id != param_id AND alias = param_alias AND is_deleted = 0)
    THEN
        SELECT -1 AS ErrorCode, 'sp_country_save' AS ErrorAt;
        LEAVE sp;    
    END IF;
    
    IF param_id > 0
    THEN

        IF NOT EXISTS (SELECT * FROM countries WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'sp_country_save' AS ErrorAt;
            LEAVE sp;
        END IF;

        UPDATE countries
        SET
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            alpha2      = param_alpha2,
            alpha3      = param_alpha3,
            `code`      = param_code,
            dialcode    = param_dialcode,
            is_primary  = param_is_primary,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT INTO countries
        SET
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            alpha2      = param_alpha2,
            alpha3      = param_alpha3,
            `code`      = param_code,
            dialcode    = param_dialcode,
            is_primary  = param_is_primary,
            is_deleted  = 0,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;            

        SET param_id = (SELECT MAX(id) FROM countries WHERE created_by  = param_user_id);

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_deliverytime_get_by_alias$$
CREATE PROCEDURE sp_deliverytime_get_by_alias(param_alias VARCHAR(50))
BEGIN

    SELECT 
        id AS id
    FROM deliverytimes
    WHERE alias = param_alias;

END
$$

DROP PROCEDURE IF EXISTS sp_deliverytime_get_list_by_ids$$
CREATE PROCEDURE sp_deliverytime_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_deliverytime_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM deliverytimes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_deliverytime_save$$
CREATE PROCEDURE sp_deliverytime_save(param_user_id INT, param_id INT, param_title VARCHAR(50), param_alias VARCHAR(50))
sp:
BEGIN

    IF EXISTS (SELECT * FROM deliverytimes WHERE alias = param_alias AND id != param_id) 
    THEN
        SELECT -1 AS ErrorCode, 'sp_deliverytime_save' AS ErrorAt;
        LEAVE sp;
    END IF;


    IF EXISTS (SELECT * FROM deliverytimes WHERE id = param_id)
    THEN

        UPDATE deliverytimes
        SET 
            title       = param_title,
            alias       = param_alias,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;
        
    ELSE

        START TRANSACTION;
        
            INSERT INTO deliverytimes
            SET 
                title       = param_title,
                alias       = param_alias,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET param_id = (SELECT MAX(id) FROM deliverytimes WHERE created_by = param_user_id);

        COMMIT;

    END IF;
    
    
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_department_get_list$$
CREATE PROCEDURE sp_department_get_list()
BEGIN

    SELECT
        id AS department_id
    FROM departments
    WHERE is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_department_get_list_by_ids$$
CREATE PROCEDURE sp_department_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_department_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM departments
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_department_get_quick_by_ids$$
CREATE PROCEDURE sp_department_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_department_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM departments
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_department_remove$$
CREATE PROCEDURE sp_department_remove(param_user_id INT, param_id INT)
BEGIN

    UPDATE departments
    SET
        is_deleted  = 1,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_id;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_department_save$$
CREATE PROCEDURE sp_department_save(param_user_id INT, param_id INT, param_title VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT * FROM departments WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_department_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM departments WHERE id = param_id)
    THEN

        UPDATE departments
        SET
            title           = param_title,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT departments
        SET
            title           = param_title,
            is_deleted      = 0,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id := (SELECT MAX(id) FROM departments WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_dliverytime_get_by_alias$$
CREATE PROCEDURE sp_dliverytime_get_by_alias(param_alias VARCHAR(50))
BEGIN

    SELECT 
        id AS id
    FROM deliverytimes
    WHERE alias = param_alias;

END
$$

DROP PROCEDURE IF EXISTS sp_email_get_last$$
CREATE PROCEDURE sp_email_get_last(param_user_id INT)
BEGIN

    SELECT 
        * 
    FROM emails 
    WHERE created_by = param_user_id
    ORDER BY id DESC
    LIMIT 1;

END
$$

DROP PROCEDURE IF EXISTS sp_email_get_list_by_ids$$
CREATE PROCEDURE sp_email_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_email_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM emails
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_email_save$$
CREATE PROCEDURE sp_email_save(param_user_id INT, param_id INT, param_object_alias CHAR(20), param_object_id INT, param_sender_address VARCHAR(250),
                    param_recipient_address VARCHAR(1000), param_to VARCHAR(250), param_attention VARCHAR(250), param_subject VARCHAR(250),
                    param_our_ref VARCHAR(250), param_your_ref VARCHAR(250), param_title VARCHAR(1000), param_description TEXT, 
                    param_signature VARCHAR(250))
BEGIN

    DECLARE var_number INT DEFAULT 0;

    IF param_id > 0
    THEN
        
        UPDATE emails
        SET
            sender_address      = param_sender_address,
            recipient_address   = param_recipient_address,
            `to`                = param_to,
            attention           = param_attention,
            `subject`           = param_subject,
            our_ref             = param_our_ref,
            your_ref            = param_your_ref,
            title               = param_title,
            description         = param_description,
            signature           = param_signature,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            SET var_number = IFNULL((SELECT MAX(number) FROM emails WHERE created_by = param_user_id), 0) + 1;
            
            INSERT INTO emails
            SET
                object_alias        = param_object_alias,
                object_id           = param_object_id,
                direction           = 'out',
                sender_address      = param_sender_address,
                recipient_address   = param_recipient_address,
                `to`                = param_to,
                attention           = param_attention,
                `subject`           = param_subject,
                our_ref             = param_our_ref,
                your_ref            = param_your_ref,
                title               = param_title,
                description         = param_description,
                signature           = param_signature,
                is_sent             = 0,
                is_dfa              = 0,
                number              = var_number,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id;

            SET param_id = (SELECT MAX(id) FROM emails WHERE created_by = param_user_id);

        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_invoicingtype_get_by_title$$
CREATE PROCEDURE sp_invoicingtype_get_by_title(param_title VARCHAR(250))
sp:
BEGIN

    SELECT 
        id AS invoicingtype_id
    FROM invoicingtypes
    WHERE title = param_title;

END
$$

DROP PROCEDURE IF EXISTS sp_invoicingtype_get_list$$
CREATE PROCEDURE sp_invoicingtype_get_list()
BEGIN

    SELECT 
        id AS invoicingtype_id
    FROM invoicingtypes
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_invoicingtype_get_list_by_ids$$
CREATE PROCEDURE sp_invoicingtype_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_invoicingtype_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            * 
        FROM invoicingtypes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_invoicingtype_save$$
CREATE PROCEDURE sp_invoicingtype_save(param_user_id INT, param_id INT, param_title VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT id FROM invoicingtypes WHERE id != param_id AND TRIM(title) = TRIM(param_title))
    THEN
        SELECT -1 AS ErrorCode, 'sp_invoicingtype_save' AS ErroAt;
        LEAVE sp;
    END IF;

    IF param_id > 0
    THEN

        UPDATE invoicingtypes
        SET
            title       = param_title,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO invoicingtypes
            SET
                title       = param_title,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;
            
            SET param_id = (SELECT MAX(id) FROM invoicingtypes WHERE created_by = param_user_id);

        COMMIT;

    END IF;

    
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_jobposition_get_list$$
CREATE PROCEDURE sp_jobposition_get_list()
BEGIN

    SELECT
        id AS jobposition_id
    FROM jobpositions
    WHERE is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_jobposition_get_list_by_ids$$
CREATE PROCEDURE sp_jobposition_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_jobposition_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM jobpositions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_jobposition_get_quick_by_ids$$
CREATE PROCEDURE sp_jobposition_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_jobposition_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM jobpositions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_jobposition_remove$$
CREATE PROCEDURE sp_jobposition_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM persons WHERE jobposition_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_jobposition_remove' AS ErrorAt;
        LEAVE sp;
    END IF;


    UPDATE jobpositions
    SET
        is_deleted  = 1,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_id;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_jobposition_save$$
CREATE PROCEDURE sp_jobposition_save(param_user_id INT, param_id INT, param_title VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT * FROM jobpositions WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_jobposition_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM jobpositions WHERE id = param_id)
    THEN

        UPDATE jobpositions
        SET
            title           = param_title,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT jobpositions
        SET
            title           = param_title,
            is_deleted      = 0,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id := (SELECT MAX(id) FROM jobpositions WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_journal_delete$$
CREATE PROCEDURE sp_journal_delete(param_id INT)
BEGIN

    DELETE FROM posts WHERE section = (SELECT alias FROM journals WHERE id = param_id);
    DELETE FROM journals WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_journal_get_by_alias$$
CREATE PROCEDURE sp_journal_get_by_alias(param_alias CHAR(20))
BEGIN

    SELECT 
        id AS journal_id 
    FROM journals 
    WHERE alias = param_alias;

END
$$

DROP PROCEDURE IF EXISTS sp_journal_get_list$$
CREATE PROCEDURE sp_journal_get_list()
BEGIN

    SELECT
        id AS journal_id
    FROM journals;

END
$$

DROP PROCEDURE IF EXISTS sp_journal_get_list_by_ids$$
CREATE PROCEDURE sp_journal_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_journal_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM journals
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_journal_save$$
CREATE PROCEDURE sp_journal_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_alias CHAR(20))
sp:
BEGIN

    IF EXISTS (SELECT * FROM journals WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_journal_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM journals WHERE id = param_id)
    THEN

        UPDATE journals
        SET
            alias       = param_alias,
            title       = param_title,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT journals
        SET
            alias       = param_alias,
            title       = param_title,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;

        SET param_id := (SELECT MAX(id) FROM journals WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_location_get_list$$
CREATE PROCEDURE sp_location_get_list()
BEGIN

    SELECT
        id AS location_id
    FROM locations;

END
$$

DROP PROCEDURE IF EXISTS sp_location_get_list_by_ids$$
CREATE PROCEDURE sp_location_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_location_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM locations
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_location_get_quick_by_ids$$
CREATE PROCEDURE sp_location_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_location_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM steelitems WHERE location_id = locations.id) AS items
        FROM locations
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_location_remove$$
CREATE PROCEDURE sp_location_remove(param_user_id INT, param_id INT)
BEGIN


    IF EXISTS (SELECT * FROM steelitems WHERE location_id = param_id)
    THEN
        
        UPDATE locations
        SET 
            is_deleted  = 1,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;        

    ELSE
        
        DELETE FROM locations WHERE id = param_id;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_location_save$$
CREATE PROCEDURE sp_location_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_description TEXT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM locations WHERE title = param_title AND is_deleted = 0 AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_location_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM locations WHERE id = param_id)
    THEN

        UPDATE locations
        SET
            title           = param_title,
            description     = param_description,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT locations
            SET
                title           = param_title,
                description     = param_description,
                is_deleted      = 0,
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;
    
            SET param_id := (SELECT MAX(id) FROM locations WHERE created_by = param_user_id);

        COMMIT;

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_market_add_country$$
CREATE PROCEDURE sp_market_add_country(param_user_id INT, param_market_id INT, param_country_id INT)
BEGIN

    INSERT INTO market_countries
    SET
        market_id   = param_market_id,
        country_id  = param_country_id,
        created_at  = NOW(),
        created_by  = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_market_get_countries$$
CREATE PROCEDURE sp_market_get_countries(param_market_id INT)
BEGIN

    SELECT 
        *
    FROM market_countries
    WHERE market_id = param_market_id;

END
$$

DROP PROCEDURE IF EXISTS sp_market_get_list$$
CREATE PROCEDURE sp_market_get_list()
BEGIN

    SELECT
        id AS market_id
    FROM markets
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_market_get_list_by_ids$$
CREATE PROCEDURE sp_market_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_market_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM markets
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_market_get_quick_by_ids$$
CREATE PROCEDURE sp_market_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_market_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM market_countries WHERE market_id = markets.id) AS countries_count,
            (SELECT COUNT(*) FROM bizes WHERE market_id = markets.id) AS bizes_count
        FROM markets
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_market_remove$$
CREATE PROCEDURE sp_market_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM bizes WHERE market_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_market_remove' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    DELETE FROM market_countries WHERE market_id = param_id;
    DELETE FROM markets WHERE id = param_id;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_market_remove_country$$
CREATE PROCEDURE sp_market_remove_country(param_market_id INT, param_country_id INT)
BEGIN

    DELETE FROM market_countries
    WHERE market_id = param_market_id 
    AND country_id = param_country_id;

END
$$

DROP PROCEDURE IF EXISTS sp_market_save$$
CREATE PROCEDURE sp_market_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_description TEXT, param_map_data VARCHAR(1000))
sp:
BEGIN

    IF EXISTS (SELECT * FROM markets WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_market_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM markets WHERE id = param_id)
    THEN

        UPDATE markets
        SET
            title           = param_title,
            description     = param_description,
            map_data        = param_map_data,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT markets
        SET
            title           = param_title,
            description     = param_description,
            map_data        = param_map_data,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id := (SELECT MAX(id) FROM markets WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_correspondence_list$$
CREATE PROCEDURE sp_message_get_correspondence_list(IN param_user_id INT, IN param_reader_id INT, IN param_from INT, IN param_count INT)
sp:
BEGIN
    DECLARE STATUS_NEW TINYINT DEFAULT 0;
    DECLARE STATUS_READ TINYINT DEFAULT 1;
    DECLARE IS_ACTIVE TINYINT DEFAULT 1;

    SET @var_stmt := "
    SELECT
        id AS message_id,
        sender_id,
        recipient_id
    FROM messages 
    WHERE (sender_id = ? AND recipient_id = ? AND sender_is_active = 1)
    OR (sender_id = ? AND recipient_id = ? AND recipient_is_active = 1)
    ORDER BY id DESC
    LIMIT ?, ?;";

    PREPARE stmt FROM @var_stmt;
    SET @stmt_user_id           = param_user_id;
    SET @stmt_reader_id         = param_reader_id;
    SET @stmt_from              = param_from;
    SET @stmt_count             = param_count;
    EXECUTE stmt USING  @stmt_user_id, @stmt_reader_id,
                        @stmt_reader_id, @stmt_user_id,
                        @stmt_from, @stmt_count;

    SELECT
        COUNT(*) AS rows
    FROM messages
    WHERE (sender_id = param_user_id AND recipient_id = param_reader_id AND sender_is_active = 1)
    OR (sender_id = param_reader_id AND recipient_id = param_user_id AND recipient_is_active = 1);
END
$$

DROP PROCEDURE IF EXISTS sp_message_get_inbox_list$$
CREATE PROCEDURE sp_message_get_inbox_list(IN param_recipient_id INT, IN param_from INT, IN param_count INT)
sp:
BEGIN
    DECLARE STATUS_NEW TINYINT DEFAULT 0;
    DECLARE STATUS_READ TINYINT DEFAULT 1;

    SET @var_stmt := "
    SELECT 
        id AS message_id,
        sender_id,
        recipient_id
    FROM messages 
    WHERE recipient_id = ? 
    AND recipient_is_active = 1
    ORDER BY id DESC
    LIMIT ?, ?;";

    PREPARE stmt FROM @var_stmt;
    SET @stmt_recipient_id      = param_recipient_id;
    SET @stmt_status_new        = STATUS_NEW;
    SET @stmt_status_read       = STATUS_READ;
    SET @stmt_from              = param_from;
    SET @stmt_count             = param_count;

    EXECUTE stmt USING @stmt_recipient_id, @stmt_from, @stmt_count;
    SELECT
        COUNT(*) AS rows
    FROM messages
    WHERE recipient_id = param_recipient_id
    AND recipient_is_active = 1;
END
$$

DROP PROCEDURE IF EXISTS sp_message_get_last_id$$
CREATE PROCEDURE sp_message_get_last_id(param_user_id INT, param_role_id INT, param_object_alias CHAR(20), param_object_id INT)
BEGIN
# LINKED WITH sp_message_get_list_for_object
# LINKED WITH sp_message_get_list
# LINKED WITH sp_message_get_pendings

    DECLARE ROLE_ADMIN  TINYINT DEFAULT 2;
    DECLARE ROLE_STAFF  TINYINT DEFAULT 6;

    DECLARE USER_GNOME  TINYINT DEFAULT 1;  # author for all system messages


    IF param_object_alias = '' AND param_object_id = 0
    THEN

        IF param_role_id <= ROLE_ADMIN
        THEN
    
            SELECT
                MAX(id) AS id
            FROM messages
            WHERE role_id IN (2,3,4,5,6,7,8,9,10);
                
        ELSEIF param_role_id <= ROLE_STAFF
        THEN
    
            SELECT 
                MAX(message_id) AS id            
            FROM message_users
            WHERE role_id IN (6,7,8,9,10)
            AND (
                type_id NOT IN (1)
                OR sender_id = param_user_id
                OR user_id = param_user_id
            );
            
        ELSE
                
            SELECT 
                MAX(message_id) AS id
            FROM message_users
            WHERE role_id IN (7,8,9,10)
            AND (
                sender_id = param_user_id
                OR user_id = param_user_id
            );
    
        END IF;
        

    ELSE

        IF param_role_id <= ROLE_ADMIN
        THEN
    
            SELECT 
                MAX(message_id) AS id
            FROM message_objects
            WHERE object_alias = param_object_alias
            AND object_id = param_object_id
            AND role_id IN (2,3,4,5,6,7,8,9,10)
            AND sender_id NOT IN (USER_GNOME);
                
        ELSEIF param_role_id <= ROLE_STAFF
        THEN
    
            SELECT
                MAX(mo.message_id) AS id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = param_object_alias
            AND object_id = param_object_id
            AND mo.role_id IN (6,7,8,9,10)
            AND (
                mo.type_id NOT IN (1)
                OR mo.sender_id = param_user_id
                OR mu.user_id = param_user_id
            )
            AND mo.sender_id NOT IN (USER_GNOME);
            
        ELSE
    
            SELECT
                MAX(mo.message_id) AS id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = param_object_alias
            AND object_id = param_object_id
            AND mo.role_id IN (7,8,9,10)
            AND (
                mo.sender_id = param_user_id
                OR mu.user_id = param_user_id
            )
            AND mo.sender_id NOT IN (USER_GNOME);
    
        END IF;

    END IF;
    
END
$$

DROP PROCEDURE IF EXISTS sp_message_get_list$$
CREATE PROCEDURE sp_message_get_list(param_user_id INT, param_role_id INT, param_message_id INT)
sp:
BEGIN
# LINKED WITH sp_message_get_list_for_object
# LINKED WITH sp_message_get_last_id
# LINKED WITH sp_message_get_pendings

    DECLARE ROLE_ADMIN  TINYINT DEFAULT 2;
    DECLARE ROLE_STAFF  TINYINT DEFAULT 6;
    
    
    IF param_message_id = 0
    THEN        
        SET param_message_id = sf_chat_get_today_first_message();
    ELSE        
        SET param_message_id = param_message_id + 1;    # because of using greater or equal    
    END IF;


    IF param_role_id <= ROLE_ADMIN
    THEN

        SELECT
            id AS message_id
        FROM messages
        WHERE id >= param_message_id
        AND role_id IN (2,3,4,5,6,7,8,9,10)
        ORDER BY id DESC;
            
    ELSEIF param_role_id <= ROLE_STAFF
    THEN

        SELECT DISTINCT
            message_id
        FROM message_users
        WHERE message_id >= param_message_id
        AND role_id IN (6,7,8,9,10)
        AND (
            type_id NOT IN (1)
            OR sender_id = param_user_id
            OR user_id = param_user_id
        )
        ORDER BY m.id DESC;            
        
    ELSE
            
        SELECT DISTINCT
            message_id
        FROM message_users
        WHERE message_id >= param_message_id
        AND role_id IN (7,8,9,10)
        AND (
            sender_id = param_user_id
            OR user_id = param_user_id
        )
        ORDER BY message_id DESC;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_list_by_ids$$
CREATE PROCEDURE sp_message_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_message_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM messages
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_list_for_object$$
CREATE PROCEDURE sp_message_get_list_for_object(param_user_id INT, param_role_id INT, param_object_alias CHAR(20), param_object_id INT, param_message_id INT, param_from INT, param_count INT)
sp:
BEGIN
# LINKED WITH sp_message_get_list
# LINKED WITH sp_message_get_last_id
# LINKED WITH sp_message_get_pendings

    DECLARE ROLE_ADMIN  TINYINT DEFAULT 2;
    DECLARE ROLE_STAFF  TINYINT DEFAULT 6;

    DECLARE USER_GNOME  TINYINT DEFAULT 1;


    DROP TEMPORARY TABLE IF EXISTS t_message_ids;
    CREATE TEMPORARY TABLE t_message_ids(message_id INT, INDEX ix_t_message_ids (message_id));


    SET @var_user_id        = param_user_id;
    SET @var_role_id        = param_role_id;
    SET @var_object_alias   = param_object_alias;
    SET @var_object_id      = param_object_id;
    SET @var_from           = param_from;
    SET @var_count          = param_count;


    IF param_role_id <= ROLE_ADMIN
    THEN

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT 
                message_id
            FROM message_objects
            WHERE object_alias = ?
            AND object_id = ?
            AND role_id IN (2,3,4,5,6,7,8,9,10)
            AND sender_id NOT IN (", USER_GNOME,")
            ", IF(param_message_id > 0, CONCAT(" AND message_id > ", param_message_id), ""), 
        ";");
    
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id;
            
    ELSEIF param_role_id <= ROLE_STAFF
    THEN

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT DISTINCT
                mo.message_id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = ?
            AND object_id = ?
            AND mo.role_id IN (6,7,8,9,10)
            AND (
                mo.type_id NOT IN (1)
                OR mo.sender_id = ?
                OR mu.user_id = ?
            )
            AND mo.sender_id NOT IN (", USER_GNOME,")
            ", IF(param_message_id > 0, CONCAT(" AND mo.message_id > ", param_message_id), ""), 
        ";");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id, @var_user_id, @var_user_id;
        
    ELSE

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT DISTINCT
                mo.message_id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = ?
            AND object_id = ?
            AND mo.role_id IN (7,8,9,10)
            AND (
                mo.sender_id = ?
                OR mu.user_id = ? 
            )
            AND mo.sender_id NOT IN (", USER_GNOME,")
            ", IF(param_message_id > 0, CONCAT(" AND mo.message_id > ", param_message_id), ""), 
        ";");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id, @var_user_id, @var_user_id;

    END IF;



    SET @var_stmt = "
    SELECT
        *
    FROM t_message_ids
    ORDER BY message_id DESC
    LIMIT ?, ?;";
    

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @var_from, @var_count;


    SELECT 
        COUNT(*) AS count
    FROM t_message_ids;


    DROP TEMPORARY TABLE IF EXISTS t_message_ids;

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_outbox_list$$
CREATE PROCEDURE sp_message_get_outbox_list(IN param_sender_id INT, IN param_from INT, IN param_count INT)
sp:
BEGIN
    DECLARE STATUS_NEW TINYINT DEFAULT 0;
    DECLARE STATUS_READ TINYINT DEFAULT 1;

    SET @var_stmt := "
    SELECT 
        id AS message_id,
        sender_id,
        recipient_id
    FROM messages 
    WHERE sender_id = ? 
    AND sender_is_active = 1 
    ORDER BY id DESC
    LIMIT ?, ?;";

    PREPARE stmt FROM @var_stmt;
    SET @stmt_sender_id         = param_sender_id;
    SET @stmt_from              = param_from;
    SET @stmt_count             = param_count;

    EXECUTE stmt USING @stmt_sender_id, @stmt_from, @stmt_count;
    SELECT
        COUNT(*) AS rows
    FROM messages
    WHERE sender_id = param_sender_id
    AND sender_is_active = 1;
END
$$

DROP PROCEDURE IF EXISTS sp_message_get_pendings$$
CREATE PROCEDURE sp_message_get_pendings(param_user_id INT, param_from INT, param_count INT)
BEGIN
# LINKED WITH sp_message_get_list_for_object
# LINKED WITH sp_message_get_last_id
# LINKED WITH sp_message_get_list
        
    DROP TEMPORARY TABLE IF EXISTS t_pendings;
    CREATE TEMPORARY TABLE t_pendings(message_id INT);
        
    
    INSERT INTO t_pendings(message_id)
    SELECT DISTINCT
        mu.message_id
    FROM message_users AS mu
    JOIN messages AS m ON mu.message_id = m.id
    LEFT JOIN message_delivered AS md ON m.id = md.message_id
    WHERE mu.user_id = param_user_id
    AND md.done_at IS NULL
    AND m.is_pending > 0;


    SET @stmt_from  = param_from;
    SET @stmt_count = param_count;    
    SET @statement  = CONCAT("
    SELECT
        * 
    FROM t_pendings 
    ORDER BY message_id DESC 
    LIMIT ?, ?;");
    
    PREPARE stmt FROM @statement;
    EXECUTE stmt USING @stmt_from, @stmt_count;


    SELECT 
        COUNT(*) AS `count`
    FROM t_pendings;


    DROP TEMPORARY TABLE IF EXISTS t_pendings;
    

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_recipients_by_ids$$
CREATE PROCEDURE sp_message_get_recipients_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_message_get_recipients_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            message_id AS id,
            user_id,
            relation,
            created_at,
            created_by
        FROM message_users
        WHERE message_id IN (", param_ids, ");");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_userdata_by_ids$$
CREATE PROCEDURE sp_message_get_userdata_by_ids(param_ids VARCHAR(1100), param_user_id INT)
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_message_get_userdata_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_user_id    = param_user_id;
    SET @var_stmt       = CONCAT(  
        "SELECT 
            message_id AS id,
            user_id,
            delivered_at,
            done_at
        FROM message_delivered
        WHERE message_id IN (", param_ids, ")
        AND user_id = ?
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @var_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_message_mark_as_done$$
CREATE PROCEDURE sp_message_mark_as_done(param_user_id INT, param_message_id INT)
BEGIN

    IF EXISTS (SELECT * FROM message_delivered WHERE message_id = param_message_id AND user_id = param_user_id)
    THEN
        
        UPDATE message_delivered
        SET
            done_at = NOW()
        WHERE message_id = param_message_id 
        AND user_id = param_user_id;

    ELSE

        INSERT INTO message_delivered
        SET
            message_id  = param_message_id,
            user_id     = param_user_id,
            done_at     = NOW();

    END IF;


    SELECT * FROM messages WHERE id = param_message_id;

END
$$

DROP PROCEDURE IF EXISTS sp_message_mass_delivered$$
CREATE PROCEDURE sp_message_mass_delivered(param_user_id INT, param_message_id INT)
BEGIN


    DECLARE var_message_id INT DEFAULT 0;


    SET var_message_id = IFNULL((
        SELECT 
            MAX(message_id) 
        FROM message_delivered 
        WHERE user_id = param_user_id 
        AND delivered_at != NULL
    ), 0);


    INSERT IGNORE INTO message_delivered(message_id, user_id, delivered_at, done_at)
    SELECT
        id,
        param_user_id,
        NOW(),
        NULL
    FROM messages
    WHERE is_alert > 0
    AND id > var_message_id 
    AND id <= param_message_id;


    UPDATE message_delivered
    SET
        delivered_at = NOW()
    WHERE user_id = param_user_id
    AND delivered_at = NULL
    AND message_id IN (
        SELECT
            id
        FROM messages
        WHERE is_alert > 0
        AND id > var_message_id 
        AND id <= param_message_id
    );


    # output
    SELECT id FROM messages WHERE is_alert > 0 AND id > var_message_id AND id <= param_message_id;


END
$$

DROP PROCEDURE IF EXISTS sp_message_save$$
CREATE PROCEDURE sp_message_save(param_user_id INT, param_type_id INT, param_role_id INT, param_sender_id INT, param_title VARCHAR(1000),
                                    param_title_source VARCHAR(1000), param_description TEXT, param_description_source TEXT, param_parent_id INT,
                                    param_deadline TIMESTAMP, param_is_alert TINYINT, param_is_pending TINYINT)
BEGIN

    START TRANSACTION;

        INSERT INTO messages
        SET
            type_id             = param_type_id,
            role_id             = param_role_id,
            sender_id           = param_sender_id,
            title               = param_title,
            title_source        = param_title_source,
            description         = param_description,
            description_source  = param_description_source,
            parent_id           = param_parent_id,
            deadline            = param_deadline,
            is_alert            = param_is_alert,
            is_pending          = param_is_pending,
            created_at          = NOW(),
            created_by          = param_user_id;
    
        SELECT MAX(id) AS id FROM messages;

    COMMIT;

END
$$

DROP PROCEDURE IF EXISTS sp_message_save_object$$
CREATE PROCEDURE sp_message_save_object(param_user_id INT, param_message_id INT, param_type_id TINYINT, param_role_id TINYINT, param_sender_id INT, param_object_alias CHAR(20), param_object_id INT)
BEGIN

    INSERT IGNORE message_objects
    SET
        message_id      = param_message_id,
        type_id         = param_type_id,
        role_id         = param_role_id,
        sender_id       = param_sender_id,
        object_alias    = param_object_alias,
        object_id       = param_object_id,
        created_at      = NOW(),
        created_by      = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_message_save_users$$
CREATE PROCEDURE sp_message_save_users(param_user_id INT, param_message_id INT, param_type_id TINYINT, param_role_id TINYINT, param_is_pending TINYINT, param_sender_id INT, param_relation CHAR(1), param_user_ids VARCHAR(1000))
sp:
BEGIN

    SET @var_stmt := CONCAT("
        INSERT IGNORE INTO message_users(message_id, type_id, role_id, is_pending, sender_id, user_id, relation, created_at, created_by)
        SELECT
            ?,
            ?,
            ?,
            ?,
            ?,
            id,
            ?,
            NOW(),
            ?
        FROM users
        WHERE id IN (", param_user_ids, ")
    ");

    SET @stmt_message_id    = param_message_id;
    SET @stmt_type_id       = param_type_id;
    SET @stmt_role_id       = param_role_id;
    SET @stmt_is_pending    = param_is_pending;
    SET @stmt_sender_id     = param_sender_id;
    SET @stmt_relation      = param_relation;
    SET @stmt_user_id       = param_user_id;

    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @stmt_message_id, @stmt_type_id, @stmt_role_id, @stmt_is_pending, @stmt_sender_id, @stmt_relation, @stmt_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_navigation_delete$$
CREATE PROCEDURE sp_navigation_delete(param_id INT)
BEGIN

    DECLARE var_parent_id   INT DEFAULT 0;
    DECLARE var_sort_no     INT DEFAULT 0;


    SELECT
        parent_id,
        sort_no
    INTO
        var_parent_id,
        var_sort_no
    FROM navigation 
    WHERE id = param_id;
    

    UPDATE navigation 
    SET 
        sort_no = sort_no - 1
    WHERE parent_id = var_parent_id
    AND sort_no > var_sort_no;

    
    DELETE FROM navigation WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_navigation_get_list$$
CREATE PROCEDURE sp_navigation_get_list(param_lang CHAR(2), param_domain CHAR(2))
BEGIN

    SELECT
        id AS navigation_id
    FROM navigation
    WHERE domain = param_domain 
    AND lang = param_lang
    ORDER BY sort_no;

END
$$

DROP PROCEDURE IF EXISTS sp_navigation_get_list_by_ids$$
CREATE PROCEDURE sp_navigation_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_navigation_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM navigation
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_navigation_save$$
CREATE PROCEDURE sp_navigation_save(param_user_id INT, param_lang CHAR(2), param_domain CHAR(2), param_id INT, 
                                    param_object_alias CHAR(10), param_object_id INT, param_parent_id INT, 
                                    param_sort_no INT, param_url VARCHAR(250), param_title VARCHAR(250), 
                                    param_role_id TINYINT, param_is_visible TINYINT)
sp:
BEGIN

    DECLARE var_parent_id   INT DEFAULT 0;
    DECLARE var_sort_no     INT DEFAULT 0;
    DECLARE var_tree_level  INT DEFAULT 0;
    DECLARE var_max_sort_no INT DEFAULT 0;

    
    IF EXISTS (SELECT * FROM navigation WHERE domain = param_domain AND lang = param_lang AND parent_id = param_parent_id AND url = param_url AND id != param_id) 
    THEN
        SELECT -1 AS ErrorCode, 'sp_navigation_save' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_max_sort_no = IFNULL((SELECT MAX(sort_no) FROM navigation WHERE domain = param_domain AND lang = param_lang AND parent_id = param_parent_id), 1);

    IF param_sort_no > var_max_sort_no + 1
    THEN

        SET param_sort_no := var_max_sort_no;

    END IF;

    SET var_tree_level = IFNULL((SELECT tree_level + 1 FROM navigation WHERE id = param_parent_id), 0);

    IF EXISTS (SELECT * FROM navigation WHERE id = param_id)
    THEN

        SET var_parent_id   := (SELECT parent_id FROM navigation WHERE id = param_id);
        SET var_sort_no     := (SELECT sort_no FROM navigation WHERE id = param_id);
    
        IF var_parent_id != param_parent_id
        THEN

            
            UPDATE navigation SET sort_no = sort_no - 1 WHERE domain = param_domain AND lang = param_lang AND sort_no > var_sort_no AND parent_id = var_parent_id;

            
            UPDATE navigation SET sort_no = sort_no + 1 WHERE domain = param_domain AND lang = param_lang AND sort_no >= param_sort_no AND parent_id = param_parent_id;
            
        ELSE

            IF var_sort_no > param_sort_no
            THEN                
                
                UPDATE navigation 
                SET 
                    sort_no = sort_no + 1 
                WHERE domain = param_domain 
                AND lang = param_lang 
                AND sort_no >= param_sort_no 
                AND sort_no < var_sort_no 
                AND parent_id = param_parent_id;
            
            ELSEIF var_sort_no < param_sort_no
            THEN
                
                IF param_sort_no <= var_max_sort_no + 1
                THEN
                    SET param_sort_no := param_sort_no - 1;
                END IF;

                UPDATE navigation 
                SET 
                    sort_no = sort_no - 1 
                WHERE domain = param_domain 
                AND lang = param_lang 
                AND sort_no > var_sort_no 
                AND sort_no <= param_sort_no 
                AND parent_id = param_parent_id;

            END IF;

        END IF;

        UPDATE navigation
        SET
            object_id   = param_object_id,
            parent_id   = param_parent_id,
            tree_level  = var_tree_level,
            sort_no     = param_sort_no,
            url         = param_url,
            title       = param_title,
            role_id     = param_role_id,
            is_visible  = param_is_visible,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        UPDATE navigation SET sort_no = sort_no + 1 WHERE domain = param_domain AND lang = param_lang AND sort_no >= param_sort_no AND parent_id = param_parent_id;

        INSERT navigation
        SET
            domain          = param_domain,
            lang            = param_lang,
            object_alias    = param_object_alias,
            object_id       = param_object_id,
            parent_id       = param_parent_id,
            tree_level      = var_tree_level,
            sort_no         = param_sort_no,
            url             = param_url,
            title           = param_title,
            role_id         = param_role_id,
            is_visible      = param_is_visible,
            created_by      = param_user_id,
            created_at      = NOW(),
            modified_by     = param_user_id,
            modified_at     = NOW();

        SET param_id := (SELECT MAX(id) FROM navigation WHERE created_by = param_user_id);        

    END IF;

    
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_objective_get_actual_list$$
CREATE PROCEDURE sp_objective_get_actual_list()
BEGIN

    DECLARE var_year    INT DEFAULT 0;
    DECLARE var_quarter INT DEFAULT 0;

    SET var_year    = YEAR(NOW());
    SET var_quarter = QUARTER(NOW());

    SELECT 
        id AS objective_id
    FROM objectives
    WHERE `year` >= var_year
    AND (`quarter` >= var_quarter OR `quarter` = 0);

END
$$

DROP PROCEDURE IF EXISTS sp_objective_get_list$$
CREATE PROCEDURE sp_objective_get_list(param_year INT, param_quarter TINYINT)
BEGIN

    SELECT
        id AS objective_id
    FROM objectives
    WHERE (`year` = param_year OR param_year = 0)
    AND (`quarter` = param_quarter OR param_quarter = 0)
    ORDER BY `year` DESC, `quarter` DESC, title;

END
$$

DROP PROCEDURE IF EXISTS sp_objective_get_list_by_ids$$
CREATE PROCEDURE sp_objective_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_objective_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM objectives
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_objective_get_quick_by_ids$$
CREATE PROCEDURE sp_objective_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_country_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM bizes WHERE objective_id = objectives.id) AS bizes_count
        FROM objectives
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_objective_remove$$
CREATE PROCEDURE sp_objective_remove(IN param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM bizes WHERE objective_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_objective_remove' AS ErrorAt;
        LEAVE sp;
    END IF;


    DELETE FROM objectives WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_objective_save$$
CREATE PROCEDURE sp_objective_save(param_user_id INT, param_id INT, param_year INT, param_quarter TINYINT, param_title VARCHAR(250), param_description TEXT)
BEGIN

    IF param_id > 0
    THEN

        UPDATE objectives
        SET
            `quarter`   = param_quarter,
            `year`      = param_year,
            title       = param_title,
            description = param_description,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO objectives
            SET
                `quarter`   = param_quarter,
                `year`      = param_year,
                title       = param_title,
                description = param_description,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;
        
            SET param_id = (SELECT MAX(id) FROM objectives WHERE created_by  = param_user_id);

        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_add_item$$
CREATE PROCEDURE sp_order_add_item(param_user_id INT, param_order_id INT, param_position_id INT, param_item_id INT)
sp:
BEGIN

    UPDATE steelitems
    SET
        is_available    = 0,
        order_id        = param_order_id,
        modified_at     = NOW(),
        modified_by     = param_user_id
    WHERE id = param_item_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_create$$
CREATE PROCEDURE sp_order_create(param_user_id INT, param_order_for CHAR(5), param_dimension_unit CHAR(5), 
                                param_weight_unit CHAR(5), param_currency CHAR(3))
BEGIN

    START TRANSACTION;
    
        INSERT INTO orders
        SET
            order_for       = param_order_for,
            number          = 0,
            biz_id          = 0,
            company_id      = 0,
            person_id       = 0,
            `type`          = 'do',
            stock_id        = 0,
            `status`        = '',
            dimension_unit  = param_dimension_unit,
            weight_unit     = param_weight_unit,
            currency        = param_currency,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;
    
        SELECT MAX(id) AS id FROM orders WHERE created_by = param_user_id;
    
    COMMIT;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_list$$
CREATE PROCEDURE sp_order_get_list(param_user_id INT, param_order_for CHAR(5), param_biz_id INT, param_company_id INT, 
                                   param_period_from TIMESTAMP, param_period_to TIMESTAMP, param_status CHAR(2), 
                                   param_steelgrade_id INT, param_thickness_from DECIMAL(10,4), 
                                   param_thickness_to DECIMAL(10,4), param_width_from DECIMAL(10,4), 
                                   param_width_to DECIMAL(10,4), param_keyword VARCHAR(100), param_type CHAR(2))
sp:
BEGIN

    DECLARE var_where       VARCHAR(4000) DEFAULT '';
    DECLARE var_prefix      VARCHAR(100) DEFAULT '';
    DECLARE var_order_ids   VARCHAR(4000) DEFAULT '';
    

    IF param_steelgrade_id > 0 OR param_thickness_from > 0 OR param_thickness_to > 0 OR param_width_from > 0 OR param_width_to > 0
    THEN

        SET var_where = '';
        
        IF param_steelgrade_id > 0
        THEN 
            SET var_where = CONCAT(var_where, "steelgrade_id = ", param_steelgrade_id); 
        END IF;


        IF param_thickness_from > 0 OR param_thickness_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");
            
            IF param_thickness_from > 0 AND param_thickness_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(thickness_mm >= ", param_thickness_from, " AND thickness_mm <= ", param_thickness_to, ")"); 
            ELSEIF param_thickness_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm >= ", param_thickness_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm <= ", param_thickness_to); 
            END IF;
                    
        END IF;
        
        IF param_width_from > 0 OR param_width_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");

            IF param_width_from > 0 AND param_width_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(width_mm >= ", param_width_from, " AND width_mm <= ", param_width_to, ")"); 
            ELSEIF param_width_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "width_mm >= ", param_width_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "width_mm <= ", param_width_to); 
            END IF;
                    
        END IF;
    
    
        DROP TEMPORARY TABLE IF EXISTS t_orders;
        CREATE TEMPORARY TABLE t_orders(id INT);
        

        SET @var_stmt := CONCAT("   
            INSERT INTO t_orders(id)
            SELECT 
                order_id
            FROM order_positions 
        ", IF(var_where = "", "", " WHERE "), var_where);

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET var_order_ids = IFNULL((SELECT GROUP_CONCAT(id SEPARATOR ",") FROM t_orders), '');
        
        IF TRIM(var_order_ids) = ''
        THEN
            SET var_order_ids = '-1';
        END IF;

    END IF;
    
    
    IF TRIM(param_order_for) != ''
    THEN        
        SET var_where = CONCAT("o.order_for = '", param_order_for, "'");
    END IF;
    

    IF param_biz_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.biz_id = ", param_biz_id);
    END IF;

    IF param_company_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.company_id = ", param_company_id);
    END IF;

    IF TRIM(param_status) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status = '", param_status, "'");
    END IF;

    IF TRIM(param_type) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.type = '", param_type, "'");
    END IF;

    IF param_period_from != NULL
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at >= ", param_period_from);
    END IF;

    IF param_period_to != NULL
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at <= ", param_period_to);
    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET param_keyword   = CONCAT('%', param_keyword, '%');
        SET var_prefix      = IF(var_where = "", "", " AND ");
        SET var_where       = CONCAT(var_where, var_prefix, "(o.buyer_ref LIKE '", param_keyword, "' OR o.supplier_ref LIKE '", param_keyword, "' OR o.description LIKE '", param_keyword, "')");
    END IF;

    IF var_order_ids != ''
    THEN    
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where       = CONCAT(var_where, var_prefix, "id IN (", var_order_ids, ")");
    END IF;

    SET @var_stmt = CONCAT("
        SELECT
            o.id AS order_id
        FROM orders AS o 
    ", IF(var_where = "", "", " WHERE "), var_where);

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_list_by_ids$$
CREATE PROCEDURE sp_order_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            * 
        FROM orders
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_list_for_stock$$
CREATE PROCEDURE sp_order_get_list_for_stock(param_user_id INT, param_stock_id INT)
sp:
BEGIN

    DECLARE var_order_for CHAR(5) DEFAULT '';
    SET var_order_for = IFNULL((SELECT order_for FROM stocks WHERE id = param_stock_id), '');

    IF var_order_for = ''
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_get_list_for_stock' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT 
        id AS order_id
    FROM orders
    WHERE order_for = var_order_for
    AND `status` = 'ip';

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_positions$$
CREATE PROCEDURE sp_order_get_positions(param_order_id INT)
BEGIN

    SELECT
        *
    FROM order_positions
    WHERE order_id = param_order_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_position_items$$
CREATE PROCEDURE sp_order_get_position_items(param_order_id INT, param_position_id INT)
BEGIN

    SELECT 
        id AS steelitem_id
    FROM steelitems
    WHERE steelposition_id = param_position_id 
    AND order_id = param_order_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_quick_by_ids$$
CREATE PROCEDURE sp_order_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT SUM(qtty) FROM order_positions WHERE order_id = orders.id) AS qtty,
            (SELECT SUM(weight) FROM order_positions WHERE order_id = orders.id) AS weight,
            (SELECT SUM(value) FROM order_positions WHERE order_id = orders.id) AS value,
            TIMESTAMPDIFF(DAY, CONCAT(YEAR(NOW()), '-', MONTH(NOW()), '-', DAY(NOW())), alert_date) AS days_to_alert
        FROM orders
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_steelgrades$$
CREATE PROCEDURE sp_order_get_steelgrades()
BEGIN

    SELECT DISTINCT
        steelgrade_id
    FROM order_positions;

END
$$

DROP PROCEDURE IF EXISTS sp_order_items_add_from_stock$$
CREATE PROCEDURE sp_order_items_add_from_stock(param_user_id INT, param_order_id INT, param_item_ids VARCHAR(1100))
BEGIN

    SET @var_order_id   = param_order_id;
    SET @var_user_id    = param_user_id;
    
    SET @var_stmt       = CONCAT("
        UPDATE steelitems
        SET
            order_id        = ?,
            is_available    = 0,
            modified_at     = NOW(),
            modified_by     = ?
        WHERE id IN (", param_item_ids, ") 
        AND is_available = 1 AND order_id = 0 
        AND is_deleted = 0;
    ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @var_order_id, @var_user_id;


    SET @var_stmt = CONCAT(  
        "
        SELECT 
            steelposition_id
        FROM steelitems
        WHERE id IN (", param_item_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_order_lock_steelitems$$
CREATE PROCEDURE sp_order_lock_steelitems(param_user_id INT, param_order_id INT, param_position_id INT, param_delta_qtty INT)
BEGIN

    SET @var_user_id        = param_user_id;
    SET @var_order_id       = param_order_id;
    SET @var_position_id    = param_position_id;
    SET @var_delta_qtty     = param_delta_qtty;
    
    
    IF param_delta_qtty > 0
    THEN

        SET @var_stmt = "
            UPDATE steelitems
            SET
                order_id        = ?,
                is_available    = 0,
                modified_at     = NOW(),
                modified_by     = ?
            WHERE steelposition_id = ? 
            AND is_available = 1 AND order_id = 0
            ORDER BY is_virtual, id
            LIMIT ?;
        ";
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_order_id, @var_user_id, @var_position_id, @var_delta_qtty;    
       
    ELSE

        SET @var_delta_qtty  = @var_delta_qtty * -1;

        SET @var_stmt = "
            UPDATE steelitems
            SET
                order_id        = 0,
                is_available    = 1,
                modified_at     = NOW(),
                modified_by     = ?
            WHERE order_id = ? AND is_available = 0 
            ORDER BY is_virtual DESC, id
            LIMIT ?;
        ";
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_user_id, @var_order_id, @var_delta_qtty;    

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_position_add_from_stock$$
CREATE PROCEDURE sp_order_position_add_from_stock(param_user_id INT, param_order_id INT, param_position_id INT)
sp:
BEGIN

    DECLARE var_qtty INT DEFAULT 0;

    SET var_qtty = IFNULL((SELECT COUNT(*) FROM steelitems WHERE steelposition_id = param_position_id AND is_available = 0 AND order_id = param_order_id), 0);
    
    IF var_qtty = 0
    THEN
        SET var_qtty = (SELECT qtty FROM steelpositions WHERE id = param_position_id);
    END IF;


    INSERT IGNORE INTO order_positions(
        order_id,
        position_id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        qtty,
        weight,
        weight_ton,
        price,
        `value`,
        notes,
        internal_notes,
        is_saved,
        created_at,
        created_by,
        modified_at,
        modified_by)
    SELECT 
        param_order_id,
        id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        var_qtty,
        unitweight * var_qtty,
        unitweight_ton * var_qtty,
        price,
        unitweight * var_qtty * price,
        notes,
        internal_notes,
        0,
        NOW(),
        param_user_id,
        NOW(),
        param_user_id
    FROM steelpositions
    WHERE id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_put_positions_from_stock$$
CREATE PROCEDURE sp_order_put_positions_from_stock(param_user_id INT, param_order_id INT, param_position_ids VARCHAR(1100))
sp:
BEGIN

    SET @var_stmt := CONCAT(  
        "
        INSERT IGNORE INTO order_positions(
            order_id,
            position_id,
            steelgrade_id,
            thickness,
            width,
            length,
            unitweight,
            qtty,
            weight,
            price,
            value,
            notes,
            internal_notes,
            is_saved,
            created_at,
            created_by,
            modified_at,
            modified_by)
        SELECT ", param_order_id, ",  
            id,
            steelgrade_id,
            thickness,
            width,
            length,
            unitweight,
            qtty,
            weight,
            price,
            value,
            notes,
            internal_notes,
            0,
            NOW(),
            ", param_user_id, ",
            NOW(),
            ", param_user_id, " 
        FROM steelpositions
        WHERE id IN (", param_position_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove$$
CREATE PROCEDURE sp_order_remove(param_user_id INT, param_order_id INT)
BEGIN

    DELETE FROM orders WHERE id = param_order_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove_item$$
CREATE PROCEDURE sp_order_remove_item(param_user_id INT, param_order_id INT, param_position_id INT, param_item_id INT)
sp:
BEGIN

    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND order_id = param_order_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    IF (SELECT is_from_order FROM steelitems WHERE id = param_item_id) > 0
    THEN
        
        CALL sp_steelitem_remove(param_user_id, param_item_id);

    ELSE
        
        UPDATE steelitems
        SET
            is_available    = 1,
            order_id        = 0,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_item_id;

    END IF;

    IF (SELECT qtty FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id) = 0
    THEN
        
        DELETE FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove_position$$
CREATE PROCEDURE sp_order_remove_position(param_order_id INT, param_position_id INT)
sp:
BEGIN

    DELETE FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id;


    IF NOT EXISTS (SELECT * FROM steelpositions WHERE id = param_position_id)
    THEN
        LEAVE sp;
    END IF;


    IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) = 1
    THEN

        SELECT id AS steelitem_id FROM steelitems WHERE steelposition_id = param_position_id;
        
        DELETE FROM steelpositions WHERE id = param_position_id;
        DELETE FROM steelitems WHERE is_from_order = 1 AND steelposition_id = param_position_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove_positions$$
CREATE PROCEDURE sp_order_remove_positions(param_order_id INT, param_position_id INT)
sp:
BEGIN

    DELETE FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id;


    IF NOT EXISTS (SELECT * FROM steelpositions WHERE id = param_position_id)
    THEN
        LEAVE sp;
    END IF;


    IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) = 1
    THEN

        SELECT id AS steelitem_id FROM steelitems WHERE steelposition_id = param_position_id;
        
        DELETE FROM steelpositions WHERE id = param_position_id;
        DELETE FROM steelitems WHERE is_from_order = 1 AND steelposition_id = param_position_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_return_position$$
CREATE PROCEDURE sp_order_return_position(param_user_id INT, param_order_id INT, param_position_id INT)
BEGIN

    DECLARE var_qtty INT DEFAULT 0;

    UPDATE steelitems
    SET
        order_id        = 0,
        is_available    = 0,
        is_deleted      = 1,
        modified_at     = NOW(),
        modified_by     = param_user_id
    WHERE order_id = param_order_id
    AND is_from_order = 1;


    UPDATE steelitems
    SET
        order_id        = 0,
        is_available    = 1,
        modified_at     = NOW(),
        modified_by     = param_user_id
    WHERE order_id = param_order_id
    AND is_from_order = 0;
    
    
    
    CALL sp_steelposition_update_qtty(param_user_id, param_position_id);

    
    SELECT * FROM steelpositions WHERE id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_save$$
CREATE PROCEDURE sp_order_save(param_user_id INT, param_id INT, param_order_for CHAR(5), param_biz_id INT,
    param_company_id INT, param_person_id INT, param_buyer_ref VARCHAR(50), param_supplier_ref VARCHAR(50),
    param_delivery_point CHAR(3), param_delivery_town VARCHAR(250), param_delivery_cost VARCHAR(250),
    param_delivery_date VARCHAR(250), param_alert_date TIMESTAMP, param_invoicingtype_id INT,
    param_paymenttype_id INT, param_status CHAR(2), 
    param_dimension_unit CHAR(10), param_weight_unit CHAR(10), param_currency CHAR(3),
    param_description TEXT)
BEGIN

    IF EXISTS (SELECT * FROM orders WHERE id = param_id)
    THEN

        UPDATE orders
        SET
            order_for           = param_order_for,
            biz_id              = param_biz_id,
            company_id          = param_company_id,
            person_id           = param_person_id,
            buyer_ref           = param_buyer_ref,
            supplier_ref        = param_supplier_ref,
            delivery_point      = param_delivery_point,
            delivery_town       = param_delivery_town,
            delivery_cost       = param_delivery_cost,
            delivery_date       = IF (TRIM(param_delivery_date) = '', param_alert_date, param_delivery_date),
            alert_date          = param_alert_date,
            invoicingtype_id    = param_invoicingtype_id,
            paymenttype_id      = param_paymenttype_id,
            `status`            = IF(param_status = '', 'ip', param_status),
            dimension_unit      = param_dimension_unit,
            weight_unit         = param_weight_unit,
            currency            = param_currency,
            description         = param_description,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO orders
            SET
                order_for           = param_order_for,
                biz_id              = param_biz_id,
                company_id          = param_company_id,
                person_id           = param_person_id,
                buyer_ref           = param_buyer_ref,
                supplier_ref        = param_supplier_ref,
                delivery_point      = param_delivery_point,
                delivery_town       = param_delivery_town,
                delivery_cost       = param_delivery_cost,
                delivery_date       = IF (TRIM(param_delivery_date) = '', param_alert_date, param_delivery_date),
                alert_date          = param_alert_date,
                invoicingtype_id    = param_invoicingtype_id,
                paymenttype_id      = param_paymenttype_id,
                `status`            = param_status,
                dimension_unit      = param_dimension_unit,
                weight_unit         = param_weight_unit,
                currency            = param_currency,
                description         = param_description,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id;

            SET param_id = (SELECT MAX(id) FROM orders WHERE created_by = param_user_id);
            
        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_save_position$$
CREATE PROCEDURE sp_order_save_position(param_user_id INT, param_order_id INT, param_position_id INT, param_steelgrade_id INT, 
                            param_thickness CHAR(10), param_thickness_mm DECIMAL(10, 4), 
                            param_width CHAR(10), param_width_mm DECIMAL(10, 4), 
                            param_length CHAR(10), param_length_mm DECIMAL(10, 4),
                            param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10, 4),
                            param_qtty INT, param_weight CHAR(10), param_weight_ton DECIMAL(10, 4),
                            param_price DECIMAL(10, 4), param_value DECIMAL(10, 4), 
                            param_deliverytime VARCHAR(250), param_internal_notes VARCHAR(250), param_order_status CHAR(2))
sp:
BEGIN

    DECLARE var_order_qtty      INT DEFAULT 0;
    DECLARE var_delta_qtty      INT DEFAULT 0;


    
    
    
    IF EXISTS (SELECT * FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id)
    THEN

        UPDATE order_positions
        SET
            steelgrade_id   = param_steelgrade_id,
            thickness       = param_thickness,
            thickness_mm    = param_thickness_mm,
            width           = param_width,
            width_mm        = param_width_mm,
            `length`        = param_length,
            length_mm       = param_length_mm,
            unitweight      = param_unitweight,
            unitweight_ton  = param_unitweight_ton,
            qtty            = param_qtty,
            weight          = param_weight,
            weight_ton      = param_weight_ton,
            price           = param_price,
            `value`         = param_value,
            deliverytime    = param_deliverytime,
            internal_notes  = param_internal_notes,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE order_id = param_order_id
        AND position_id = param_position_id;
        
    ELSE

        INSERT order_positions
        SET
            order_id        = param_order_id,
            position_id     = param_position_id,
            steelgrade_id   = param_steelgrade_id,
            thickness       = param_thickness,
            thickness_mm    = param_thickness_mm,
            width           = param_width,
            width_mm        = param_width_mm,
            `length`        = param_length,
            length_mm       = param_length_mm,
            unitweight      = param_unitweight,
            unitweight_ton  = param_unitweight_ton,
            qtty            = param_qtty,
            weight          = param_weight,
            weight_ton      = param_weight_ton,
            price           = param_price,
            `value`         = param_value,
            deliverytime    = param_deliverytime,
            internal_notes  = param_internal_notes,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

    END IF;

    
    
    SET var_order_qtty = IFNULL((SELECT COUNT(*) FROM steelitems WHERE order_id = param_order_id AND steelposition_id = param_position_id), 0);

    
    
    IF (SELECT `status` FROM orders WHERE id = param_order_id) = ''
    THEN
        
        IF var_order_qtty != param_qtty
        THEN

            SET var_delta_qtty = param_qtty - var_order_qtty;
        
            
            IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) > 0 AND var_order_qtty > 0
            THEN
                CALL sp_order_update_steelitems(param_user_id, param_order_id, param_position_id, var_delta_qtty);
            END IF;

            
            CALL sp_order_lock_steelitems(param_user_id, param_order_id, param_position_id, var_delta_qtty);
            
        END IF;

        SET @ENABLE_TRIGGERS = FALSE;
        UPDATE steelpositions
        SET
            tech_action         = 'toorder',
            tech_object_alias   = 'order',
            tech_object_id      = param_order_id,
            tech_data           = param_qtty
        WHERE id = param_position_id;
        SET @ENABLE_TRIGGERS = TRUE;

    ELSE

        IF var_order_qtty != param_qtty
        THEN

            SET var_delta_qtty = param_qtty - var_order_qtty;
        
            
            IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) > 0 AND var_order_qtty > 0
            THEN
                CALL sp_order_update_steelitems(param_user_id, param_order_id, param_position_id, var_delta_qtty);
            END IF;
                
            
            CALL sp_order_lock_steelitems(param_user_id, param_order_id, param_position_id, var_delta_qtty);

        END IF;

        
        SET @ENABLE_TRIGGERS = FALSE;
        UPDATE steelpositions
        SET
            tech_action         = IF(param_qtty > var_order_qtty, 'toorder', 'tostock'),
            tech_object_alias   = 'order',
            tech_object_id      = param_order_id,
            tech_data           = ABS(var_delta_qtty)
        WHERE id = param_position_id;
        SET @ENABLE_TRIGGERS = TRUE;
    
    END IF;

    
    
    CALL sp_steelposition_update_qtty(param_user_id, param_position_id);

    
    UPDATE order_positions SET is_saved = 1 WHERE order_id = param_order_id AND position_id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_order_save_positions_from_stock$$
CREATE PROCEDURE sp_order_save_positions_from_stock(param_user_id INT, param_order_id INT, param_position_ids VARCHAR(1100))
sp:
BEGIN

    SET @var_stmt := CONCAT(  
        "
        INSERT IGNORE INTO order_positions(
            order_id,
            position_id,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            length,
            length_mm,
            unitweight,
            unitweight_ton,
            qtty,
            weight,
            weight_ton,
            price,
            value,
            internal_notes,
            is_saved,
            created_at,
            created_by,
            modified_at,
            modified_by)
        SELECT ", param_order_id, ",  
            id,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            length,
            length_mm,
            unitweight,
            unitweight_ton,
            qtty,
            weight,
            weight_ton,
            price,
            value,
            internal_notes,
            0,
            NOW(),
            ", param_user_id, ",
            NOW(),
            ", param_user_id, " 
        FROM steelpositions
        WHERE id IN (", param_position_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_test_position_qtty$$
CREATE PROCEDURE sp_order_test_position_qtty(param_user_id INT, param_order_id INT, param_position_id INT, param_qtty INT, param_order_new_status CHAR(2))
sp:
BEGIN

    DECLARE var_order_qtty INT DEFAULT 0;
    DECLARE var_stock_qtty INT DEFAULT 0;

    
    IF param_order_new_status = 'ca'
    THEN
        SELECT TRUE AS available, 0 AS qtty;
        LEAVE sp;
    END IF;

    
    IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) > 0
    THEN
        SELECT TRUE AS available, 0 AS qtty;
        LEAVE sp;
    END IF;


    SET var_order_qtty = IFNULL((SELECT qtty FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id), 0);
    SET var_stock_qtty = (SELECT qtty FROM steelpositions WHERE id = param_position_id);
    SET var_stock_qtty = var_order_qtty + var_stock_qtty;

    IF var_stock_qtty >= param_qtty
    THEN
        SELECT TRUE AS available, var_stock_qtty AS qtty;
    ELSE
        SELECT FALSE AS available, var_stock_qtty AS qtty;
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_update_position_qtty$$
CREATE PROCEDURE sp_order_update_position_qtty(param_user_id INT, param_order_id INT, param_position_id INT)
BEGIN

    DECLARE var_qtty        INT DEFAULT 0;
    DECLARE var_prev_qtty   INT DEFAULT 0;

    
    SET var_prev_qtty   = IFNULL((
        SELECT 
            qtty 
        FROM order_positions 
        WHERE order_id = param_order_id
        AND position_id = param_position_id
    ), 0);

    SET var_qtty = IFNULL((
        SELECT
            COUNT(*)
        FROM steelitems
        WHERE steelposition_id = param_position_id
        AND order_id = param_order_id
    ), 0);


    UPDATE order_positions
    SET
        qtty        = var_qtty,
        weight      = unitweight * qtty,
        weight_ton  = unitweight_ton * qtty,
        `value`     = price * unitweight * qtty,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE order_id = param_order_id
    AND position_id = param_position_id;


    
    SET @ENABLE_TRIGGERS = FALSE;
    UPDATE steelpositions
    SET
        tech_action         = IF(var_qtty > var_prev_qtty, 'toorder', 'tostock'),
        tech_object_alias   = 'order',
        tech_object_id      = param_order_id,
        tech_data           = ABS(var_qtty - var_prev_qtty)
    WHERE id = param_position_id;
    SET @ENABLE_TRIGGERS = TRUE;

END
$$

DROP PROCEDURE IF EXISTS sp_order_update_steelitems$$
CREATE PROCEDURE sp_order_update_steelitems(param_user_id INT, param_order_id INT, param_position_id INT, param_delta_qtty INT)
BEGIN

    DECLARE var_steelitem_id INT DEFAULT 0;
    DECLARE var_i INT DEFAULT 1;

    IF param_delta_qtty > 0
    THEN
    
        WHILE var_i <= param_delta_qtty
        DO
        
            START TRANSACTION;
            
                INSERT INTO steelitems(
                    guid,
					alias,
					steelposition_id,
                    product_id,
                    biz_id,
                    stockholder_id,
                    location_id,
                    dimension_unit,
                    weight_unit,
                    currency,
                    parent_id,
                    rel,
                    steelgrade_id,
                    thickness,
                    thickness_mm,
                    thickness_measured,
                    width,
                    width_mm,
                    width_measured,
                    width_max,
                    length,
                    length_mm,
                    length_measured,
                    length_max,
                    unitweight,
                    unitweight_ton,
                    price,
                    `value`,
                    supplier_id,
                    supplier_invoice_no,
                    supplier_invoice_date,
                    purchase_price,
                    purchase_value,
                    purchase_currency,
                    in_ddt_number,
                    in_ddt_date,
                    ddt_number,
                    ddt_date,
                    deliverytime_id,
                    notes,
                    internal_notes,
                    owner_id,
                    `status`,
                    is_virtual,
                    is_available,
                    is_deleted,
                    mill,
                    system,
                    unitweight_measured,
                    unitweight_weighed,
                    current_cost,
                    pl,
                    load_ready,
                    is_from_order,
                    order_id,
                    created_at,
                    created_by,
                    modified_at,
                    modified_by                
                )
                SELECT
                    '',
					'',
					param_position_id,
                    product_id,
                    biz_id,
                    0,
                    0,
                    dimension_unit,
                    weight_unit,
                    currency,
                    0,
                    '',
                    steelgrade_id,
                    thickness,
                    thickness_mm,
                    0,
                    width,
                    width_mm,
                    0,
                    0,
                    `length`,
                    length_mm,
                    0,
                    0,
                    unitweight,
                    unitweight_ton,
                    price,
                    `value`,
                    0,
                    '',
                    NULL,
                    0,
                    0,
                    currency,
                    '',
                    NULL,
                    '',
                    NULL,
                    0,
                    '',
                    internal_notes,
                    0,
                    'new',
                    0,
                    0,
                    0,
                    '',
                    '',
                    0,
                    0,
                    0,
                    0,
                    '',
                    1,
                    param_order_id,
                    NOW(),
                    param_user_id,
                    NOW(),
                    param_user_id
                FROM steelpositions
                WHERE id = param_position_id;

                SET var_steelitem_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);

                INSERT INTO steelitem_properties(
                    item_id,
                    heat_lot,
                    c,
                    si,
                    mn,
                    p,
                    s,
                    cr,
                    ni,
                    cu,
                    al,
                    mo,
                    nb,
                    v,
                    n,
                    ti,
                    sn,
                    b,
                    ceq,
                    tensile_sample_direction,
                    tensile_strength,
                    yeild_point,
                    elongation,
                    reduction_of_area,
                    test_temp,
                    impact_strength,
                    hardness,
                    ust,
                    sample_direction,
                    stress_relieving_temp,
                    heating_rate_per_hour,
                    holding_time,
                    cooling_down_rate,
                    `condition`,
                    normalizing_temp,
                    created_at,
                    created_by,
                    modified_at,
                    modified_by
                )
                SELECT
                    var_steelitem_id,
                    '',
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    '',
                    0,
                    0,
                    0,
                    0,
                    0,
                    '',
                    0,
                    '',
                    '',
                    0,
                    0,
                    0,
                    0,
                    '',
                    0,
                    NOW(),
                    param_user_id,
                    NOW(),
                    param_user_id;
            
            COMMIT;            

            SET var_i = var_i + 1;

        END WHILE;

    ELSE
        
        SET param_delta_qtty    = -1 * param_delta_qtty;
        SET var_steelitem_id    = (
            SELECT 
                id
            FROM steelitems
            WHERE steelposition_id = param_position_id
            ORDER BY order_id, guid, created_at DESC
            LIMIT 1
        );

        WHILE var_i <= param_delta_qtty
        DO
            
            DELETE FROM steelitems WHERE id = var_steelitem_id;

            SET var_steelitem_id    = (SELECT MAX(id) FROM steelitems WHERE steelposition_id = param_position_id AND id < var_steelitem_id);
            SET var_i = var_i + 1;

        END WHILE;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_page_get_by_url$$
CREATE PROCEDURE sp_page_get_by_url(param_domain CHAR(2), param_url VARCHAR(255))
sp:
BEGIN

    DECLARE var_id INT DEFAULT 0;

    SET var_id = IFNULL((SELECT id FROM pages WHERE domain = param_domain AND url = param_url), 0);

    IF var_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_page_get_by_url' AS ErrorAlias;
        LEAVE sp;
    END IF;

    SELECT var_id AS page_id;

END
$$

DROP PROCEDURE IF EXISTS sp_page_get_list$$
CREATE PROCEDURE sp_page_get_list()
BEGIN

    SELECT
        id AS page_id
    FROM pages
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_page_get_list_by_ids$$
CREATE PROCEDURE sp_page_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_page_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM pages
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_page_save$$
CREATE PROCEDURE sp_page_save(param_user_id INT, param_id INT, param_title VARCHAR(250), 
                    param_description TEXT, param_meta_keywords VARCHAR(1000), 
                    param_meta_description TEXT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM pages WHERE id = param_id)
    THEN

        UPDATE pages
        SET
            title               = param_title,
            description         = param_description,
            meta_keywords       = param_meta_keywords,
            meta_description    = param_meta_description,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT pages
        SET
            title               = param_title,
            description         = param_description,
            meta_keywords       = param_meta_keywords,
            meta_description    = param_meta_description,
            created_at          = NOW(),
            created_by          = param_user_id,
            modified_at         = NOW(),
            modified_by         = param_user_id;

        SET param_id := (SELECT MAX(id) FROM pages WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_paymenttype_get_by_title$$
CREATE PROCEDURE sp_paymenttype_get_by_title(param_title VARCHAR(250))
sp:
BEGIN

    SELECT 
        id AS paymenttype_id
    FROM paymenttypes
    WHERE title = param_title;

END
$$

DROP PROCEDURE IF EXISTS sp_paymenttype_get_list$$
CREATE PROCEDURE sp_paymenttype_get_list()
BEGIN

    SELECT 
        id AS paymenttype_id
    FROM paymenttypes
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_paymenttype_get_list_by_ids$$
CREATE PROCEDURE sp_paymenttype_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_paymenttype_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            * 
        FROM paymenttypes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_paymenttype_save$$
CREATE PROCEDURE sp_paymenttype_save(param_user_id INT, param_id INT, param_title VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT id FROM paymenttypes WHERE id != param_id AND TRIM(title) = TRIM(param_title))
    THEN
        SELECT -1 AS ErrorCode, 'sp_paymenttype_save' AS ErroAt;
        LEAVE sp;
    END IF;

    IF param_id > 0
    THEN

        UPDATE paymenttypes
        SET
            title       = param_title,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO paymenttypes
            SET
                title       = param_title,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;
            
            SET param_id = (SELECT MAX(id) FROM paymenttypes WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_person_get_contacts_by_ids$$
CREATE PROCEDURE sp_person_get_contacts_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_person_get_contacts_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            object_id AS id,
            type,
            title,
            description
        FROM contactdata
        WHERE object_alias = 'person'
        AND object_id IN (", param_ids, ");");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_person_get_list_by_ids$$
CREATE PROCEDURE sp_person_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_person_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM persons
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_person_save$$
CREATE PROCEDURE sp_person_save(param_user_id INT, param_id INT, param_alias VARCHAR(32), param_title CHAR(5), param_first_name VARCHAR(50), 
                                param_middle_name VARCHAR(50), param_last_name VARCHAR(50), param_name_for_label VARCHAR(250), 
                                param_company_id INT(11), param_department_id INT(11), param_jobposition_id INT(11),                                 
                                param_country_id INT(11), param_region_id INT(11), param_city_id INT(11), param_zip VARCHAR(50), 
                                param_address VARCHAR(250), param_languages VARCHAR(250), param_notes TEXT, param_birthday TIMESTAMP,
                                param_gender CHAR(1))
sp:
BEGIN

    IF EXISTS (SELECT * FROM persons WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_person_save' AS ErrorAlias;
        LEAVE sp;
    END IF;


    IF param_title = 'mr' OR param_title = 'sr'
    THEN
        SET param_gender = 'm';
    ELSEIF param_title = 'miss' OR param_title = 'mrs' OR param_title = 'sra'
    THEN
        SET param_gender = 'f';
    END IF;

    
    IF param_id > 0
    THEN

        UPDATE persons
        SET
            title           = param_title,
            first_name      = param_first_name,
            middle_name     = param_middle_name,
            last_name       = param_last_name,
            name_for_label  = param_name_for_label,
            company_id      = param_company_id,
            department_id   = param_department_id,
            jobposition_id  = param_jobposition_id,
            country_id      = param_country_id,
            region_id       = param_region_id,
            city_id         = param_city_id,
            zip             = param_zip,
            address         = param_address,
            languages       = param_languages,
            notes           = param_notes,
            birthday        = param_birthday,
            gender          = param_gender,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO persons
            SET
                title           = param_title,
                first_name      = param_first_name,
                middle_name     = param_middle_name,
                last_name       = param_last_name,
                name_for_label  = param_name_for_label,
                company_id      = param_company_id,
                department_id   = param_department_id,
                jobposition_id  = param_jobposition_id,
                country_id      = param_country_id,
                region_id       = param_region_id,
                city_id         = param_city_id,
                zip             = param_zip,
                address         = param_address,
                languages       = param_languages,
                notes           = param_notes,
                birthday        = param_birthday,
                picture_id      = 0,
                alias           = param_alias,
                gender          = param_gender,
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;

            SET param_id = (SELECT MAX(id) FROM persons WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_post_delete$$
CREATE PROCEDURE sp_post_delete(param_id INT)
BEGIN

    SELECT * FROM posts WHERE id = param_id;

    IF EXISTS (SELECT * FROM comments WHERE object_alias = 'post' AND object_id = param_id)
    THEN

        UPDATE posts
        SET 
            is_deleted = 1
        WHERE id = param_id;

    ELSE

        DELETE FROM posts WHERE id = param_id;

    END IF;


END
$$

DROP PROCEDURE IF EXISTS sp_post_get_archive_navigation$$
CREATE PROCEDURE sp_post_get_archive_navigation(param_section CHAR(10), param_topic_id INT)
BEGIN

    SELECT DISTINCT
        `year`,
        `month`
    FROM posts
    WHERE section = param_section
    AND (topic_id = param_topic_id OR param_topic_id = 0)
    ORDER BY `year`, `month`;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_forum_active_list$$
CREATE PROCEDURE sp_post_get_forum_active_list(param_from INT, param_count INT)
sp:
BEGIN

    DROP TEMPORARY TABLE IF EXISTS t_posts;
    CREATE TEMPORARY TABLE t_posts(post_id INT, created_at DATETIME);
    
    INSERT INTO t_posts(post_id, created_at)
    SELECT
        id,
        (SELECT MAX(created_at) FROM comments WHERE object_alias = 'post' AND object_id = posts.id)
    FROM posts
    WHERE section = 'forum'
    AND is_deleted = 0;

    
    PREPARE stmt FROM
    "SELECT 
        *
    FROM t_posts
    ORDER BY created_at DESC
    LIMIT ?, ?;";

    SET @stmt_from      = param_from;
    SET @stmt_count     = param_count;
    
    EXECUTE stmt USING @stmt_from, @stmt_count;


    SELECT 
        COUNT(*) AS rows
    FROM t_posts;


    DROP TEMPORARY TABLE IF EXISTS t_posts;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_list$$
CREATE PROCEDURE sp_post_get_list(param_section CHAR(20), param_topic_id INT, param_from INT, param_count INT)
sp:
BEGIN

    IF param_topic_id > 0
    THEN
        IF EXISTS (SELECT * FROM topics WHERE id = param_topic_id)
        THEN
            SET param_section = (SELECT section FROM topics WHERE id = param_topic_id);
        END IF;
    END IF;


    PREPARE stmt FROM
    "SELECT
        id AS post_id
    FROM posts
    WHERE section = ?
    AND (topic_id = ? OR ? = 0)
    AND is_deleted = 0
    ORDER BY `date` DESC, id DESC
    LIMIT ?, ?;";

    SET @stmt_section   = param_section;
    SET @stmt_topic_id  = param_topic_id;
    SET @stmt_from      = param_from;
    SET @stmt_count     = param_count;
    
    EXECUTE stmt USING @stmt_section, @stmt_topic_id, @stmt_topic_id, @stmt_from, @stmt_count;


    SELECT 
        COUNT(*) AS rows
    FROM posts
    WHERE section = param_section
    AND (topic_id = param_topic_id OR param_topic_id = 0)
    AND is_deleted = 0;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_list_by_ids$$
CREATE PROCEDURE sp_post_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN
    
    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_post_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(
    "SELECT 
        *,
        IFNULL((SELECT id FROM attachments WHERE object_alias = 'post' AND object_id = posts.id AND is_main = 1 LIMIT 1), 0) AS picture_id
    FROM posts
    WHERE id IN (", param_ids, ")
    ORDER BY id
    LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_list_by_year_month_day$$
CREATE PROCEDURE sp_post_get_list_by_year_month_day(param_section CHAR(10), param_year INT, param_month INT, param_day INT, param_from INT, param_count INT)
sp:
BEGIN

    PREPARE stmt FROM
    "SELECT
        id AS post_id,
        topic_id,
        created_by AS user_id
    FROM posts
    WHERE 
        section = ?
        AND (`year` = ? OR ? = 0)
        AND (`month` = ? OR ? = 0)
        AND (`day` = ? OR ? = 0)

    ORDER BY `date` DESC, id DESC
    LIMIT ?, ?;";

    SET @stmt_section   = param_section;
    SET @stmt_year      = param_year;
    SET @stmt_month     = param_month;
    SET @stmt_day       = param_day;        
    SET @stmt_from      = param_from;
    SET @stmt_count     = param_count + 1;

    
    EXECUTE stmt USING 
    @stmt_section, 
    @stmt_year, @stmt_year, 
    @stmt_month, @stmt_month, 
    @stmt_day, @stmt_day,
    @stmt_from, @stmt_count;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_list_from_archive$$
CREATE PROCEDURE sp_post_get_list_from_archive(param_section CHAR(10), param_topic_id INT, param_year INT, param_month INT, 
                                                param_from INT, param_count INT)
BEGIN

    PREPARE stmt FROM
    "SELECT
        id AS post_id
    FROM posts
    WHERE 
        section = ?
        AND (topic_id = ? OR ? = 0)
        AND (`year` = ? OR ? = 0)
        AND (`month` = ? OR ? = 0)
        AND is_deleted = 0
    ORDER BY `date` DESC, id DESC
    LIMIT ?, ?;";

    SET @stmt_section   = param_section;
    SET @stmt_topic     = param_topic_id;
    SET @stmt_year      = param_year;
    SET @stmt_month     = param_month;
    SET @stmt_from      = param_from;
    SET @stmt_count     = param_count + 1;

    
    EXECUTE stmt USING 
    @stmt_section, 
    @stmt_topic, @stmt_topic, 
    @stmt_year, @stmt_year, 
    @stmt_month, @stmt_month, 
    @stmt_from, @stmt_count;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_navigation_by_year$$
CREATE PROCEDURE sp_post_get_navigation_by_year(param_section CHAR(10), param_year INT)
BEGIN
       
    SELECT DISTINCT
        `year`
    FROM posts
    WHERE section = param_section
    ORDER BY `year` DESC;

    SELECT DISTINCT
        `month`
    FROM posts
    WHERE section = param_section
    AND `year` = param_year
    ORDER BY `month`;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_page_no$$
CREATE PROCEDURE sp_post_get_page_no(param_post_id INT, param_per_page INT)
BEGIN

    DECLARE var_section     CHAR(10) DEFAULT '';
    DECLARE var_topic_id    INT DEFAULT 0;

    
    SELECT
        section,
        topic_id
    INTO
        var_section,
        var_topic_id
    FROM posts
    WHERE id = param_post_id;


    SELECT CEIL((SELECT COUNT(*) FROM posts WHERE section = var_section AND topic_id = var_topic_id AND id <= param_post_id) / param_per_page) AS page_no;

END
$$

DROP PROCEDURE IF EXISTS sp_post_get_quick_by_ids$$
CREATE PROCEDURE sp_post_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_post_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM object_visits WHERE object_alias = 'post' AND object_id = p.id) AS visits_count,
            (SELECT COUNT(*) FROM comments WHERE object_alias = 'post' AND object_id = p.id) AS comments_count,
            (SELECT id FROM comments WHERE object_alias = 'post' AND object_id = p.id ORDER BY id DESC LIMIT 1) AS last_comment_id
        FROM posts p
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_post_save$$
CREATE PROCEDURE sp_post_save(param_user_id INT, param_id INT, param_section CHAR(10), param_topic_id INT, param_date DATETIME, 
                            param_title VARCHAR(250), param_brief VARCHAR(2000), param_description TEXT, param_source VARCHAR(500), 
                            param_tags VARCHAR(500))
sp:
BEGIN

    
    IF EXISTS (SELECT id FROM posts WHERE id = param_id)
    THEN

        UPDATE posts
        SET
            topic_id    = CASE WHEN section = 'news' THEN param_topic_id ELSE topic_id END,
            `date`      = param_date,
            `day`       = DAYOFMONTH(param_date),
            `month`     = MONTH(param_date), 
            `year`      = YEAR(param_date), 
            title       = param_title,
            brief       = param_brief,
            description = param_description,
            `source`    = param_source,
            tags        = param_tags,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT INTO posts 
        SET
            section     = param_section,
            topic_id    = param_topic_id,
            `date`      = param_date,
            `day`       = DAYOFMONTH(param_date),
            `month`     = MONTH(param_date), 
            `year`      = YEAR(param_date), 
            title       = param_title,
            brief       = param_brief,
            description = param_description,
            `source`    = param_source,
            tags        = param_tags,
            is_closed   = 0,
            is_deleted  = 0,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;
        
            
        SET param_id := (SELECT MAX(id) FROM posts WHERE created_by = param_user_id);
        
        UPDATE topics SET last_post_id = param_id WHERE id = param_topic_id;

    END IF;

    SELECT * FROM posts WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_post_update_last_comment$$
CREATE PROCEDURE sp_post_update_last_comment(param_post_id INT, param_comment_id INT)
BEGIN

    IF EXISTS (SELECT * FROM posts WHERE id = param_post_id) 
    AND EXISTS (SELECT * FROM comments WHERE id = param_comment_id)
    THEN
    
        UPDATE posts 
        SET 
            last_comment_id = param_comment_id 
        WHERE id = param_post_id;
        
        UPDATE topics 
        SET 
            last_comment_id = param_comment_id 
        WHERE id = (SELECT topic_id FROM posts WHERE id = param_post_id);

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_get_by_guid$$
CREATE PROCEDURE sp_preorder_get_by_guid(param_guid VARCHAR(32))
BEGIN

    SELECT 
        *
    FROM preorders
    WHERE guid = param_guid;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_get_list$$
CREATE PROCEDURE sp_preorder_get_list(param_user_id INT)
BEGIN

    SELECT
        *
    FROM preorders
    WHERE created_by = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_get_positions$$
CREATE PROCEDURE sp_preorder_get_positions(param_guid INT)
BEGIN

    SELECT
        *
    FROM preorder_positions
    WHERE guid = param_guid;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_get_position_items$$
CREATE PROCEDURE sp_preorder_get_position_items(param_guid VARCHAR(32), param_position_id INT)
BEGIN

    SELECT 
        item_id
    FROM preorder_items
    WHERE guid = param_guid
    AND position_id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_items_add_from_stock$$
CREATE PROCEDURE sp_preorder_items_add_from_stock(param_user_id INT, param_guid VARCHAR(32), param_item_ids VARCHAR(1100))
BEGIN

    SET @var_stmt := CONCAT(  
        "
        INSERT IGNORE INTO preorder_items(
            guid,
            position_id,
            item_id
        )
        SELECT '", param_guid, "',  
            steelposition_id,
            id
        FROM steelitems
        WHERE id IN (", param_item_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

    SET @var_stmt := CONCAT(  
        "
        SELECT 
            steelposition_id
        FROM steelitems
        WHERE id IN (", param_item_ids, ");
        ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_items_move_to_order$$
CREATE PROCEDURE sp_preorder_items_move_to_order(param_user_id INT, param_guid VARCHAR(32), param_order_id INT)
BEGIN

        UPDATE steelitems
        SET
            order_id        = param_order_id,
            is_available    = 0,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id IN (SELECT item_id FROM preorder_items WHERE guid = param_guid)
        AND is_available = 1 AND order_id = 0;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_position_add_from_stock$$
CREATE PROCEDURE sp_preorder_position_add_from_stock(param_user_id INT, param_guid VARCHAR(32), param_position_id INT)
sp:
BEGIN

    DECLARE var_qtty INT DEFAULT 0;

    IF EXISTS (SELECT * FROM preorder_items WHERE guid = param_guid AND position_id = param_position_id)
    THEN
        SET var_qtty = (SELECT COUNT(*) FROM preorder_items WHERE guid = param_guid AND position_id = param_position_id);
    ELSE
        SET var_qtty = (SELECT qtty FROM steelpositions WHERE id = param_position_id);
    END IF;

    INSERT IGNORE INTO preorder_positions(
        guid,
        position_id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        qtty,
        weight,
        weight_ton,
        price,
        `value`,
        internal_notes,
        is_saved,
        created_at,
        created_by,
        modified_at,
        modified_by)
    SELECT 
        param_guid,  
        id,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        var_qtty,
        unitweight * var_qtty,
        unitweight_ton * var_qtty,
        price,
        unitweight * var_qtty * price,
        internal_notes,
        0,
        NOW(),
        param_user_id,
        NOW(),
        param_user_id
    FROM steelpositions
    WHERE id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_remove$$
CREATE PROCEDURE sp_preorder_remove(param_user_id INT, param_guid VARCHAR(32))
BEGIN

    DELETE FROM preorder_items WHERE guid = param_guid;
    DELETE FROM preorder_positions WHERE guid = param_guid;
    DELETE FROM preorders WHERE guid = param_guid;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_remove_position$$
CREATE PROCEDURE sp_preorder_remove_position(param_guid VARCHAR(32), param_position_id INT)
sp:
BEGIN

    DELETE FROM preorder_positions WHERE guid = param_guid AND position_id = param_position_id;
    DELETE FROM preorder_items WHERE guid = param_guid AND position_id = param_position_id;


    IF NOT EXISTS (SELECT * FROM steelpositions WHERE id = param_position_id)
    THEN
        LEAVE sp;
    END IF;


    IF (SELECT is_from_order FROM steelpositions WHERE id = param_position_id) = 1
    THEN

        DELETE FROM steelpositions WHERE id = param_position_id;
        DELETE FROM steelitems WHERE is_from_order = 1 AND steelposition_id = param_position_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_save$$
CREATE PROCEDURE sp_preorder_save(param_user_id INT, param_guid VARCHAR(32), param_order_for CHAR(5), param_biz_id INT,
    param_company_id INT, param_person_id INT, param_buyer_ref VARCHAR(50), param_supplier_ref VARCHAR(50),
    param_delivery_point CHAR(3), param_delivery_town VARCHAR(250), param_delivery_cost VARCHAR(250),
    param_delivery_date VARCHAR(250), param_alert_date TIMESTAMP, param_invoicingtype_id INT,
    param_paymenttype_id INT, param_status CHAR(2), 
    param_dimension_unit CHAR(10), param_weight_unit CHAR(10), param_currency CHAR(3),
    param_description TEXT)
BEGIN


    IF EXISTS (SELECT * FROM preorders WHERE guid = param_guid)
    THEN

        UPDATE preorders
        SET
            order_for           = param_order_for,
            biz_id              = param_biz_id,
            company_id          = param_company_id,
            person_id           = param_person_id,
            buyer_ref           = param_buyer_ref,
            supplier_ref        = param_supplier_ref,
            delivery_point      = param_delivery_point,
            delivery_town       = param_delivery_town,
            delivery_cost       = param_delivery_cost,
            delivery_date       = param_delivery_date,
            alert_date          = param_alert_date,
            invoicingtype_id    = param_invoicingtype_id,
            paymenttype_id      = param_paymenttype_id,
            dimension_unit      = param_dimension_unit,
            weight_unit         = param_weight_unit,
            currency            = param_currency,
            description         = param_description,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE guid = param_guid;
    
    ELSE

        INSERT INTO preorders
        SET
            guid                = param_guid,
            order_for           = param_order_for,
            biz_id              = param_biz_id,
            company_id          = param_company_id,
            person_id           = param_person_id,
            buyer_ref           = param_buyer_ref,
            supplier_ref        = param_supplier_ref,
            delivery_point      = param_delivery_point,
            delivery_town       = param_delivery_town,
            delivery_cost       = param_delivery_cost,
            delivery_date       = param_delivery_date,
            alert_date          = param_alert_date,
            invoicingtype_id    = param_invoicingtype_id,
            paymenttype_id      = param_paymenttype_id,
            `status`            = '',
            dimension_unit      = param_dimension_unit,
            weight_unit         = param_weight_unit,
            currency            = param_currency,
            description         = param_description,
            created_at          = NOW(),
            created_by          = param_user_id,
            modified_at         = NOW(),
            modified_by         = param_user_id;
    
    END IF;



    SELECT param_guid AS guid;

END
$$

DROP PROCEDURE IF EXISTS sp_preorder_save_position$$
CREATE PROCEDURE sp_preorder_save_position(param_user_id INT, param_guid VARCHAR(32), param_position_id INT, param_steelgrade_id INT, 
                            param_thickness CHAR(10), param_thickness_mm DECIMAL(10, 4), param_width CHAR(10), param_width_mm DECIMAL(10, 4), 
                            param_length CHAR(10), param_length_mm DECIMAL(10, 4), param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10, 4),
                            param_qtty INT, param_weight CHAR(10), param_weight_ton DECIMAL(10, 4), param_price DECIMAL(10, 4), param_value DECIMAL(10, 4), 
                            param_deliverytime VARCHAR(250), param_internal_notes VARCHAR(250), param_order_status CHAR(2))
sp:
BEGIN

    IF EXISTS (SELECT * FROM preorder_positions WHERE guid = param_guid AND position_id = param_position_id)
    THEN

        UPDATE preorder_positions
        SET
            steelgrade_id   = param_steelgrade_id,
            thickness       = param_thickness,
            thickness_mm    = param_thickness_mm,
            width           = param_width,
            width_mm        = param_width_mm,
            `length`        = param_length,
            length_mm       = param_length_mm,
            unitweight      = param_unitweight,
            unitweight_ton  = param_unitweight_ton,
            qtty            = param_qtty,
            weight          = param_weight,
            weight_ton      = param_weight_ton,
            price           = param_price,
            `value`         = param_value,
            deliverytime    = param_deliverytime,
            internal_notes  = param_internal_notes,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE guid = param_guid
        AND position_id = param_position_id;
        
    ELSE

        INSERT preorder_positions
        SET
            guid            = param_guid,
            position_id     = param_position_id,
            steelgrade_id   = param_steelgrade_id,
            thickness       = param_thickness,
            thickness_mm    = param_thickness_mm,
            width           = param_width,
            width_mm        = param_width_mm,
            `length`        = param_length,
            length_mm       = param_length_mm,
            unitweight      = param_unitweight,
            unitweight_ton  = param_unitweight_ton,
            qtty            = param_qtty,
            weight          = param_weight,
            weight_ton      = param_weight_ton,
            price           = param_price,
            `value`         = param_value,
            deliverytime    = param_deliverytime,
            internal_notes  = param_internal_notes,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_product_get_list$$
CREATE PROCEDURE sp_product_get_list(param_team_id INT, param_parent_id INT)
BEGIN

    SELECT
        id AS product_id
    FROM products
    WHERE (team_id = param_team_id OR param_team_id = 0)
    AND (parent_id = param_parent_id OR param_parent_id = -1)
    AND is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_product_get_list_by_ids$$
CREATE PROCEDURE sp_product_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_product_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            p.*,
            (SELECT COUNT(*) FROM products WHERE parent_id = p.id) AS children_count
        FROM products AS p
        WHERE p.id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_product_get_tariffcodes$$
CREATE PROCEDURE sp_product_get_tariffcodes(param_user_id INT, param_product_id INT)
BEGIN

    SELECT
        *
    FROM product_tariffcodes
    WHERE product_id = param_product_id
    AND is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_product_remove$$
CREATE PROCEDURE sp_product_remove(param_user_id INT, param_id INT)
BEGIN

    SELECT id, parent_id FROM products WHERE id = param_id;
    
    UPDATE products
    SET
        is_deleted  = 1,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_product_remove_tariffcode$$
CREATE PROCEDURE sp_product_remove_tariffcode(param_user_id INT, param_id INT)
BEGIN

    DELETE FROM product_tariffcodes
    WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_product_save$$
CREATE PROCEDURE sp_product_save(param_user_id INT, param_id INT, param_parent_id INT, param_team_id INT, 
                                param_title VARCHAR(250), param_alias VARCHAR(32), param_description TEXT)
sp:
BEGIN

    DECLARE var_level INT DEFAULT 0;
    
    IF EXISTS (SELECT * FROM products WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_product_save' AS ErrorAlias;
        LEAVE sp;
    END IF;
    

    SET var_level = IFNULL((SELECT `level` + 1 FROM products WHERE id = param_parent_id), 0);
    
    IF param_id > 0
    THEN

        UPDATE products
        SET
            parent_id   = param_parent_id,
            team_id     = param_team_id,
            `level`     = var_level,
            title       = param_title,
            alias       = param_alias,
            description = param_description,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
        
            INSERT INTO products
            SET
                parent_id   = param_parent_id,
                team_id     = param_team_id,
                `level`     = var_level,
                title       = param_title,
                alias       = param_alias,
                description = param_description,
                is_deleted  = 0,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET param_id = (SELECT MAX(id) FROM products WHERE created_by  = param_user_id);
        
        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_product_save_tariffcode$$
CREATE PROCEDURE sp_product_save_tariffcode(param_user_id INT, param_id INT, param_product_id INT, param_title VARCHAR(250), param_description VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT * FROM product_tariffcodes WHERE title = param_title AND product_id = param_product_id AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_product_save_tariffcode' AS ErrorAt;
        LEAVE sp;
    END IF;


    IF EXISTS (SELECT * FROM product_tariffcodes WHERE id = param_id)
    THEN

        UPDATE product_tariffcodes
        SET
            title       = param_title,
            description = param_description,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE
             
        INSERT product_tariffcodes
        SET
            product_id  = param_product_id,
            title       = param_title,
            description = param_description,
            is_deleted  = 0,
            created_at  = NOW(),
            created_by  = param_user_id,            
            modified_at = NOW(),
            modified_by = param_user_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_qctype_get_by_title$$
CREATE PROCEDURE sp_qctype_get_by_title(param_title VARCHAR(250))
sp:
BEGIN

    SELECT 
        id AS qctype_id
    FROM qctypes
    WHERE title = param_title;

END
$$

DROP PROCEDURE IF EXISTS sp_qctype_get_list$$
CREATE PROCEDURE sp_qctype_get_list()
BEGIN

    SELECT 
        id AS qctype_id
    FROM qctypes
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_qctype_get_list_by_ids$$
CREATE PROCEDURE sp_qctype_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_qctype_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            * 
        FROM qctypes
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_qctype_save$$
CREATE PROCEDURE sp_qctype_save(param_user_id INT, param_id INT, param_title VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT id FROM qctypes WHERE id != param_id AND TRIM(title) = TRIM(param_title))
    THEN
        SELECT -1 AS ErrorCode, 'sp_qctype_save' AS ErroAt;
        LEAVE sp;
    END IF;

    IF param_id > 0
    THEN

        UPDATE qctypes
        SET
            title       = param_title,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO qctypes
            SET
                title       = param_title,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;
            
            SET param_id = (SELECT MAX(id) FROM qctypes WHERE created_by = param_user_id);

        COMMIT;

    END IF;

    
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_region_get_list$$
CREATE PROCEDURE sp_region_get_list(param_country_id INT)
BEGIN

    SELECT
        id AS region_id
    FROM regions
    WHERE country_id = param_country_id
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_region_get_list_by_ids$$
CREATE PROCEDURE sp_region_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_region_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM regions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_region_get_quick_by_ids$$
CREATE PROCEDURE sp_region_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_region_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM companies WHERE region_id = regions.id) AS companies_count,
            (SELECT COUNT(*) FROM persons WHERE region_id = regions.id) AS persons_count,
            (SELECT COUNT(*) FROM cities WHERE region_id = regions.id) AS cities_count
        FROM regions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_region_remove$$
CREATE PROCEDURE sp_region_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM cities WHERE region_id = param_id)
    OR EXISTS (SELECT * FROM persons WHERE region_id = param_id)
    OR EXISTS (SELECT * FROM companies WHERE region_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_region_remove' AS ErrorAt;
        LEAVE sp;    
    END IF;

    
    DELETE FROM regions WHERE id = param_id;
    SELECT param_id AS id;
        
END
$$

DROP PROCEDURE IF EXISTS sp_region_save$$
CREATE PROCEDURE sp_region_save(param_user_id INT, param_id INT, param_country_id INT, param_title VARCHAR(250), param_alias VARCHAR(32), 
                                param_title1 VARCHAR(250), param_title2 VARCHAR(250))
sp:
BEGIN

    IF EXISTS (SELECT * FROM regions WHERE id != param_id AND alias = param_alias)
    THEN
        SELECT -1 AS ErrorCode, 'sp_region_save' AS ErrorAt;
        LEAVE sp;    
    END IF;
    
    IF param_id > 0
    THEN

        IF NOT EXISTS (SELECT * FROM regions WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'sp_region_save' AS ErrorAt;
            LEAVE sp;
        END IF;

        UPDATE regions
        SET
            country_id  = param_country_id,
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT INTO regions
        SET
            country_id  = param_country_id,
            title       = param_title,
            alias       = param_alias,
            title1      = param_title1,
            title2      = param_title2,
            created_at  = NOW(),
            created_by  = param_user_id,
            modified_at = NOW(),
            modified_by = param_user_id;            

        SET param_id = (SELECT MAX(id) FROM regions WHERE created_by  = param_user_id);

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_sc_clear_positions$$
CREATE PROCEDURE sp_sc_clear_positions(param_user_id INT, param_sc_id INT)
BEGIN

    DELETE FROM sc_positions 
    WHERE sc_id = param_sc_id;

END
$$

DROP PROCEDURE IF EXISTS sp_sc_get_list_by_ids$$
CREATE PROCEDURE sp_sc_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_sc_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *,
            YEAR(created_at) as created_year
        FROM sc
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_sc_get_list_by_order$$
CREATE PROCEDURE sp_sc_get_list_by_order(param_user_id INT, param_order_id INT)
BEGIN

    SELECT 
        id AS sc_id
    FROM sc
    WHERE order_id = param_order_id
    ORDER BY id DESC;

END
$$

DROP PROCEDURE IF EXISTS sp_sc_get_positions$$
CREATE PROCEDURE sp_sc_get_positions(param_sc_id INT)
BEGIN

    SELECT
        *
    FROM sc_positions
    WHERE sc_id = param_sc_id;

END
$$

DROP PROCEDURE IF EXISTS sp_sc_get_quick_by_ids$$
CREATE PROCEDURE sp_sc_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_sc_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            IFNULL((SELECT MAX(id) FROM attachments WHERE object_alias = 'sc' AND object_id = sc.id), 0) AS attachment_id
        FROM sc
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_sc_save$$
CREATE PROCEDURE sp_sc_save(param_user_id INT, param_id INT, param_order_id INT, param_person_id INT, param_delivery_point VARCHAR(250),
                            param_delivery_date VARCHAR(250), param_chemical_composition TEXT, param_tolerances TEXT, 
                            param_hydrogen_control TEXT, param_surface_quality TEXT, param_surface_condition TEXT, param_side_edges TEXT,
                            param_marking TEXT, param_packing TEXT, param_stamping TEXT, param_ust_standard TEXT, param_dunnaging_requirements TEXT,
                            param_documents_supplied TEXT, param_front_and_back_ends TEXT, param_origin TEXT, param_inspection TEXT,
                            param_delivery_form TEXT, param_reduction_of_area TEXT, param_testing TEXT, param_delivery_cost VARCHAR(250),
                            param_qctype_id INT, param_notes TEXT, param_transport_mode VARCHAR(250))
BEGIN



    IF param_id > 0
    THEN
        
        UPDATE sc
        SET
            person_id               = param_person_id,
            delivery_point          = param_delivery_point,
            delivery_date           = param_delivery_date,
            chemical_composition    = param_chemical_composition,
            tolerances              = param_tolerances,
            hydrogen_control        = param_hydrogen_control,
            surface_quality         = param_surface_quality,
            surface_condition       = param_surface_condition,
            side_edges              = param_side_edges,
            marking                 = param_marking,
            packing                 = param_packing,
            stamping                = param_stamping,
            ust_standard            = param_ust_standard,
            dunnaging_requirements  = param_dunnaging_requirements,
            documents_supplied      = param_documents_supplied,
            front_and_back_ends     = param_front_and_back_ends,
            origin                  = param_origin,
            inspection              = param_inspection,
            delivery_form           = param_delivery_form,
            reduction_of_area       = param_reduction_of_area,
            testing                 = param_testing,
            delivery_cost           = param_delivery_cost,
            qctype_id               = param_qctype_id,
            notes                   = param_notes,
            transport_mode          = param_transport_mode,
            modified_at             = NOW(),
            modified_by             = param_user_id            
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO sc
            SET
                order_id                = param_order_id,
                person_id               = param_person_id,
                delivery_point          = param_delivery_point,
                delivery_date           = param_delivery_date,                
                chemical_composition    = param_chemical_composition,
                tolerances              = param_tolerances,
                hydrogen_control        = param_hydrogen_control,
                surface_quality         = param_surface_quality,
                surface_condition       = param_surface_condition,
                side_edges              = param_side_edges,
                marking                 = param_marking,
                packing                 = param_packing,
                stamping                = param_stamping,
                ust_standard            = param_ust_standard,
                dunnaging_requirements  = param_dunnaging_requirements,
                documents_supplied      = param_documents_supplied,
                front_and_back_ends     = param_front_and_back_ends,
                origin                  = param_origin,
                inspection              = param_inspection,
                delivery_form           = param_delivery_form,
                reduction_of_area       = param_reduction_of_area,
                testing                 = param_testing,
                delivery_cost           = param_delivery_cost,
                qctype_id               = param_qctype_id,
                notes                   = param_notes,
                transport_mode          = param_transport_mode,
                is_sent                 = 0,
                is_returned             = 0,
                created_at              = NOW(),
                created_by              = param_user_id,
                modified_at             = NOW(),
                modified_by             = param_user_id;           

            SET param_id = (SELECT MAX(id) FROM sc WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;
    
END
$$

DROP PROCEDURE IF EXISTS sp_sc_save_position$$
CREATE PROCEDURE sp_sc_save_position(param_user_id INT, param_sc_id INT, param_position_id INT)
BEGIN

    INSERT INTO sc_positions
    SET
        sc_id       = param_sc_id,
        position_id = param_position_id,
        created_at  = param_user_id,
        created_by  = NOW();

END
$$

DROP PROCEDURE IF EXISTS sp_steelgrade_get_list$$
CREATE PROCEDURE sp_steelgrade_get_list()
BEGIN

    SELECT
        id AS steelgrade_id
    FROM steelgrades
    WHERE is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_steelgrade_get_list_by_ids$$
CREATE PROCEDURE sp_steelgrade_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelgrade_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM steelgrades
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_steelgrade_get_quick_by_ids$$
CREATE PROCEDURE sp_steelgrade_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelgrade_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM steelgrades
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_steelgrade_remove$$
CREATE PROCEDURE sp_steelgrade_remove(param_user_id INT, param_id INT)
BEGIN

    IF EXISTS (SELECT * FROM steelitems WHERE steelgrade_id = param_id)
        OR EXISTS (SELECT * FROM steelpositions WHERE steelgrade_id = param_id)
    THEN
        
        UPDATE steelgrades
        SET
            is_deleted = 1,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        DELETE FROM steelgrades WHERE id = param_id;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelgrade_save$$
CREATE PROCEDURE sp_steelgrade_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_alias VARCHAR(10), 
                                    param_bgcolor VARCHAR(20), param_color VARCHAR(20), param_description TEXT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM steelgrades WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelgrade_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM steelgrades WHERE id = param_id)
    THEN

        UPDATE steelgrades
        SET
            title           = param_title,
            alias           = param_alias,
            description     = param_description,
            bgcolor         = param_bgcolor,
            color           = param_color,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT steelgrades
        SET
            title           = param_title,
            alias           = param_alias,
            description     = param_description,
            bgcolor         = param_bgcolor,
            color           = param_color,
            is_deleted      = 0,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id := (SELECT MAX(id) FROM steelgrades WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitems_prepare_revision$$
CREATE PROCEDURE sp_steelitems_prepare_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN

    DECLARE var_tn VARCHAR(50) DEFAULT '';
    SET var_tn = sf_get_revision_table_name('steelitems_history', param_date);


    SET @var_stmt = CONCAT('DROP TABLE IF EXISTS ', var_tn, ';');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    SET @var_stmt = CONCAT('CREATE TABLE ', var_tn, ' LIKE steelitems;');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    DROP TEMPORARY TABLE IF EXISTS ids;
    CREATE TEMPORARY TABLE ids(id INT);

    INSERT INTO ids(id) SELECT MAX(id) FROM steelitems_history WHERE record_at <= param_date GROUP BY steelitem_id;

    SET @var_stmt = CONCAT('INSERT INTO ', var_tn, '(
        id,
        guid,
        product_id,
        biz_id,
        stockholder_id,
        location_id,
        dimension_unit,
        weight_unit,
        currency,
        parent_id,
        rel,
        steelgrade_id,
        thickness,
        thickness_mm,
        thickness_measured,
        width,
        width_mm,
        width_measured,
        width_max,
        length,
        length_mm,
        length_measured,
        length_max,
        unitweight,
        unitweight_ton,
        price,
        value,
        supplier_id,
        supplier_invoice_no,
        supplier_invoice_date,
        purchase_price,
        purchase_value,
        in_ddt_number,
        in_ddt_date,
        ddt_number,
        ddt_date,
        deliverytime_id,
        notes,
        internal_notes,
        owner_id,
        status,
        is_virtual,
        is_available,
        is_deleted,
        mill,
        system,
        unitweight_measured,
        unitweight_weighed,
        current_cost,
        pl,
        load_ready,
        order_id,
        created_at,
        created_by,
        modified_at,
        modified_by
    )
    SELECT 
        steelitem_id,
        guid,
        product_id,
        biz_id,
        stockholder_id,
        location_id,
        dimension_unit,
        weight_unit,
        currency,
        parent_id,
        rel,
        steelgrade_id,
        thickness,
        thickness_mm,
        thickness_measured,
        width,
        width_mm,
        width_measured,
        width_max,
        length,
        length_mm,
        length_measured,
        length_max,
        unitweight,
        unitweight_ton,
        price,
        value,
        supplier_id,
        supplier_invoice_no,
        supplier_invoice_date,
        purchase_price,
        purchase_value,
        in_ddt_number,
        in_ddt_date,        
        ddt_number,
        ddt_date,
        deliverytime_id,
        notes,
        internal_notes,
        owner_id,
        status,
        is_virtual,
        is_available,
        is_deleted,
        mill,
        system,
        unitweight_measured,
        unitweight_weighed,
        current_cost,
        pl,
        load_ready,
        order_id,
        created_at,
        created_by,
        modified_at,
        modified_by
    FROM ids
    JOIN steelitems_history ON steelitems_history.id = ids.id
    WHERE act != \'d\'');

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  

    
    DROP TEMPORARY TABLE IF EXISTS ids;


END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_check_guid$$
CREATE PROCEDURE sp_steelitem_check_guid(param_id INT, param_guid VARCHAR(32))
BEGIN

    SELECT
        *
    FROM steelitems
    WHERE guid = param_guid 
    AND id != param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_cut$$
CREATE PROCEDURE sp_steelitem_cut(param_user_id INT, param_item_id INT, param_stockholder_id INT, param_width CHAR(10), param_width_mm DECIMAL(10,4), 
                                    param_length CHAR(10), param_length_mm DECIMAL(10,4), param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10,4), 
                                    param_position_id INT)
sp:
BEGIN

    DECLARE var_new_item_id INT DEFAULT 0;
    DECLARE var_location_id INT DEFAULT 0;


    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND is_available = 1 AND is_deleted = 0 AND parent_id = 0)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_cut' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SET var_location_id = (SELECT location_id FROM companies WHERE id = param_stockholder_id);


    START TRANSACTION;
    
        INSERT INTO steelitems (
            guid,
			alias,
            steelposition_id,
            product_id,
            biz_id,
            stockholder_id,
            location_id,
            dimension_unit,
            weight_unit,
            currency,
            parent_id,
            rel,
            steelgrade_id,
            thickness,
            thickness_mm,
            thickness_measured,
            width,
            width_mm,
            width_measured,
            width_max,
            `length`,
            length_mm,
            length_measured,
            length_max,
            unitweight,
            unitweight_ton,
            price,
            `value`,
            supplier_id,
            supplier_invoice_no,
            supplier_invoice_date,
            purchase_price,
            purchase_value,
            ddt_number,
            ddt_date,
            deliverytime_id,
            notes,
            internal_notes,
            owner_id,
            `status`,
            is_virtual,
            is_available,
            is_deleted,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            '',
			'',
            param_position_id,
            product_id,
            (SELECT biz_id FROM steelpositions WHERE id = param_position_id),
            param_stockholder_id,
            var_location_id,
            (SELECT dimension_unit FROM steelpositions WHERE id = param_position_id),
            (SELECT weight_unit FROM steelpositions WHERE id = param_position_id),
            (SELECT currency FROM steelpositions WHERE id = param_position_id),
            param_item_id,
            'c',
            steelgrade_id,
            thickness,
            thickness_mm,
            0,
            param_width,
            param_width_mm,
            0,
            0,
            param_length,
            param_length_mm,
            0,
            0,
            param_unitweight,
            param_unitweight_ton,
            (SELECT price FROM steelpositions WHERE id = param_position_id),
            (SELECT param_unitweight * price FROM steelpositions WHERE id = param_position_id),
            supplier_id,
            supplier_invoice_no,
            supplier_invoice_date,
            purchase_price,
            purchase_value,
            ddt_number,
            ddt_date,
            deliverytime_id,
            notes,
            internal_notes,
            owner_id,
            'new',
            1,
            1,
            0,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id
        FROM steelitems
        WHERE id = param_item_id;

        SET var_new_item_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);

        INSERT INTO steelitem_properties(
            item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            var_new_item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id
        FROM steelitem_properties
        WHERE item_id = param_item_id;

    COMMIT;


    SELECT param_item_id AS item_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_history$$
CREATE PROCEDURE sp_steelitem_get_history(param_user_id INT, param_steelitem_id INT)
sp:
BEGIN

    DROP TEMPORARY TABLE IF EXISTS tmp_items;
    CREATE TEMPORARY TABLE tmp_items(revision_id INT AUTO_INCREMENT, item_history_id INT, item_properties_history_id INT, record_at TIMESTAMP, record_by INT, PRIMARY KEY(revision_id));
    
    
    IF  (SELECT COUNT(*) FROM steelitem_properties_history WHERE item_id = param_steelitem_id) >
        (SELECT COUNT(*) FROM steelitems_history WHERE steelitem_id = param_steelitem_id)
    THEN

        INSERT INTO tmp_items(item_history_id, item_properties_history_id, record_at, record_by)
        SELECT
            CASE WHEN 
                EXISTS (SELECT id FROM steelitems_history WHERE steelitem_id = param_steelitem_id AND record_at >= steelitem_properties_history.record_at)
            THEN
                (SELECT id FROM steelitems_history WHERE steelitem_id = param_steelitem_id AND record_at >= steelitem_properties_history.record_at LIMIT 1)
            ELSE
                (SELECT id FROM steelitems_history WHERE steelitem_id = param_steelitem_id ORDER BY record_at DESC LIMIT 1)
            END,
            id,
            record_at,
            record_by
        FROM steelitem_properties_history
        WHERE item_id = param_steelitem_id
        ORDER BY id DESC;

    ELSE

        INSERT INTO tmp_items(item_history_id, item_properties_history_id, record_at, record_by)
        SELECT
            id,
            CASE WHEN 
                EXISTS (SELECT id FROM steelitem_properties_history WHERE item_id = param_steelitem_id AND record_at >= steelitems_history.record_at)
            THEN
                (SELECT id FROM steelitem_properties_history WHERE item_id = param_steelitem_id AND record_at >= steelitems_history.record_at LIMIT 1)
            ELSE
                (SELECT id FROM steelitem_properties_history WHERE item_id = param_steelitem_id ORDER BY record_at DESC LIMIT 1)
            END,
            record_at,
            record_by
        FROM steelitems_history
        WHERE steelitem_id = param_steelitem_id
        ORDER BY id DESC;
    
    END IF;
    
    SELECT 
        tmp_items.revision_id,
        steelitems_history.*,
        heat_lot,
        c,
        si,
        mn,
        p,
        s,
        cr,
        ni,
        cu,
        al,
        mo,
        nb,
        v,
        n,
        ti,
        sn,
        b,
        ceq,
        tensile_sample_direction,
        tensile_strength,
        yeild_point,
        elongation,
        reduction_of_area,
        test_temp,
        impact_strength,
        hardness,
        ust,
        sample_direction,
        stress_relieving_temp,
        heating_rate_per_hour,
        holding_time,
        cooling_down_rate,
        `condition`,
        normalizing_temp,
        (SELECT stock_id FROM steelpositions WHERE id = steelitems_history.steelposition_id) AS stock_id,
        DATEDIFF((SELECT created_at FROM steelitems_history WHERE steelitem_id = param_steelitem_id ORDER BY id LIMIT 1), ddt_date) AS ddt_days_on_stock, 
        DATEDIFF((SELECT created_at FROM steelitems_history WHERE steelitem_id = param_steelitem_id ORDER BY id LIMIT 1), steelitems_history.created_at) AS days_on_stock,
        item_history_id,
        item_properties_history_id,
        tmp_items.record_at AS history_record_at,
        tmp_items.record_by AS history_record_by
    FROM tmp_items
    JOIN steelitems_history ON steelitems_history.id = tmp_items.item_history_id
    JOIN steelitem_properties_history ON steelitem_properties_history.id = tmp_items.item_properties_history_id
    ORDER BY tmp_items.revision_id;

    DROP TEMPORARY TABLE IF EXISTS tmp_items;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_history_revision$$
CREATE PROCEDURE sp_steelitem_get_history_revision(param_item_id INT, param_item_history_id INT, param_item_properties_history_id INT)
BEGIN

    SELECT
        *
    FROM steelitems_history
    WHERE steelitem_id = param_item_id
    AND id <= param_item_history_id
    ORDER BY id DESC 
    LIMIT 2;

    SELECT
        *
    FROM steelitem_properties_history
    WHERE item_id = param_item_id
    AND id <= param_item_properties_history_id
    ORDER BY id DESC 
    LIMIT 2;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list$$
CREATE PROCEDURE sp_steelitem_get_list(param_user_id INT, param_stock_id INT, param_locations VARCHAR(100), param_deliverytimes VARCHAR(100), 
                                        param_is_real TINYINT, param_is_virtual TINYINT, param_is_twin TINYINT, param_is_cut TINYINT, 
                                        param_steelgrade_id INT, 
                                        param_thickness_from DECIMAL(10,4), param_thickness_to DECIMAL(10,4), 
                                        param_width_from DECIMAL(10,4), param_width_to DECIMAL(10,4), 
                                        param_length_from DECIMAL(10,4), param_length_to DECIMAL(10,4), 
                                        param_weight_from DECIMAL(10,4), param_weight_to DECIMAL(10,4), 
                                        param_keyword VARCHAR(50), param_plateid VARCHAR(32), param_available TINYINT, param_revision VARCHAR(12))
sp:
BEGIN
    
    DECLARE var_where   VARCHAR(4000) DEFAULT '';
    DECLARE var_type    VARCHAR(1000) DEFAULT '';
    DECLARE var_rev     VARCHAR(50) DEFAULT '';

    IF param_stock_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_get_list' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_rev     = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");
    SET var_where   = " WHERE si.is_deleted = 0";

    
    IF TRIM(param_locations) = '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.stockholder_id IN (SELECT company_id FROM stock_locations", var_rev, " WHERE stock_id = ", param_stock_id, ")");     
    ELSE
        SET var_where = CONCAT(var_where, " AND si.stockholder_id IN (", param_locations, ")");     
    END IF;

    IF TRIM(param_deliverytimes) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.deliverytime_id IN (", param_deliverytimes, ")"); 
    END IF;

    IF param_steelgrade_id > 0 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.steelgrade_id = ", param_steelgrade_id); 
    END IF;

    IF param_is_real > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "si.is_virtual = 0"); 
    END IF;

    IF param_is_virtual > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.is_virtual = 1 AND si.parent_id = 0)"); 
    END IF;

    IF param_is_twin > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.parent_id > 0 AND rel = 't')"); 
    END IF;

    IF param_is_cut > 0
    THEN
        IF TRIM(var_type) != '' THEN SET var_type = CONCAT(var_type, " OR "); END IF;
        SET var_type = CONCAT(var_type, "(si.parent_id > 0 AND rel = 'c')"); 
    END IF;

    IF TRIM(var_type) != ''
    THEN
        SET var_where = CONCAT(var_where, " AND (", var_type, ")"); 
    END IF;


    IF TRIM(param_plateid) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND si.guid LIKE '%", param_plateid, "%'"); 
    END IF;

    IF param_available > 0
    THEN
        SET var_where = CONCAT(var_where, " AND si.is_available = 1"); 
    END IF;

    

    IF param_thickness_from > 0 OR param_thickness_to > 0
    THEN 
        
        IF param_thickness_from > 0 AND param_thickness_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.thickness_mm >= ", param_thickness_from, " AND si.thickness_mm <= ", param_thickness_to, ")"); 
        ELSEIF param_thickness_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.thickness_mm >= ", param_thickness_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.thickness_mm <= ", param_thickness_to); 
        END IF;
                
    END IF;
    
    IF param_width_from > 0 OR param_width_to > 0
    THEN 
        
        IF param_width_from > 0 AND param_width_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.width_mm >= ", param_width_from, " AND si.width_mm <= ", param_width_to, ")"); 
        ELSEIF param_width_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.width_mm >= ", param_width_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.width_mm <= ", param_width_to); 
        END IF;
                
    END IF;

    IF param_length_from > 0 OR param_length_to > 0
    THEN 
        
        IF param_length_from > 0 AND param_length_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.length_mm >= ", param_length_from, " AND si.length_mm <= ", param_length_to, ")"); 
        ELSEIF param_length_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.length_mm >= ", param_length_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.length_mm <= ", param_length_to); 
        END IF;
                
    END IF;

    IF param_weight_from > 0 OR param_weight_to > 0
    THEN 
        
        IF param_weight_from > 0 AND param_weight_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (si.unitweight_ton >= ", param_weight_from, " AND si.unitweight_ton <= ", param_weight_to, ")"); 
        ELSEIF param_weight_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND si.unitweight_ton >= ", param_weight_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND si.unitweight_ton <= ", param_weight_to); 
        END IF;
                
    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET var_where = CONCAT(var_where, " AND (si.notes LIKE '%", param_keyword, "%' OR si.internal_notes LIKE '%", param_keyword, "%')"); 
    END IF;

    
    DROP TEMPORARY TABLE IF EXISTS t_items;
    CREATE TEMPORARY TABLE t_items(id INT, steelgrade VARCHAR(50), thickness DECIMAL(10,4), width DECIMAL(10, 4), `length` DECIMAL(10,4));
        
    SET @var_stmt := CONCAT("   INSERT INTO t_items(id, steelgrade, thickness, width, `length`)
                                SELECT 
                                    si.id,
                                    (SELECT alias FROM steelgrades WHERE id = si.steelgrade_id),
                                    si.thickness_mm,
                                    si.width_mm,
                                    si.length_mm
                                FROM steelitems", var_rev, " AS si", var_where);

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

    SELECT 
        id AS steelitem_id 
    FROM t_items
    ORDER BY steelgrade, thickness, width, `length`;


    DROP TEMPORARY TABLE IF EXISTS t_items;


END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_get_list_by_ids$$
CREATE PROCEDURE sp_steelitem_get_list_by_ids(param_ids VARCHAR(1100), param_revision VARCHAR(12))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *,
            DATEDIFF(NOW(), in_ddt_date)   AS ddt_days_on_stock, 
            DATEDIFF(NOW(), created_at) AS days_on_stock
        FROM steelitems", IF(TRIM(param_revision), CONCAT("_history_", param_revision), ""), " AS si 
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_move$$
CREATE PROCEDURE sp_steelitem_move(param_user_id INT, param_id INT, param_dest_stockholder_id INT, param_dest_position_id INT, param_source_position_id INT)
sp:
BEGIN

    DECLARE var_location_id INT DEFAULT 0;

    IF param_dest_position_id = param_source_position_id
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id AND is_available = 1 AND is_deleted = 0)
    THEN
        SELECT -2 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_location_id = (SELECT location_id FROM companies WHERE id = param_dest_stockholder_id);

    
    
    IF param_source_position_id > 0 AND NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id AND steelposition_id = param_source_position_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    
    SELECT 
        steelposition_id
    FROM steelitems 
    WHERE id = param_id
    AND (steelposition_id = param_source_position_id OR param_source_position_id = 0);


    
    UPDATE steelitems
    SET
        steelposition_id    = param_dest_position_id,
        biz_id              = (SELECT biz_id FROM steelpositions WHERE id = param_dest_position_id),
        stockholder_id      = param_dest_stockholder_id,
        location_id         = var_location_id,
        dimension_unit      = (SELECT dimension_unit FROM steelpositions WHERE id = param_dest_position_id),
        weight_unit         = (SELECT weight_unit FROM steelpositions WHERE id = param_dest_position_id),
        currency            = (SELECT currency FROM steelpositions WHERE id = param_dest_position_id),
        steelgrade_id       = (SELECT steelgrade_id FROM steelpositions WHERE id = param_dest_position_id),
        thickness           = (SELECT thickness FROM steelpositions WHERE id = param_dest_position_id),
        thickness_mm        = (SELECT thickness_mm FROM steelpositions WHERE id = param_dest_position_id),
        width               = (SELECT width FROM steelpositions WHERE id = param_dest_position_id),
        width_mm            = (SELECT width_mm FROM steelpositions WHERE id = param_dest_position_id),
        `length`            = (SELECT `length` FROM steelpositions WHERE id = param_dest_position_id),
        length_mm           = (SELECT length_mm FROM steelpositions WHERE id = param_dest_position_id),
        unitweight          = (SELECT unitweight FROM steelpositions WHERE id = param_dest_position_id),
        unitweight_ton      = (SELECT unitweight_ton FROM steelpositions WHERE id = param_dest_position_id),
        price               = (SELECT price FROM steelpositions WHERE id = param_dest_position_id),
        `value`             = (SELECT unitweight * price FROM steelpositions WHERE id = param_dest_position_id)
    WHERE id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_properties_prepare_revision$$
CREATE PROCEDURE sp_steelitem_properties_prepare_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN


    DECLARE var_tn VARCHAR(50) DEFAULT '';
    SET var_tn = sf_get_revision_table_name('steelitem_properties_history', param_date);


    SET @var_stmt = CONCAT('DROP TABLE IF EXISTS ', var_tn, ';');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    SET @var_stmt = CONCAT('CREATE TABLE ', var_tn, ' LIKE steelitem_properties;');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    DROP TEMPORARY TABLE IF EXISTS ids;
    CREATE TEMPORARY TABLE ids(id INT);

    INSERT INTO ids(id) SELECT MAX(id) FROM steelitem_properties_history WHERE record_at <= param_date GROUP BY item_id;

    SET @var_stmt = CONCAT('INSERT INTO ', var_tn, '(
        id,
        item_id,
        heat_lot,
        c,
        si,
        mn,
        p,
        s,
        cr,
        ni,
        cu,
        al,
        mo,
        nb,
        v,
        n,
        ti,
        sn,
        b,
        ceq,
        tensile_sample_direction,
        tensile_strength,
        yeild_point,
        elongation,
        reduction_of_area,
        test_temp,
        impact_strength,
        hardness,
        ust,
        sample_direction,
        stress_relieving_temp,
        heating_rate_per_hour,
        holding_time,
        cooling_down_rate,
        `condition`,
        normalizing_temp,
        created_at,
        created_by,
        modified_at,
        modified_by
    )
    SELECT 
        ids.id,
        item_id,
        heat_lot,
        c,
        si,
        mn,
        p,
        s,
        cr,
        ni,
        cu,
        al,
        mo,
        nb,
        v,
        n,
        ti,
        sn,
        b,
        ceq,
        tensile_sample_direction,
        tensile_strength,
        yeild_point,
        elongation,
        reduction_of_area,
        test_temp,
        impact_strength,
        hardness,
        ust,
        sample_direction,
        stress_relieving_temp,
        heating_rate_per_hour,
        holding_time,
        cooling_down_rate,
        `condition`,
        normalizing_temp,
        created_at,
        created_by,
        modified_at,
        modified_by
    FROM ids
    JOIN steelitem_properties_history ON steelitem_properties_history.id = ids.id
    WHERE act != \'d\'');

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  

    
    DROP TEMPORARY TABLE IF EXISTS ids;


END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_properties_save$$
CREATE PROCEDURE sp_steelitem_properties_save(param_user_id INT, param_item_id INT, param_heat_lot VARCHAR(50), param_c DECIMAL(10, 4),
                                                param_si DECIMAL(10, 4), param_mn DECIMAL(10, 4), param_p DECIMAL(10, 4), param_s DECIMAL(10, 4),
                                                param_cr DECIMAL(10, 4), param_ni DECIMAL(10, 4), param_cu DECIMAL(10, 4), param_al DECIMAL(10, 4),
                                                param_mo DECIMAL(10, 4), param_nb DECIMAL(10, 4), param_v DECIMAL(10, 4), param_n DECIMAL(10, 4),
                                                param_ti DECIMAL(10, 4), param_sn DECIMAL(10, 4), param_b DECIMAL(10, 4), param_ceq DECIMAL(10, 4),
                                                param_tensile_sample_direction VARCHAR(50), param_tensile_strength INT, param_yeild_point INT, param_elongation DECIMAL(10, 4),
                                                param_reduction_of_area DECIMAL(10, 4), param_test_temp INT, param_impact_strength VARCHAR(20),
                                                param_hardness INT, param_ust VARCHAR(50), param_sample_direction VARCHAR(50),
                                                param_stress_relieving_temp INT, param_heating_rate_per_hour INT,
                                                param_holding_time INT, param_cooling_down_rate INT, param_condition CHAR(10), 
                                                param_normalizing_temp INT)
sp:
BEGIN

    DECLARE var_history_count INT DEFAULT 0;
    DECLARE var_properties_history_count INT DEFAULT 0;

    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id) 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_properties_save' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    
    IF EXISTS (SELECT * FROM steelitem_properties WHERE item_id = param_item_id)
    THEN
        
        UPDATE steelitem_properties
        SET
            heat_lot                    = param_heat_lot,
            c                           = param_c,
            si                          = param_si,
            mn                          = param_mn,
            p                           = param_p,
            s                           = param_s,
            cr                          = param_cr,
            ni                          = param_ni,
            cu                          = param_cu,
            al                          = param_al,
            mo                          = param_mo,
            nb                          = param_nb,
            v                           = param_v,
            n                           = param_n,
            ti                          = param_ti,
            sn                          = param_sn,
            b                           = param_b,
            ceq                         = param_ceq,
            tensile_sample_direction    = param_tensile_sample_direction,
            tensile_strength            = param_tensile_strength,
            yeild_point                 = param_yeild_point,
            elongation                  = param_elongation,
            reduction_of_area           = param_reduction_of_area,
            test_temp                   = param_test_temp,
            impact_strength             = param_impact_strength,
            hardness                    = param_hardness,
            ust                         = param_ust,
            sample_direction            = param_sample_direction,
            stress_relieving_temp       = param_stress_relieving_temp,
            heating_rate_per_hour       = param_heating_rate_per_hour,
            holding_time                = param_holding_time,
            cooling_down_rate           = param_cooling_down_rate,
            `condition`                 = param_condition,
            normalizing_temp            = param_normalizing_temp,
            modified_at                 = NOW(),
            modified_by                 = param_user_id
        WHERE item_id = param_item_id;


        SET var_history_count               = (SELECT COUNT(*) FROM steelitems_history WHERE steelitem_id = param_item_id);
        SET var_properties_history_count    = (SELECT COUNT(*) FROM steelitem_properties_history WHERE item_id = param_item_id);

        IF var_history_count != var_properties_history_count
        THEN
            
            IF var_history_count > var_properties_history_count
            THEN

                UPDATE steelitem_properties
                SET
                    tech_action = IF(tech_action = '', 'edit', '')
                WHERE item_id = param_item_id;

            ELSE

                UPDATE steelitems
                SET
                    tech_action = IF(tech_action = '', 'edit', '')
                WHERE id = param_item_id;

            END IF;

        END IF;
                
    ELSE

        START TRANSACTION;
        
            INSERT INTO steelitem_properties
            SET
                item_id                     = param_item_id,
                heat_lot                    = param_heat_lot,
                c                           = param_c,
                si                          = param_si,
                mn                          = param_mn,
                p                           = param_p,
                s                           = param_s,
                cr                          = param_cr,
                ni                          = param_ni,
                cu                          = param_cu,
                al                          = param_al,
                mo                          = param_mo,
                nb                          = param_nb,
                v                           = param_v,
                n                           = param_n,
                ti                          = param_ti,
                sn                          = param_sn,
                b                           = param_b,
                ceq                         = param_ceq,
                tensile_sample_direction    = param_tensile_sample_direction,
                tensile_strength            = param_tensile_strength,
                yeild_point                 = param_yeild_point,
                elongation                  = param_elongation,
                reduction_of_area           = param_reduction_of_area,
                test_temp                   = param_test_temp,
                impact_strength             = param_impact_strength,
                hardness                    = param_hardness,
                ust                         = param_ust,
                sample_direction            = param_sample_direction,
                stress_relieving_temp       = param_stress_relieving_temp,
                heating_rate_per_hour       = param_heating_rate_per_hour,
                holding_time                = param_holding_time,
                cooling_down_rate           = param_cooling_down_rate,
                `condition`                 = param_condition,
                normalizing_temp            = param_normalizing_temp,
                tech_action                 = '',
                created_at                  = NOW(),
                created_by                  = param_user_id,
                modified_at                 = NOW(),
                modified_by                 = param_user_id;

        COMMIT;
        
    END IF;
    

    SELECT param_item_id AS item_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_property_get_list_by_ids$$
CREATE PROCEDURE sp_steelitem_property_get_list_by_ids(param_ids VARCHAR(1100), param_revision VARCHAR(12))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_property_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            item_id AS id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            created_at,
            created_by,
            modified_at,
            modified_by
        FROM steelitem_properties", IF(TRIM(param_revision), CONCAT("_history_", param_revision), ''), 
        " WHERE item_id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_remove$$
CREATE PROCEDURE sp_steelitem_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    DROP TEMPORARY TABLE IF EXISTS tmp_items;
    CREATE TEMPORARY TABLE tmp_items(id INT(11), handled TINYINT, UNIQUE(id));

    DROP TEMPORARY TABLE IF EXISTS tmp_items1;
    CREATE TEMPORARY TABLE tmp_items1(id INT(11), UNIQUE(id));

    
    INSERT INTO tmp_items(id, handled)
    SELECT param_id, 0;

    WHILE (SELECT COUNT(*) FROM tmp_items WHERE handled = 0) > 0
    DO
        TRUNCATE TABLE tmp_items1;
        
        INSERT INTO tmp_items1(id) 
        SELECT id FROM tmp_items WHERE handled = 0;
        
        UPDATE tmp_items SET handled = 1 WHERE handled = 0;
        
        INSERT INTO tmp_items(id, handled)
        SELECT id, 0 FROM steelitems WHERE parent_id IN (SELECT id FROM tmp_items1);
            
    END WHILE;


    
    SELECT id AS steelitem_id, steelposition_id FROM steelitems WHERE id IN (SELECT id FROM tmp_items);
    
    
    UPDATE steelitem_properties SET modified_at = NOW(), modified_by = param_user_id WHERE item_id IN (SELECT id FROM steelitems WHERE id IN (SELECT id FROM tmp_items));
    DELETE FROM steelitem_properties WHERE item_id IN (SELECT id FROM tmp_items);

    
    UPDATE steelitems SET modified_at = NOW(), modified_by = param_user_id WHERE id IN (SELECT id FROM tmp_items);
    DELETE FROM steelitems WHERE id IN (SELECT id FROM tmp_items);
 

    DROP TEMPORARY TABLE IF EXISTS tmp_items;
    DROP TEMPORARY TABLE IF EXISTS tmp_items1;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_save$$
CREATE PROCEDURE sp_steelitem_save(param_user_id INT, param_id INT, param_position_id INT, param_guid VARCHAR(32), param_alias VARCHAR(32),
                                    param_product_id INT(11), param_biz_id INT(11), param_stockholder_id INT(11), param_dimension_unit CHAR(10), 
                                    param_weight_unit CHAR(10), param_currency CHAR(10), param_steelgrade_id INT, 
                                    param_thickness CHAR(10), param_thickness_mm DECIMAL(10, 4), param_thickness_measured CHAR(10), 
                                    param_width CHAR(10), param_width_mm DECIMAL(10, 4), param_width_measured CHAR(10), param_width_max CHAR(10), 
                                    param_length CHAR(10), param_length_mm DECIMAL(10, 4), param_length_measured CHAR(10), param_length_max CHAR(10), 
                                    param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10, 4), param_price DECIMAL(10, 4), 
                                    param_value DECIMAL(10, 4), param_supplier_id INT(11), param_supplier_invoice_no VARCHAR(50), 
                                    param_supplier_invoice_date TIMESTAMP, param_purchase_price DECIMAL(10, 4), param_purchase_value DECIMAL(10, 4), 
                                    param_in_ddt_number VARCHAR(50), param_in_ddt_date TIMESTAMP, 
                                    param_out_ddt_number VARCHAR(50), param_out_ddt_date TIMESTAMP, 
                                    param_deliverytime_id INT, param_notes TEXT, 
                                    param_internal_notes TEXT, param_owner_id INT(11), param_status CHAR(15), param_is_virtual TINYINT(4), 
                                    param_mill VARCHAR(50), param_system VARCHAR(50), param_unitweight_measured DECIMAL(10, 4),
                                    param_unitweight_weighed DECIMAL(10, 4), param_current_cost DECIMAL(10,4),
                                    param_pl DECIMAL(10,4), param_load_ready VARCHAR(50), param_purchase_currency CHAR(10))
sp:
BEGIN

    DECLARE var_location_id INT DEFAULT 0;

    IF TRIM(param_guid) != '' AND EXISTS (SELECT * FROM steelitems WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'steelitem_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SET param_is_virtual    = IF(TRIM(param_guid) != '', 0, param_is_virtual);
    SET var_location_id     = (SELECT location_id FROM companies WHERE id = param_stockholder_id);
        

    IF param_id > 0
    THEN

        IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'steelitem_save' AS ErrorAt;
            LEAVE sp;
        END IF;
    
        UPDATE steelitems
        SET
            guid                    = param_guid,
            alias                   = param_alias,
            product_id              = param_product_id,
            biz_id                  = param_biz_id,
            stockholder_id          = param_stockholder_id,
            location_id             = var_location_id,
            dimension_unit          = param_dimension_unit,
            weight_unit             = param_weight_unit,
            currency                = param_currency,            
            steelgrade_id           = param_steelgrade_id,
            thickness               = param_thickness,
            thickness_mm            = param_thickness_mm,
            thickness_measured      = param_thickness_measured,
            width                   = param_width,
            width_mm                = param_width_mm,
            width_measured          = param_width_measured,
            width_max               = param_width_max,
            `length`                = param_length,
            length_mm               = param_length_mm,
            length_measured         = param_length_measured,
            length_max              = param_length_max,
            unitweight              = param_unitweight,
            unitweight_ton          = param_unitweight_ton,
            price                   = param_price,
            `value`                 = param_value,
            supplier_id             = param_supplier_id,
            supplier_invoice_no     = param_supplier_invoice_no,
            supplier_invoice_date   = IF(param_supplier_invoice_date AND param_supplier_invoice_date != '', param_supplier_invoice_date, NULL),
            purchase_price          = param_purchase_price,
            purchase_value          = param_purchase_value,
            purchase_currency       = param_purchase_currency,
            in_ddt_number           = param_in_ddt_number,
            in_ddt_date             = IF(param_in_ddt_date AND param_in_ddt_date != '', param_in_ddt_date, NULL),
            ddt_number              = param_out_ddt_number,
            ddt_date                = IF(param_out_ddt_date AND param_out_ddt_date != '', param_out_ddt_date, NULL),
            deliverytime_id         = param_deliverytime_id,
            notes                   = param_notes,
            internal_notes          = param_internal_notes,
            owner_id                = param_owner_id,
            `status`                = param_status,
            is_virtual              = param_is_virtual,
            mill                    = param_mill,
            system                  = param_system,
            unitweight_measured     = param_unitweight_measured,
            unitweight_weighed      = param_unitweight_weighed,
            current_cost            = param_current_cost,
            pl                      = param_pl,
            load_ready              = param_load_ready,
            modified_at             = NOW(),
            modified_by             = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
            
            INSERT INTO steelitems
            SET
                steelposition_id        = param_position_id,
                guid                    = param_guid,
                alias                   = param_alias,
                product_id              = param_product_id,
                biz_id                  = param_biz_id,
                stockholder_id          = param_stockholder_id,
                location_id             = var_location_id,
                dimension_unit          = param_dimension_unit,
                weight_unit             = param_weight_unit,
                currency                = param_currency,
                parent_id               = 0,
                rel                     = '',
                steelgrade_id           = param_steelgrade_id,
                thickness               = param_thickness,
                thickness_mm            = param_thickness_mm,
                thickness_measured      = param_thickness_measured,
                width                   = param_width,
                width_mm                = param_width_mm,
                width_measured          = param_width_measured,
                width_max               = param_width_max,
                `length`                = param_length,
                length_mm               = param_length_mm,
                length_measured         = param_length_measured,
                length_max              = param_length_max,
                unitweight              = param_unitweight,
                unitweight_ton          = param_unitweight_ton,
                price                   = param_price,
                `value`                 = param_value,
                supplier_id             = param_supplier_id,
                supplier_invoice_no     = param_supplier_invoice_no,
                supplier_invoice_date   = null,
                purchase_price          = param_purchase_price,
                purchase_value          = param_purchase_value,
                purchase_currency       = param_purchase_currency,
                in_ddt_number           = '',
                in_ddt_date             = null,
                ddt_number              = '',
                ddt_date                = null,
                deliverytime_id         = param_deliverytime_id,
                notes                   = param_notes,
                internal_notes          = param_internal_notes,
                owner_id                = param_owner_id,
                `status`                = param_status,
                is_virtual              = param_is_virtual,
                is_available            = 1,
                is_deleted              = 0,
                mill                    = param_mill,
                system                  = param_system,
                unitweight_measured     = param_unitweight_measured,
                unitweight_weighed      = param_unitweight_weighed,
                current_cost            = param_current_cost,
                pl                      = param_pl,
                load_ready              = param_load_ready,
                is_from_order           = IF(param_stockholder_id > 0, 0, 1),
                order_id                = 0,
                tech_action             = '',
                created_at              = NOW(),
                created_by              = param_user_id,
                modified_at             = NOW(),
                modified_by             = param_user_id;
        
            SET param_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);
        
        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_twin$$
CREATE PROCEDURE sp_steelitem_twin(param_user_id INT, param_item_id INT, param_stockholder_id INT, param_position_id INT)
sp:
BEGIN

    DECLARE var_new_item_id INT DEFAULT 0;
    DECLARE var_location_id INT DEFAULT 0;
    

    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND is_available = 1 AND is_deleted = 0 AND parent_id = 0)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_twin' AS ErrorAt;
        LEAVE sp;
    END IF;    
    
    IF EXISTS (SELECT * FROM steelitems WHERE steelposition_id = param_position_id AND id IN (SELECT id FROM steelitems WHERE parent_id = param_item_id))
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_twin' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_location_id = (SELECT location_id FROM companies WHERE id = param_stockholder_id);


    START TRANSACTION;
    
        INSERT INTO steelitems (
            guid,
			alias,
            steelposition_id,
            product_id,
            biz_id,
            stockholder_id,
            location_id,
            dimension_unit,
            weight_unit,
            currency,
            parent_id,
            rel,
            steelgrade_id,
            thickness,
            thickness_mm,
            thickness_measured,
            width,
            width_mm,
            width_measured,
            width_max,
            `length`,
            length_mm,
            length_measured,
            length_max,
            unitweight,
            unitweight_ton,
            price,
            `value`,
            supplier_id,
            supplier_invoice_no,
            supplier_invoice_date,
            purchase_price,
            purchase_value,
            ddt_number,
            ddt_date,
            deliverytime_id,
            notes,
            internal_notes,
            owner_id,
            `status`,
            is_virtual,
            is_available,
            is_deleted,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            '',
			'',
            param_position_id,
            product_id,
            (SELECT biz_id FROM steelpositions WHERE id = param_position_id),
            param_stockholder_id,
            var_location_id,
            (SELECT dimension_unit FROM steelpositions WHERE id = param_position_id),
            (SELECT weight_unit FROM steelpositions WHERE id = param_position_id),
            (SELECT currency FROM steelpositions WHERE id = param_position_id),
            param_item_id,
            't',
            (SELECT steelgrade_id FROM steelpositions WHERE id = param_position_id),
            (SELECT thickness FROM steelpositions WHERE id = param_position_id),
            (SELECT thickness_mm FROM steelpositions WHERE id = param_position_id),
            0,
            (SELECT width FROM steelpositions WHERE id = param_position_id),
            (SELECT width_mm FROM steelpositions WHERE id = param_position_id),
            0,
            0,
            (SELECT `length` FROM steelpositions WHERE id = param_position_id),
            (SELECT length_mm FROM steelpositions WHERE id = param_position_id),
            0,
            0,
            (SELECT unitweight FROM steelpositions WHERE id = param_position_id),
            (SELECT unitweight_ton FROM steelpositions WHERE id = param_position_id),
            (SELECT price FROM steelpositions WHERE id = param_position_id),
            (SELECT unitweight * price FROM steelpositions WHERE id = param_position_id),
            supplier_id,
            supplier_invoice_no,
            supplier_invoice_date,
            purchase_price,
            purchase_value,
            ddt_number,
            ddt_date,
            deliverytime_id,
            notes,
            internal_notes,
            owner_id,
            'new',
            1,
            1,
            0,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id
        FROM steelitems
        WHERE id = param_item_id;

        SET var_new_item_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);

        INSERT INTO steelitem_properties(
            item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            var_new_item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id
        FROM steelitem_properties
        WHERE item_id = param_item_id;

    COMMIT;
	

    SELECT param_item_id AS item_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelpositions_prepare_revision$$
CREATE PROCEDURE sp_steelpositions_prepare_revision(param_user_id INT, param_date TIMESTAMP)
sp:
BEGIN

    
    DECLARE var_tn VARCHAR(50) DEFAULT '';
    SET var_tn = sf_get_revision_table_name('steelpositions_history', param_date);

    
    SET @var_stmt = CONCAT('DROP TABLE IF EXISTS ', var_tn, ';');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    SET @var_stmt = CONCAT('CREATE TABLE ', var_tn, ' LIKE steelpositions;');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    DROP TEMPORARY TABLE IF EXISTS ids;
    CREATE TEMPORARY TABLE ids(id INT);

    INSERT INTO ids(id) SELECT MAX(id) FROM steelpositions_history WHERE record_at <= param_date GROUP BY steelposition_id;

    SET @var_stmt = CONCAT('INSERT INTO ', var_tn, '(
        id,
        stock_id,
        product_id,
        biz_id,
        dimension_unit,
        weight_unit,
        currency,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        qtty,
        weight,
        weight_ton,
        price,
        value,
        deliverytime_id,
        notes,
        internal_notes,
        is_deleted,
        created_at,
        created_by,
        modified_at,
        modified_by)
    SELECT 
        steelposition_id,
        stock_id,
        product_id,
        biz_id,
        dimension_unit,
        weight_unit,
        currency,
        steelgrade_id,
        thickness,
        thickness_mm,
        width,
        width_mm,
        length,
        length_mm,
        unitweight,
        unitweight_ton,
        qtty,
        weight,
        weight_ton,
        price,
        value,
        deliverytime_id,
        notes,
        internal_notes,
        is_deleted,
        created_at,
        created_by,
        modified_at,
        modified_by
    FROM ids
    JOIN steelpositions_history ON steelpositions_history.id = ids.id
    WHERE act != \'d\'');

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  

    
    DROP TEMPORARY TABLE IF EXISTS ids;


END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_add_item$$
CREATE PROCEDURE sp_steelposition_add_item(param_user_id INT, param_steelposition_id INT, param_steelitem_id INT)
BEGIN

    IF NOT EXISTS (SELECT * FROM steelposition_items WHERE steelposition_id = param_steelposition_id AND steelitem_id = param_steelitem_id)
    THEN
        
        INSERT INTO steelposition_items
        SET
            steelposition_id    = param_steelposition_id,
            steelitem_id        = param_steelitem_id,
            created_at          = NOW(),
            created_by          = param_user_id;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_history$$
CREATE PROCEDURE sp_steelposition_get_history(IN param_user_id INT, IN param_steelposition_id INT)
BEGIN

    SELECT
        *
    FROM steelpositions_history
    WHERE steelposition_id = param_steelposition_id
    ORDER BY id DESC;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_items$$
CREATE PROCEDURE sp_steelposition_get_items(param_user_id INT, param_steelposition_id INT, param_only_active BOOLEAN, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(100) DEFAULT '';    
    SET var_rev = IF(TRIM(param_revision) != '', CONCAT('_history_', param_revision), '');


    SET @var_stmt := CONCAT(
    "SELECT
        id AS steelitem_id
    FROM steelitems", var_rev,
    " WHERE steelposition_id = ", param_steelposition_id, 
    " AND is_deleted = 0",
    IF(param_only_active, " AND is_available = 1", ""),  ";");


    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_list$$
CREATE PROCEDURE sp_steelposition_get_list(param_user_id INT, param_product_id INT, param_stock_id INT, param_locations VARCHAR(100), 
                                        param_deliverytimes VARCHAR(100), param_steelgrade_id INT, 
                                        param_thickness_from DECIMAL(10,4), param_thickness_to DECIMAL(10,4), 
                                        param_width_from DECIMAL(10,4), param_width_to DECIMAL(10,4), 
                                        param_length_from DECIMAL(10,4), param_length_to DECIMAL(10,4), 
                                        param_weight_from DECIMAL(10,4), param_weight_to DECIMAL(10,4), 
                                        param_keyword VARCHAR(50), param_revision VARCHAR(12))
sp:
BEGIN

    
    DECLARE var_where   VARCHAR(4000) DEFAULT '';
    DECLARE var_rev     VARCHAR(100) DEFAULT '';    

    
    SET var_rev     = IF(TRIM(param_revision) != '', CONCAT('_history_', param_revision), '');
    SET var_where   = CONCAT(" WHERE sp.is_from_order = 0 AND sp.is_deleted = 0 AND sp.qtty > 0 AND sp.stock_id = ", param_stock_id);

    
    IF param_product_id > 0 
    THEN 
        SET var_where = CONCAT(var_where, " AND sp.product_id = ", param_product_id); 
    END IF;
    
    IF param_steelgrade_id > 0 
    THEN 
        SET var_where = CONCAT(var_where, " AND sp.steelgrade_id = ", param_steelgrade_id); 
    END IF;
    
    IF TRIM(param_deliverytimes) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND sp.deliverytime_id IN (", param_deliverytimes, ")"); 
    END IF;

    IF param_thickness_from > 0 OR param_thickness_to > 0
    THEN 
        
        IF param_thickness_from > 0 AND param_thickness_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.thickness_mm >= ", param_thickness_from, " AND sp.thickness_mm <= ", param_thickness_to, ")"); 
        ELSEIF param_thickness_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.thickness_mm >= ", param_thickness_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.thickness_mm <= ", param_thickness_to); 
        END IF;
                
    END IF;
    
    IF param_width_from > 0 OR param_width_to > 0
    THEN 
        
        IF param_width_from > 0 AND param_width_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.width_mm >= ", param_width_from, " AND sp.width_mm <= ", param_width_to, ")"); 
        ELSEIF param_width_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.width_mm >= ", param_width_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.width_mm <= ", param_width_to); 
        END IF;
                
    END IF;

    IF param_length_from > 0 OR param_length_to > 0
    THEN 
        
        IF param_length_from > 0 AND param_length_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.length_mm >= ", param_length_from, " AND sp.length_mm <= ", param_length_to, ")"); 
        ELSEIF param_length_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.length_mm >= ", param_length_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.length_mm <= ", param_length_to); 
        END IF;
                
    END IF;

    IF param_weight_from > 0 OR param_weight_to > 0
    THEN 
        
        IF param_weight_from > 0 AND param_weight_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.unitweight_ton >= ", param_weight_from, " AND sp.unitweight_ton <= ", param_weight_to, ")"); 
        ELSEIF param_weight_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.unitweight_ton >= ", param_weight_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.unitweight_ton <= ", param_weight_to); 
        END IF;
                
    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET var_where = CONCAT(var_where, " AND (sp.notes LIKE '%", param_keyword, "%' OR sp.internal_notes LIKE '%", param_keyword, "%')"); 
    END IF;

    IF TRIM(param_locations) != ''
    THEN
        
        SET var_where = CONCAT(" JOIN steelitems", var_rev, " AS si ON si.steelposition_id = sp.id",
                        var_where, 
                        " AND si.location_id IN (", param_locations, ")"
                        );
    END IF;

    
    DROP TEMPORARY TABLE IF EXISTS t_steelpositions;
    CREATE TEMPORARY TABLE t_steelpositions(id INT, steelgrade VARCHAR(50), thickness DECIMAL(10,4), width DECIMAL(10, 4), `length` DECIMAL(10,4));

    SET @var_stmt := CONCAT("   INSERT INTO t_steelpositions(id, steelgrade, thickness, width, `length`)
                                SELECT DISTINCT 
                                    sp.id,
                                    (SELECT alias FROM steelgrades WHERE id = sp.steelgrade_id),
                                    sp.thickness_mm,
                                    sp.width_mm,
                                    sp.length_mm
                                FROM steelpositions", var_rev, " AS sp", var_where);

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;        


    SELECT 
        id AS steelposition_id 
    FROM t_steelpositions
    ORDER BY steelgrade, thickness, width, `length`;


    DROP TEMPORARY TABLE IF EXISTS t_steelpositions;
END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_list_by_ids$$
CREATE PROCEDURE sp_steelposition_get_list_by_ids(param_ids VARCHAR(1100), param_revision VARCHAR(12))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelposition_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM steelpositions", IF(TRIM(param_revision), CONCAT("_history_", param_revision), ""), 
        " WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_quick_by_ids$$
CREATE PROCEDURE sp_steelposition_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelposition_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT SUM(qtty) FROM steelpositions_reserved WHERE steelposition_id = steelpositions.id) AS reserved
        FROM steelpositions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_ws_list$$
CREATE PROCEDURE sp_steelposition_get_ws_list(param_user_id INT, param_product_id INT, param_stock_id INT, param_locations VARCHAR(100), 
                                        param_deliverytimes VARCHAR(100), param_steelgrades VARCHAR(100), 
                                        param_thickness_from DECIMAL(10,4), param_thickness_to DECIMAL(10,4), 
                                        param_width_from DECIMAL(10,4), param_width_to DECIMAL(10,4), 
                                        param_length_from DECIMAL(10,4), param_length_to DECIMAL(10,4), 
                                        param_weight_from DECIMAL(10,4), param_weight_to DECIMAL(10,4))
sp:
BEGIN

    
    DECLARE var_where           VARCHAR(4000) DEFAULT '';
    DECLARE var_deliverytimes   VARCHAR(1000) DEFAULT '';


    SET var_where           = CONCAT(" WHERE sp.is_from_order = 0 AND sp.is_deleted = 0 AND sp.is_reserved = 0 AND sp.qtty > 0 AND sp.stock_id = ", param_stock_id);
    SET var_deliverytimes   = (SELECT deliverytimes FROM stocks WHERE id = param_stock_id);

    
    IF param_product_id > 0 
    THEN 
        SET var_where = CONCAT(var_where, " AND sp.product_id = ", param_product_id); 
    END IF;
    
    IF TRIM(param_steelgrades) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND sp.steelgrade_id IN (", param_steelgrades, ")"); 
    END IF;
    
    IF TRIM(param_deliverytimes) != '' 
    THEN 
        SET var_where = CONCAT(var_where, " AND (sp.deliverytime_id IN (", param_deliverytimes, ") AND sp.deliverytime_id IN (", var_deliverytimes, "))"); 
    ELSE
        SET var_where = CONCAT(var_where, " AND (sp.deliverytime_id IN (", var_deliverytimes, "))"); 
    END IF;

    IF param_thickness_from > 0 OR param_thickness_to > 0
    THEN 
        
        IF param_thickness_from > 0 AND param_thickness_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.thickness_mm >= ", param_thickness_from, " AND sp.thickness_mm <= ", param_thickness_to, ")"); 
        ELSEIF param_thickness_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.thickness_mm >= ", param_thickness_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.thickness_mm <= ", param_thickness_to); 
        END IF;
                
    END IF;
    
    IF param_width_from > 0 OR param_width_to > 0
    THEN 
        
        IF param_width_from > 0 AND param_width_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.width_mm >= ", param_width_from, " AND sp.width_mm <= ", param_width_to, ")"); 
        ELSEIF param_width_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.width_mm >= ", param_width_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.width_mm <= ", param_width_to); 
        END IF;
                
    END IF;

    IF param_length_from > 0 OR param_length_to > 0
    THEN 
        
        IF param_length_from > 0 AND param_length_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.length_mm >= ", param_length_from, " AND sp.length_mm <= ", param_length_to, ")"); 
        ELSEIF param_length_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.length_mm >= ", param_length_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.length_mm <= ", param_length_to); 
        END IF;
                
    END IF;

    IF param_weight_from > 0 OR param_weight_to > 0
    THEN 
        
        IF param_weight_from > 0 AND param_weight_to > 0
        THEN
            SET var_where = CONCAT(var_where, " AND (sp.unitweight_ton >= ", param_weight_from, " AND sp.unitweight_ton <= ", param_weight_to, ")"); 
        ELSEIF param_weight_from > 0
        THEN
            SET var_where = CONCAT(var_where, " AND sp.unitweight_ton >= ", param_weight_from); 
        ELSE
            SET var_where = CONCAT(var_where, " AND sp.unitweight_ton <= ", param_weight_to); 
        END IF;
                
    END IF;

    IF TRIM(param_locations) != ''
    THEN
        
        SET var_where = CONCAT(" JOIN steelitems", " AS si ON si.steelposition_id = sp.id",
                        var_where, 
                        " AND si.location_id IN (", param_locations, ")"
                        );
    END IF;

    
    DROP TEMPORARY TABLE IF EXISTS t_steelpositions;
    CREATE TEMPORARY TABLE t_steelpositions(id INT, steelgrade VARCHAR(50), thickness DECIMAL(10,4), width DECIMAL(10, 4), `length` DECIMAL(10,4));

    SET @var_stmt := CONCAT("   INSERT INTO t_steelpositions(id, steelgrade, thickness, width, `length`)
                                SELECT DISTINCT 
                                    sp.id,
                                    (SELECT alias FROM steelgrades WHERE id = sp.steelgrade_id),
                                    sp.thickness_mm,
                                    sp.width_mm,
                                    sp.length_mm
                                FROM steelpositions", " AS sp", var_where);
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;        


    SELECT 
        id AS steelposition_id 
    FROM t_steelpositions
    ORDER BY steelgrade, thickness, width, `length`;


    DROP TEMPORARY TABLE IF EXISTS t_steelpositions;
END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_items_prepare_revision$$
CREATE PROCEDURE sp_steelposition_items_prepare_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN

    DECLARE var_tn VARCHAR(50) DEFAULT '';
    SET var_tn = sf_get_revision_table_name('steelposition_items_history', param_date);


    SET @var_stmt = CONCAT('DROP TABLE IF EXISTS ', var_tn, ';');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    SET @var_stmt = CONCAT('CREATE TABLE ', var_tn, ' LIKE steelposition_items;');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    DROP TEMPORARY TABLE IF EXISTS ids;
    CREATE TEMPORARY TABLE ids(id INT);

    INSERT INTO ids(id) SELECT MAX(id) FROM steelposition_items_history WHERE record_at <= param_date GROUP BY steelposition_id, steelitem_id;

    SET @var_stmt = CONCAT('INSERT INTO ', var_tn, '(id, steelposition_id, steelitem_id, created_at, created_by, modified_at, modified_by)
        SELECT 
            ids.id,
            steelposition_id, 
            steelitem_id, 
            created_at, 
            created_by, 
            modified_at, 
            modified_by
        FROM ids
        JOIN steelposition_items_history ON steelposition_items_history.id = ids.id
        WHERE act != \'d\'');

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  

    
    DROP TEMPORARY TABLE IF EXISTS ids;


END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_remove$$
CREATE PROCEDURE sp_steelposition_remove(param_user_id INT, param_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM order_positions WHERE position_id = param_id)
    THEN        
        UPDATE steelpositions SET is_deleted = 1, modified_at = NOW(), modified_by = param_user_id WHERE id = param_id;
    ELSE
        UPDATE steelpositions SET modified_at = NOW(), modified_by = param_user_id WHERE id = param_id;
        DELETE FROM steelpositions WHERE id = param_id;    
    END IF;
    
    
    DELETE FROM steelpositions_reserved WHERE steelposition_id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_reserve_add$$
CREATE PROCEDURE sp_steelposition_reserve_add(param_user_id INT, param_position_id INT, param_qtty INT, param_company_id INT, param_person_id INT, param_period INT)
BEGIN

    IF EXISTS (SELECT * FROM steelpositions_reserved WHERE steelposition_id = param_position_id AND company_id = param_company_id AND person_id = param_person_id)
    THEN

        UPDATE steelpositions_reserved
        SET
            qtty        = param_qtty,
            period      = param_period,
            expire_at   = TIMESTAMPADD(HOUR, param_period, NOW()),
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE steelposition_id = param_position_id 
        AND company_id = param_company_id 
        AND person_id = param_person_id;

    ELSE

        INSERT INTO steelpositions_reserved
        SET
            steelposition_id    = param_position_id,
            company_id          = param_company_id,
            person_id           = param_person_id,
            qtty                = param_qtty,
            period              = param_period,
            expire_at           = TIMESTAMPADD(HOUR, param_period, NOW()),
            created_at          = NOW(),
            created_by          = param_user_id,
            modified_at         = NOW(),
            modified_by         = param_user_id;

    END IF;

    
    CALL sp_steelposition_update_qtty(param_user_id, param_position_id);

    
    SELECT * FROM steelpositions WHERE id = param_position_id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_reserve_companies$$
CREATE PROCEDURE sp_steelposition_reserve_companies()
BEGIN

    SELECT DISTINCT
        company_id
    FROM steelpositions_reserved AS spr
    JOIN companies AS c ON spr.company_id = c.id
    ORDER BY c.title;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_reserve_get_list$$
CREATE PROCEDURE sp_steelposition_reserve_get_list(param_user_id INT, param_company_id INT)
BEGIN

    SELECT
        sr.*
    FROM steelpositions_reserved AS sr
    JOIN steelpositions AS s ON s.id = sr.steelposition_id
    WHERE (sr.company_id = param_company_id OR param_company_id = 0)
    ORDER BY s.stock_id, s.thickness_mm, s.width_mm, s.length_mm;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_reserve_remove$$
CREATE PROCEDURE sp_steelposition_reserve_remove(param_user_id INT, param_id INT)
BEGIN

    DECLARE var_steelposition_id INT DEFAULT 0;
    SET var_steelposition_id = (SELECT steelposition_id FROM steelpositions_reserved WHERE id = param_id);
    
    SELECT * FROM steelpositions WHERE id = var_steelposition_id;
    DELETE FROM steelpositions_reserved WHERE id = param_id;

    
    CALL sp_steelposition_update_qtty(param_user_id, var_steelposition_id);

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_save$$
CREATE PROCEDURE sp_steelposition_save(param_user_id INT, param_id INT, param_stock_id INT, param_product_id INT, param_biz_id INT, 
                                param_dimension_unit CHAR(10), param_weight_unit CHAR(10), param_currency CHAR(3),
                                param_steelgrade_id INT, param_thickness CHAR(10), param_thickness_mm DECIMAL(10,4), 
                                param_width CHAR(10), param_width_mm DECIMAL(10,4), 
                                param_length CHAR(10), param_length_mm DECIMAL(10,4), 
                                param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10,4), 
                                param_qtty INT, 
                                param_weight CHAR(10), param_weight_ton DECIMAL(10,4), 
                                param_price DECIMAL(10,4), param_value DECIMAL(10,4), 
                                param_deliverytime_id INT, 
                                param_notes VARCHAR(250), param_internal_notes VARCHAR(250))
sp:
BEGIN

    DECLARE var_qtty INT DEFAULT 0;
    
    IF param_id > 0
    THEN
        
        IF NOT EXISTS (SELECT * FROM steelpositions WHERE id = param_id)
        THEN 
            SELECT -1 as ErrorCode, 'sp_steelposition_save' AS ErrorAt;
            LEAVE sp;
        END IF;

        
        SET var_qtty    = sf_steelposition_get_qtty(param_id);
        SET param_value = param_price * param_unitweight * var_qtty;

        IF var_qtty = 0 
        THEN

            CALL sp_steelposition_remove(param_user_id, param_id);
            LEAVE sp;

        END IF;

        
        UPDATE steelpositions
        SET
            biz_id              = CASE WHEN param_biz_id = 0 THEN biz_id ELSE param_biz_id END,
            steelgrade_id       = param_steelgrade_id,
            thickness           = param_thickness,
            thickness_mm        = param_thickness_mm,
            width               = param_width,
            width_mm            = param_width_mm,
            `length`            = param_length,
            length_mm           = param_length_mm,
            unitweight          = param_unitweight,
            unitweight_ton      = param_unitweight_ton,
            weight              = param_unitweight * var_qtty, 
            weight_ton          = param_unitweight_ton * var_qtty, 
            price               = param_price,
            `value`             = param_value,
            deliverytime_id     = param_deliverytime_id,
            notes               = param_notes,
            internal_notes      = param_internal_notes,
            qtty                = var_qtty,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

        
        

        
        UPDATE steelitems
        SET
            steelgrade_id   = param_steelgrade_id,
            thickness       = param_thickness,
            thickness_mm    = param_thickness_mm,
            width           = param_width,
            width_mm        = param_width_mm,
            `length`        = param_length,
            length_mm       = param_length_mm,
            unitweight      = param_unitweight,
            unitweight_ton  = param_unitweight_ton,
            price           = param_price,
            `value`         = param_value
        WHERE steelposition_id = param_id;
    
    ELSE

        START TRANSACTION;

            INSERT INTO steelpositions
            SET
                stock_id        = param_stock_id,
                product_id      = param_product_id,
                biz_id          = param_biz_id,
                dimension_unit  = param_dimension_unit,
                weight_unit     = param_weight_unit,
                currency        = param_currency,
                steelgrade_id   = param_steelgrade_id,
                thickness       = param_thickness,
                thickness_mm    = param_thickness_mm,
                width           = param_width,
                width_mm        = param_width_mm,
                length          = param_length,
                length_mm       = param_length_mm,
                unitweight      = param_unitweight,
                unitweight_ton  = param_unitweight_ton,
                qtty            = param_qtty,
                weight          = param_weight,
                weight_ton      = param_weight_ton,
                price           = param_price,
                `value`         = param_value,
                deliverytime_id = param_deliverytime_id,
                notes           = param_notes,
                internal_notes  = param_internal_notes,
                is_from_order   = IF(param_stock_id > 0, 0, 1),
                is_deleted      = 0,
                is_reserved     = 0,
                tech_action     = '',
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;
    
            SET param_id = (SELECT MAX(id) FROM steelpositions WHERE created_by = param_user_id);

        COMMIT;    

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_update_qtty$$
CREATE PROCEDURE sp_steelposition_update_qtty(param_user_id INT, param_id INT)
BEGIN

    DECLARE var_qtty            INT DEFAULT 0;
    DECLARE var_reserved_qtty   INT DEFAULT 0;


    IF NOT EXISTS (SELECT * FROM steelitems WHERE steelposition_id = param_id)
    THEN

        CALL sp_steelposition_remove(param_user_id, param_id);

    ELSE

        SET var_qtty            = sf_steelposition_get_qtty(param_id);
        SET var_reserved_qtty   = IFNULL((SELECT SUM(qtty) FROM steelpositions_reserved WHERE steelposition_id = param_id), 0);

        UPDATE steelpositions
        SET
            modified_at = NOW(),
            modified_by = param_user_id,
            qtty        = var_qtty,
            weight      = unitweight * var_qtty,
            weight_ton  = unitweight_ton * var_qtty,
            `value`     = price * unitweight * var_qtty,
            is_reserved = IF(var_reserved_qtty >= var_qtty, 1, 0)
        WHERE id = param_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_steelposition_update_qtty_output$$
CREATE PROCEDURE sp_steelposition_update_qtty_output(param_user_id INT, param_id INT)
BEGIN

    
    SELECT * FROM steelpositions WHERE id = param_id;

    
    CALL sp_steelposition_update_qtty(param_user_id, param_id);

END
$$

DROP PROCEDURE IF EXISTS sp_stock_check_revision$$
CREATE PROCEDURE sp_stock_check_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN

    IF NOT EXISTS (SELECT table_name FROM information_schema.tables WHERE table_name = sf_get_revision_table_name('steelpositions_history', param_date))
    THEN

        START TRANSACTION;
    
            CALL sp_steelitem_properties_prepare_revision(param_user_id, param_date);
            CALL sp_steelitems_prepare_revision(param_user_id, param_date);
            CALL sp_steelpositions_prepare_revision(param_user_id, param_date);
            CALL sp_stock_locations_prepare_revision(param_user_id, param_date);
    
        COMMIT;

    END IF;


    SELECT sf_get_revision_id(param_date) AS revision_id;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_clear_locations$$
CREATE PROCEDURE sp_stock_clear_locations(param_stock_id INT)
BEGIN
    
    DELETE FROM stock_locations WHERE stock_id = param_stock_id;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_delivery_times$$
CREATE PROCEDURE sp_stock_get_delivery_times(param_stock_id INT, param_location_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    
    IF param_stock_id = 0 
    THEN 
        SELECT -1 AS ErrorCode, 'sp_stock_get_delivery_times' AS ErrorAt;
        LEAVE sp; 
    END IF;

    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");


    IF param_location_id > 0
    THEN

        SET @var_stmt = CONCAT("SELECT DISTINCT
                steelpositions.deliverytime_id
            FROM steelpositions", var_rev," AS sp
            JOIN steelitems", var_rev," AS si ON si.steelposition_id = sp.id
            WHERE sp.stock_id = ", param_stock_id, 
            " AND si.location_id = ", param_location_id,
            " AND sp.deliverytime_id > 0 AND si.is_deleted = 0 AND si.is_available = 1 AND qtty > 0;");

    ELSE
        
        SET @var_stmt = CONCAT("SELECT DISTINCT
                deliverytime_id
            FROM steelpositions", var_rev, 
            " WHERE stock_id = ", param_stock_id, 
            " AND deliverytime_id > 0
            AND qtty > 0;");
        
    END IF;

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_item_deliverytimes$$
CREATE PROCEDURE sp_stock_get_item_deliverytimes(param_stock_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    
    IF param_stock_id = 0 
    THEN 
        SELECT -1 AS ErrorCode, 'sp_stock_get_item_deliverytimes' AS ErrorAt;
        LEAVE sp; 
    END IF;

    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");


    SET @var_stmt = CONCAT("SELECT DISTINCT
            si.deliverytime_id
        FROM steelitems", var_rev," AS si 
        JOIN steelpositions", var_rev," AS sp ON si.steelposition_id = sp.id 
        WHERE sp.stock_id = ", param_stock_id, 
        " AND si.deliverytime_id > 0 AND si.is_deleted = 0 AND si.is_available = 1;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_item_filter$$
CREATE PROCEDURE sp_stock_get_item_filter(param_user_id INT, param_stock_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");

    IF param_stock_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_stock_get_item_filter' AS ErrorAt;
        LEAVE sp;
    END IF;


    CALL sp_stock_get_item_locations(param_stock_id, param_revision);


    SET @var_stmt = CONCAT("SELECT DISTINCT
        deliverytime_id
    FROM steelitems", var_rev, 
    " WHERE location_id IN (SELECT location_id FROM stock_locations", var_rev, " WHERE stock_id = ", param_stock_id, ")
    AND deliverytime_id > 0 
    AND is_deleted = 0 AND is_available = 1;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


    SET @var_stmt = CONCAT("SELECT DISTINCT
        steelgrade_id
    FROM steelitems", var_rev, 
    " WHERE location_id IN (SELECT location_id FROM stock_locations WHERE stock_id = ", param_stock_id, ")
    AND steelgrade_id > 0 
    AND is_deleted = 0 AND is_available = 1;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_item_locations$$
CREATE PROCEDURE sp_stock_get_item_locations(param_stock_id INT, param_revision VARCHAR(12))
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");

    SET @var_stmt = CONCAT("SELECT DISTINCT
        si.stockholder_id
    FROM steelitems", var_rev," AS si
    JOIN steelpositions", var_rev," AS sp ON sp.id = si.steelposition_id
    JOIN companies AS c ON si.stockholder_id = c.id
    WHERE sp.stock_id = ", param_stock_id,
    " AND si.stockholder_id > 0 
    AND si.is_deleted = 0 AND si.is_available = 1 
    ORDER BY c.title;");   

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_item_steelgrades$$
CREATE PROCEDURE sp_stock_get_item_steelgrades(param_stock_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    
    IF param_stock_id = 0 
    THEN 
        SELECT -1 AS ErrorCode, 'sp_stock_get_item_steelgrades' AS ErrorAt;
        LEAVE sp; 
    END IF;

    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");


    SET @var_stmt = CONCAT("SELECT DISTINCT
            si.steelgrade_id
        FROM steelitems", var_rev," AS si 
        JOIN steelpositions AS sp ON si.steelposition_id = sp.id 
        WHERE sp.stock_id = ", param_stock_id, 
        " AND si.steelgrade_id > 0 
        AND si.is_deleted = 0 AND si.is_available = 1;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_list$$
CREATE PROCEDURE sp_stock_get_list()
BEGIN

    SELECT
        id AS stock_id
    FROM stocks;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_list_by_ids$$
CREATE PROCEDURE sp_stock_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_stock_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM stocks
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_locations$$
CREATE PROCEDURE sp_stock_get_locations(param_stock_id INT)
BEGIN

    SELECT
        sl.*
    FROM stock_locations as sl
    JOIN companies AS c ON sl.company_id = c.id
    WHERE sl.stock_id = param_stock_id
    ORDER BY c.title;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_position_deliverytimes$$
CREATE PROCEDURE sp_stock_get_position_deliverytimes(param_stock_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    
    IF param_stock_id = 0 
    THEN 
        SELECT -1 AS ErrorCode, 'sp_stock_get_position_deliverytimes' AS ErrorAt;
        LEAVE sp; 
    END IF;

    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");


    SET @var_stmt = CONCAT("SELECT DISTINCT
            sp.deliverytime_id
        FROM steelpositions", var_rev," AS sp
        WHERE sp.stock_id = ", param_stock_id, 
        " AND sp.deliverytime_id > 0 
        AND qtty > 0 AND is_from_order = 0 AND sp.is_deleted = 0;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_position_locations$$
CREATE PROCEDURE sp_stock_get_position_locations(param_stock_id INT, param_revision VARCHAR(12))
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");

    SET @var_stmt = CONCAT("SELECT DISTINCT
        si.location_id
    FROM steelitems", var_rev," AS si
    JOIN steelpositions", var_rev," AS sp ON sp.id = si.steelposition_id
    JOIN locations AS l ON si.location_id = l.id
    WHERE sp.stock_id = ", param_stock_id,
    " AND si.location_id > 0 AND sp.qtty > 0 AND sp.is_from_order = 0 
    AND si.is_deleted = 0 AND si.is_available = 1 
    ORDER BY l.title;");   

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_quick_by_ids$$
CREATE PROCEDURE sp_stock_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_stock_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT COUNT(*) FROM steelpositions WHERE stock_id = stocks.id) AS positions,
            (SELECT COUNT(*) FROM orders WHERE stock_id = stocks.id) AS orders
        FROM stocks
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_steelgrades$$
CREATE PROCEDURE sp_stock_get_steelgrades(param_stock_id INT, param_stockholder_id INT, param_revision VARCHAR(12))
sp:
BEGIN

    DECLARE var_rev VARCHAR(50) DEFAULT '';
    SET var_rev = IF(TRIM(param_revision), CONCAT("_history_", param_revision), "");

    IF param_stock_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_stock_get_steelgrades' AS ErrorAt;
        LEAVE sp;
    END IF;


    IF param_stockholder_id > 0
    THEN

        SET @var_stmt = CONCAT("SELECT DISTINCT
                sp.steelgrade_id
            FROM steelpositions", var_rev, " AS sp
            JOIN steelitems", var_rev, " AS si ON si.steelposition_id = sp.id
            WHERE sp.stock_id = ", param_stock_id, 
            " AND si.stockholder_id = ", param_stockholder_id, 
            " AND sp.qtty > 0 
            AND si.is_deleted = 0 AND si.is_available = 1;");

    ELSE
        
        SET @var_stmt = CONCAT("SELECT DISTINCT
            steelgrade_id
        FROM steelpositions", var_rev, " AS sp
        WHERE stock_id = ", param_stock_id, 
        " AND sp.qtty > 0;");

    END IF;

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_ws_deliverytimes$$
CREATE PROCEDURE sp_stock_get_ws_deliverytimes(param_stock_id INT)
sp:
BEGIN

    DECLARE var_deliverytimes VARCHAR(1000) DEFAULT '';
    SET var_deliverytimes = IFNULL((SELECT deliverytimes FROM stocks WHERE id = param_stock_id), '0');


    SET @var_stmt = CONCAT("SELECT DISTINCT
            sp.deliverytime_id
        FROM steelpositions AS sp
        WHERE sp.stock_id = ", param_stock_id, " 
        AND sp.deliverytime_id > 0 AND deliverytime_id IN (", var_deliverytimes, ") 
        AND qtty > 0 AND is_from_order = 0 AND sp.is_deleted = 0 AND sp.is_reserved = 0;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_ws_locations$$
CREATE PROCEDURE sp_stock_get_ws_locations(param_stock_id INT)
BEGIN

    DECLARE var_deliverytimes VARCHAR(1000) DEFAULT '';
    SET var_deliverytimes = IFNULL((SELECT deliverytimes FROM stocks WHERE id = param_stock_id), '0');

    
    SET @var_stmt = CONCAT("SELECT DISTINCT
        si.location_id
    FROM steelitems AS si
    JOIN steelpositions AS sp ON sp.id = si.steelposition_id
    JOIN locations AS l ON si.location_id = l.id
    WHERE sp.stock_id = ", param_stock_id, " 
    AND si.location_id > 0 AND sp.qtty > 0 AND sp.is_from_order = 0 AND sp.is_deleted = 0 AND sp.is_reserved = 0
    AND sp.deliverytime_id IN (", var_deliverytimes, ") 
    AND si.is_deleted = 0 AND si.is_available = 1 
    ORDER BY l.title;");   

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_get_ws_steelgrades$$
CREATE PROCEDURE sp_stock_get_ws_steelgrades(param_stock_id INT)
sp:
BEGIN

    DECLARE var_deliverytimes VARCHAR(1000) DEFAULT '';
    SET var_deliverytimes = IFNULL((SELECT deliverytimes FROM stocks WHERE id = param_stock_id), '0');


    SET @var_stmt = CONCAT("SELECT DISTINCT
            sp.steelgrade_id
        FROM steelpositions AS sp
        WHERE sp.stock_id = ", param_stock_id, " 
        AND sp.steelgrade_id > 0 AND deliverytime_id IN (", var_deliverytimes, ") 
        AND qtty > 0 AND is_from_order = 0 AND sp.is_deleted = 0 AND sp.is_reserved = 0;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_locations_prepare_revision$$
CREATE PROCEDURE sp_stock_locations_prepare_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN

    DECLARE var_tn VARCHAR(50) DEFAULT '';
    SET var_tn = sf_get_revision_table_name('stock_locations_history', param_date);


    SET @var_stmt = CONCAT('DROP TABLE IF EXISTS ', var_tn, ';');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    SET @var_stmt = CONCAT('CREATE TABLE ', var_tn, ' LIKE stock_locations;');
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  


    DROP TEMPORARY TABLE IF EXISTS ids;
    CREATE TEMPORARY TABLE ids(id INT);

    INSERT INTO ids(id) SELECT MAX(id) FROM stock_locations_history WHERE record_at <= param_date GROUP BY stock_id, company_id;

    SET @var_stmt = CONCAT('INSERT INTO ', var_tn, '(id, stock_id, company_id, created_at, created_by, modified_at, modified_by)
        SELECT 
            ids.id,
            stock_id, 
            company_id, 
            created_at, 
            created_by, 
            modified_at, 
            modified_by
        FROM ids
        JOIN stock_locations_history ON stock_locations_history.id = ids.id
        WHERE act != \'d\'');

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;  

    
    DROP TEMPORARY TABLE IF EXISTS ids;


END
$$

DROP PROCEDURE IF EXISTS sp_stock_prepare_revision$$
CREATE PROCEDURE sp_stock_prepare_revision(param_user_id INT, param_date TIMESTAMP)
BEGIN

END
$$

DROP PROCEDURE IF EXISTS sp_stock_remove_location$$
CREATE PROCEDURE sp_stock_remove_location(param_user_id INT, param_stock_id INT, param_company_id INT)
BEGIN

    UPDATE stock_locations 
    SET 
        modified_at = NOW(), 
        modified_by = param_user_id 
    WHERE stock_id = param_stock_id 
    AND company_id = param_company_id;

    DELETE FROM stock_locations WHERE stock_id = param_stock_id AND company_id = param_company_id;
    
END
$$

DROP PROCEDURE IF EXISTS sp_stock_save$$
CREATE PROCEDURE sp_stock_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_description TEXT, param_dimension_unit CHAR(5), 
                            param_weight_unit CHAR(5), param_currency CHAR(3), param_invoicingtype_id INT, param_paymenttype_id INT,
                            param_deliverytimes VARCHAR(1000), param_visible_columns VARCHAR(1000), param_email_for_orders VARCHAR(250),
                            param_order_for CHAR(5))
sp:
BEGIN

    IF EXISTS (SELECT * FROM stocks WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_stock_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM stocks WHERE id = param_id)
    THEN

        UPDATE stocks
        SET
            title               = param_title,
            description         = param_description,
            dimension_unit      = param_dimension_unit,
            weight_unit         = param_weight_unit,
            currency            = param_currency,
            invoicingtype_id    = param_invoicingtype_id,
            paymenttype_id      = param_paymenttype_id,
            deliverytimes       = param_deliverytimes,
            visible_columns     = param_visible_columns,
            email_for_orders    = param_email_for_orders,
            order_for           = param_order_for,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

        
        

    ELSE

        START TRANSACTION;

            INSERT stocks
            SET
                title               = param_title,
                description         = param_description,
                dimension_unit      = param_dimension_unit,
                weight_unit         = param_weight_unit,
                currency            = param_currency,
                invoicingtype_id    = param_invoicingtype_id,
                paymenttype_id      = param_paymenttype_id,
                deliverytimes       = param_deliverytimes,
                visible_columns     = param_visible_columns,
                email_for_orders    = param_email_for_orders,
                order_for           = param_order_for,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id;
    
            SET param_id := (SELECT MAX(id) FROM stocks WHERE created_by = param_user_id);
        
        COMMIT;

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_stock_save_location$$
CREATE PROCEDURE sp_stock_save_location(param_user_id INT, param_stock_id INT, param_company_id INT)
sp:
BEGIN

    IF EXISTS (SELECT * FROM stock_locations WHERE stock_id = param_stock_id AND company_id = param_company_id)
    THEN
        LEAVE sp;
    END IF;
    
    INSERT INTO stock_locations
    SET
        stock_id        = param_stock_id,
        company_id      = param_company_id,
        modified_at     = NOW(),
        modified_by     = param_user_id,
        created_at      = NOW(),
        created_by      = param_user_id;    

END
$$

DROP PROCEDURE IF EXISTS sp_stock_search_combinations_add$$
CREATE PROCEDURE sp_stock_search_combinations_add(param_user_id INT, param_direction CHAR(3), param_stock_id INT, param_steelgrade_id INT,
                                                    param_thickness VARCHAR(50), param_width VARCHAR(50), param_length VARCHAR(50))
BEGIN

    INSERT INTO stock_search_combinations
    SET
        direction       = param_direction,
        stock_id        = param_stock_id,
        steelgrade_id   = param_steelgrade_id,
        thickness       = param_thickness,
        width           = param_width,
        `length`        = param_length,
        hits            = 1,
        created_at      = NOW(),
        created_by      = param_user_id;
        
END
$$

DROP PROCEDURE IF EXISTS sp_stock_search_combinations_get$$
CREATE PROCEDURE sp_stock_search_combinations_get(param_user_id INT, param_direction CHAR(3), param_stock_id INT, param_month INT, param_year INT)
sp:
BEGIN
   
    DECLARE var_start_date TIMESTAMP; 
    DECLARE var_end_date TIMESTAMP;
    
    SET var_start_date  = TIMESTAMP(CONCAT(param_year, '-', param_month, '-01'));
    SET var_end_date    = TIMESTAMPADD(MONTH, 1, var_start_date);

    SELECT 
        *,
        SUM(hits) AS hits
    FROM stock_search_combinations
    WHERE direction = param_direction
    AND stock_id = param_stock_id
    AND created_at BETWEEN var_start_date AND var_end_date
    GROUP BY steelgrade_id, thickness;
            
END
$$

DROP PROCEDURE IF EXISTS sp_team_add_user$$
CREATE PROCEDURE sp_team_add_user(param_author_id INT, param_team_id INT, param_user_id INT)
BEGIN

    INSERT INTO team_users
    SET
        team_id     = param_team_id,
        user_id     = param_user_id,
        created_at  = NOW(),
        created_by  = param_author_id;

END
$$

DROP PROCEDURE IF EXISTS sp_team_get_list$$
CREATE PROCEDURE sp_team_get_list()
BEGIN

    SELECT
        id AS team_id
    FROM teams
    WHERE is_deleted = 0
    ORDER BY title;

END
$$

DROP PROCEDURE IF EXISTS sp_team_get_list_by_ids$$
CREATE PROCEDURE sp_team_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_team_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *
        FROM teams
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_team_get_quick_by_ids$$
CREATE PROCEDURE sp_team_get_quick_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_team_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id
        FROM teams
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_team_get_users$$
CREATE PROCEDURE sp_team_get_users(param_team_id INT)
BEGIN

    SELECT 
        *
    FROM team_users
    WHERE team_id = param_team_id;

END
$$

DROP PROCEDURE IF EXISTS sp_team_remove$$
CREATE PROCEDURE sp_team_remove(param_user_id INT, param_id INT)
BEGIN

    UPDATE teams
    SET
        is_deleted  = 1,
        modified_at = NOW(),
        modified_by = param_user_id
    WHERE id = param_id;

    DELETE FROM team_users WHERE team_id = param_id;

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_team_remove_user$$
CREATE PROCEDURE sp_team_remove_user(param_team_id INT, param_user_id INT)
BEGIN

    DELETE FROM team_users
    WHERE team_id = param_team_id 
    AND user_id = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_team_save$$
CREATE PROCEDURE sp_team_save(param_user_id INT, param_id INT, param_title VARCHAR(250), param_description TEXT, param_email VARCHAR(500))
sp:
BEGIN

    IF EXISTS (SELECT * FROM teams WHERE title = param_title AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_team_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM teams WHERE id = param_id)
    THEN

        UPDATE teams
        SET
            title           = param_title,
            description     = param_description,
            email           = param_email,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        INSERT teams
        SET
            title           = param_title,
            description     = param_description,
            email           = param_email,
            is_deleted      = 0,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id;

        SET param_id := (SELECT MAX(id) FROM teams WHERE created_by = param_user_id);

    END IF;
    

    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_by_person$$
CREATE PROCEDURE sp_user_get_by_person(param_person_id INT)
BEGIN

    SELECT 
        MAX(id) AS user_id
    FROM users
    WHERE person_id = param_person_id;

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_list_by_ids$$
CREATE PROCEDURE sp_user_get_list_by_ids(param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_user_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(
        "SELECT 
            *,
            IFNULL((SELECT id FROM attachments WHERE `type` = 'image' AND object_alias = 'user' AND object_id = users.id AND is_main = 1 LIMIT 1), 0) AS picture_id
        FROM users
        WHERE id IN (", param_ids, ")
        ORDER BY id
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_list_by_login$$
CREATE PROCEDURE sp_user_get_list_by_login(param_login VARCHAR(50), param_rows_count INT)
BEGIN

    SET @var_stmt := CONCAT(  
        "SELECT 
            id AS user_id
        FROM users
        WHERE login LIKE '%", param_login, "%' OR nickname LIKE '%", param_login, "%'
        LIMIT ", param_rows_count, ";");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_list_for_chat$$
CREATE PROCEDURE sp_user_get_list_for_chat()
BEGIN

    SELECT
        id AS user_id
    FROM users 
    WHERE chat_icon_park = 1;

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_mam_list$$
CREATE PROCEDURE sp_user_get_mam_list()
BEGIN

    SELECT
        id AS user_id
    FROM users
    WHERE is_mam = 1
    ORDER BY login;

END
$$

DROP PROCEDURE IF EXISTS sp_user_get_quicklist_by_ids$$
CREATE PROCEDURE sp_user_get_quicklist_by_ids(IN param_ids VARCHAR(1100))
sp:BEGIN
    
    IF param_ids = '' THEN
      SELECT -1 AS ErrorCode, 'sp_user_get_quicklist_by_ids' AS ErrorAt;
      LEAVE sp;
    END IF;

    SET @var_stmt := CONCAT(  
      "SELECT 
        us.user_id AS id,
        sf_user_currently_reading(user_id) AS currently_reading,
        us.rating,
        us.activity,
        us.books_read AS count_books_read,
        us.books_wish AS count_books_wish,
        us.books_reading AS count_books_reading,
        (us.books_wish + us.books_reading) AS count_books_wish_reading,
        us.books_own AS count_books_own,
        us.friends AS count_friends,
        us.favorites AS count_favorites,
        us.reviews AS count_reviews,
        us.reviews_friends_only AS count_reviews_friends_only,
        us.reviews_neformat AS count_reviews_neformat,
        us.reviews_neformat_friends_only AS count_reviews_neformat_friends_only,
        us.reviews_private AS count_reviews_private,
        us.quotes AS count_quotes,
        us.quotes_friends_only AS count_quotes_friends_only,
        us.quotes_neformat AS count_quotes_neformat,
        us.quotes_neformat_friends_only AS count_quotes_neformat_friends_only,
        us.quotes_private AS count_quotes_private,
        us.selections AS count_selections,
        us.selections_friends_only AS count_selections_friends_only,
        us.selections_neformat AS count_selections_neformat,
        us.selections_neformat_friends_only AS count_selections_neformat_friends_only,
        us.selections_private AS count_selections_private,
        us.stories AS count_stories,
        us.stories_friends_only AS count_stories_friends_only,
        us.stories_neformat AS count_stories_neformat,
        us.stories_neformat_friends_only AS count_stories_neformat_friends_only,
        us.stories_private AS count_stories_private,
        IFNULL(us.last_event, '0000-00-00') AS last_event,
        IFNULL(us.last_rec_at, '0000-00-00') AS last_rec_at,
        IFNULL(us.last_social_update_at, '0000-00-00') AS last_social_update_at,
        us.messages_unread
      FROM user_stats us
      WHERE user_id IN (", param_ids, ")
      ORDER BY user_id
      LIMIT 100;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;
END
$$

DROP PROCEDURE IF EXISTS sp_user_login$$
CREATE PROCEDURE sp_user_login(param_login CHAR(20), param_password CHAR(32))
sp:
BEGIN
    
    DECLARE var_user_id INT DEFAULT 0;

    SET var_user_id := IFNULL((SELECT id FROM users WHERE (login = param_login OR email = param_login OR nickname = param_login) AND `password` = param_password), 0);
    
    IF var_user_id = 0
    THEN
        SELECT -1 AS ErrorCode, 'sp_user_login' AS ErrorAt;
        LEAVE sp;
    END IF;

    SELECT var_user_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_user_logout$$
CREATE PROCEDURE sp_user_logout(param_user_id INT)
BEGIN

    UPDATE users SET last_message_id = (SELECT last_message_id FROM active_users WHERE user_id = param_user_id);

    DELETE FROM active_users WHERE user_id = param_user_id;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_add$$
CREATE PROCEDURE sp_user_request_add(param_domain CHAR(10), param_login VARCHAR(20), param_password VARCHAR(32), param_email VARCHAR(250), 
                                        param_title CHAR(5), param_first_name VARCHAR(50), param_last_name VARCHAR(50), param_phone VARCHAR(20),
                                        param_skype VARCHAR(100), param_company_name VARCHAR(250), param_website VARCHAR(1000),
                                        param_country_id INT(11))
sp:
BEGIN

    DECLARE var_secret_code VARCHAR(32) DEFAULT '';
    
    IF EXISTS (SELECT * FROM users WHERE login = param_login) 
    THEN
        SELECT -1 AS ErrorCode, 'sp_user_request_add' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_secret_code = CONCAT(sf_gen_secret_code(26), IFNULL((SELECT MAX(id) FROM user_requests), 0) + 1);

    INSERT INTO user_requests
    SET
        domain          = param_domain,
        login           = param_login,
        `password`      = param_password,
        email           = param_email,
        title           = param_title,
        first_name      = param_first_name,
        last_name       = param_last_name,
        phone           = param_phone,
        skype           = param_skype,
        company_name    = param_company_name,
        website         = param_website,
        country_id      = param_country_id,
        is_confirmed    = 0,
        is_processed    = 0,
        secret_code     = var_secret_code,
        created_at      = NOW();
        
    SELECT var_secret_code AS secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_confirm$$
CREATE PROCEDURE sp_user_request_confirm(param_secret_code VARCHAR(32))
BEGIN

    UPDATE user_requests
    SET
        is_confirmed    = 1,
        confirmed_at    = NOW()
    WHERE secret_code = param_secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_get$$
CREATE PROCEDURE sp_user_request_get(param_secret_code VARCHAR(32))
BEGIN

    SELECT 
        *
    FROM user_requests
    WHERE secret_code = param_secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_save$$
CREATE PROCEDURE sp_user_save(param_user_id INT, param_id INT, param_login VARCHAR(20), param_nickname VARCHAR(2), param_password VARCHAR(32),
                                param_email VARCHAR(250), param_role_id TINYINT, param_status_id TINYINT, param_person_id INT, 
                                param_color VARCHAR(20), param_is_mam TINYINT, param_se_access TINYINT, param_pa_access TINYINT)
sp: 
BEGIN

    IF param_id > 0
    THEN

        UPDATE users
        SET
            login       = param_login,
            nickname    = param_nickname,
            `password`  = param_password,
            email       = param_email,
            role_id     = param_role_id,
            status_id   = param_status_id,
            person_id   = param_person_id,
            color       = param_color,
            is_mam      = param_is_mam,
            se_access   = param_se_access,
            pa_access   = param_pa_access,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO users
            SET
                login       = param_login,
                nickname    = param_nickname,
                `password`  = param_password,
                email       = param_email,
                role_id     = param_role_id,
                status_id   = param_status_id,
                person_id   = param_person_id,
                color       = param_color,
                is_mam      = param_is_mam,
                se_access   = param_se_access,
                pa_access   = param_pa_access,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET param_id = (SELECT MAX(id) FROM users WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_user_update_profile$$
CREATE PROCEDURE sp_user_update_profile(param_user_id INT, param_title CHAR(5), param_first_name VARCHAR(50), param_last_name VARCHAR(50), 
                                        param_phone VARCHAR(20), param_skype VARCHAR(100))
BEGIN

    DECLARE var_person_id INT DEFAULT 0;
    SET var_person_id = (SELECT person_id FROM users WHERE id = param_user_id);

    UPDATE persons
    SET
        title       = param_title,
        first_name  = param_first_name,
        last_name   = param_last_name,
        phone       = param_phone,
        skype       = param_skype
    WHERE id = var_person_id;

    SELECT 
        param_user_id   AS user_id,
        var_person_id   AS person_id;

END
$$

DROP PROCEDURE IF EXISTS _import_biz_users$$
CREATE PROCEDURE _import_biz_users()
BEGIN

    DECLARE var_biz_id      INT DEFAULT 0;
    DECLARE var_navigators  VARCHAR(1000) DEFAULT '';

    SET var_biz_id = IFNULL((SELECT MIN(id) FROM bizes WHERE navigators != ''), 0);

    TRUNCATE TABLE biz_users;

    WHILE var_biz_id > 0
    DO
        
        SET var_navigators = REPLACE((SELECT navigators FROM bizes WHERE id = var_biz_id), '/', ',');

        SET @var_stmt := CONCAT("
            INSERT INTO biz_users(biz_id, user_id, is_driver, created_at, created_by)
            SELECT ", var_biz_id, ", id, 0, NOW(), 0 
            FROM users 
            WHERE id IN (", var_navigators, ");");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;        

        SET var_biz_id = IFNULL((SELECT MIN(id) FROM bizes WHERE navigators != '' AND id > var_biz_id), 0);
    
    END WHILE;
    

END
$$

DROP PROCEDURE IF EXISTS _import_message_users$$
CREATE PROCEDURE _import_message_users()
sp:
BEGIN

    DECLARE var_message_id  INT DEFAULT 0;
    DECLARE var_users       VARCHAR(1000) DEFAULT '';
    DECLARE var_params      VARCHAR(1000) DEFAULT '';

    SET var_message_id = (SELECT MIN(id) FROM messages);
    
    WHILE var_message_id > 0
    DO
        #SELECT var_message_id;

        SET var_params  = (SELECT CONCAT(type_id, ',', role_id, ',', sender_id) FROM messages WHERE id = var_message_id);
        
        SET var_users   = IFNULL((SELECT REPLACE(TRIM(BOTH ',' FROM tl_recipients), ',,', ',') FROM messages WHERE id = var_message_id), '');        
        IF var_users != ''
        THEN

            SET @var_stmt   = CONCAT("
                INSERT INTO message_users(message_id, type_id, role_id, sender_id, user_id, relation, created_at, created_by)
                SELECT ",
                    var_message_id, ",", var_params, ",
                    id,
                    'r',
                    NOW(),
                    id
                FROM users
                WHERE id IN (", var_users, ");");
    
            PREPARE stmt FROM @var_stmt;
            EXECUTE stmt;

        END IF;


        SET var_users = IFNULL((SELECT REPLACE(TRIM(BOTH ',' FROM tl_cc), ',,', ',') FROM messages WHERE id = var_message_id), '');        
        IF var_users != ''
        THEN

            SET @var_stmt   = CONCAT("
                INSERT INTO message_users(message_id, type_id, role_id, sender_id, user_id, relation, created_at, created_by)
                SELECT ",
                    var_message_id, ",", var_params, ", 
                    id,
                    'c',
                    NOW(),
                    id
                FROM users
                WHERE id IN (", var_users, ");");
            
            PREPARE stmt FROM @var_stmt;
            EXECUTE stmt;

        END IF;

        
        SET var_message_id = IFNULL((SELECT MIN(id) FROM messages WHERE id > var_message_id), 0);

    END WHILE;  

END
$$

DROP FUNCTION IF EXISTS deprecated_20120423_sf_steelposition_get_qtty$$
CREATE FUNCTION deprecated_20120423_sf_steelposition_get_qtty(param_id INT)
  RETURNS int(11)
BEGIN

    DECLARE var_qtty        INT DEFAULT 0;
    DECLARE var_order_qtty  INT DEFAULT 0;

    
    SET var_qtty = (
        SELECT 
            COUNT(steelposition_items.id) 
        FROM steelposition_items
        JOIN steelitems ON steelitems.id = steelposition_items.steelitem_id
        WHERE steelposition_id = param_id
        AND is_deleted = 0
    );

    
    
    SET var_order_qtty = IFNULL((
        SELECT
            SUM(qtty) 
        FROM order_positions
        WHERE position_id = param_id
    ), 0);
    
    
    
    SET var_qtty = var_qtty - var_order_qtty;
    RETURN IF(var_qtty > 0, var_qtty, 0);

    










END
$$

DROP FUNCTION IF EXISTS sf_chat_get_today_first_message$$
CREATE FUNCTION sf_chat_get_today_first_message()
  RETURNS int(11)
BEGIN

    DECLARE var_message_id INT DEFAULT 0;

    # first message for today
    SET var_message_id = IFNULL((SELECT MIN(id) FROM messages WHERE created_at >= CURDATE()), 0);

    # last message for yesterday
    IF var_message_id = 0
    THEN
        SET var_message_id = IFNULL((SELECT MAX(id) + 1 FROM messages WHERE created_at < CURDATE()), 0);
    END IF;

    RETURN var_message_id;

END
$$

DROP FUNCTION IF EXISTS sf_gen_secret_code$$
CREATE FUNCTION sf_gen_secret_code(param_code_length  INT )
  RETURNS varchar(1024) CHARSET utf8
BEGIN
    
    DECLARE i      INT DEFAULT 32;
    DECLARE j      INT;
    DECLARE skip   INT;
    DECLARE rnd    INT;
    DECLARE result VARCHAR(1024) DEFAULT '';
    
    IF param_code_length > 0 
    THEN
        SET i = IF(param_code_length > 1024, 1024, param_code_length);
    END IF;
    
    WHILE i > 0 DO
        SET skip = FLOOR(RAND() * 7);

        WHILE j > 0 DO
            SET skip = FLOOR(RAND());
            SET j = j - 1;
        END WHILE;

        SET rnd = FLOOR(RAND() * 36);
        SET result = CONCAT(result, IF(rnd < 10, CHAR(48 + rnd), CHAR(87 + rnd)));
        SET i = i - 1;
    END WHILE;

    RETURN result;

END
$$

DROP FUNCTION IF EXISTS sf_get_activity_ancestors$$
CREATE FUNCTION sf_get_activity_ancestors(param_activity_id INT)
  RETURNS varchar(50) CHARSET utf8
BEGIN

    DECLARE var_ancestors   VARCHAR(50) DEFAULT '';
    DECLARE var_parent_id   INT DEFAULT 0;


    SET var_ancestors = param_activity_id;
    SET var_parent_id = IFNULL((SELECT parent_id FROM activities WHERE id = param_activity_id), 0);    
    
    WHILE var_parent_id > 0
    DO
    
        SET var_ancestors   = CONCAT(var_ancestors, ',', var_parent_id);
        SET var_parent_id   = IFNULL((SELECT parent_id FROM activities WHERE id = var_parent_id), 0);

    END WHILE;
    

    RETURN var_ancestors;

END
$$

DROP FUNCTION IF EXISTS sf_get_revision_id$$
CREATE FUNCTION sf_get_revision_id(param_date TIMESTAMP)
  RETURNS varchar(20) CHARSET utf8
BEGIN

    RETURN DATE_FORMAT(param_date, '%Y%m%d%H%i');

END
$$

DROP FUNCTION IF EXISTS sf_get_revision_table_name$$
CREATE FUNCTION sf_get_revision_table_name(param_table_name VARCHAR(50), param_date TIMESTAMP)
  RETURNS varchar(50) CHARSET utf8
BEGIN

    RETURN CONCAT(param_table_name, '_', DATE_FORMAT(param_date, '%Y%m%d%H%i'));

END
$$

DROP FUNCTION IF EXISTS sf_steelposition_get_qtty$$
CREATE FUNCTION sf_steelposition_get_qtty(param_id INT)
  RETURNS int(11)
BEGIN

    RETURN (
        SELECT 
            COUNT(*) 
        FROM steelitems
        WHERE steelposition_id = param_id
        AND is_available = 1
        AND is_deleted = 0
    );

END
$$

DELIMITER ;
