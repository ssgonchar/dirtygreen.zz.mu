SET NAMES 'utf8';

CREATE  TABLE `mam_local`.`emails_raw_corrupted`
(
  `id` INT NOT NULL ,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB
COMMENT = 'Данные о тех письмах, которые \'отграббились\' с ошибкой и не помещаются в emails_raw';

ALTER TABLE `emails_raw_corrupted`
    ADD COLUMN `username` VARCHAR(200) NULL COMMENT 'Наименование email-аккаунта'  AFTER `id`,
    ADD COLUMN `mailbox_name` VARCHAR(200) NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])'  AFTER `username`,
    ADD COLUMN `message_num` INT NULL COMMENT 'Номер сообщения на почтовом сервере'  AFTER `mailbox_name`,
    ADD COLUMN `error_message` TEXT NULL  AFTER `message_num`,
    ADD COLUMN `created_at` DATETIME NULL COMMENT 'Дата создания записи. Техническое поле'  AFTER `error_message`,
    ADD COLUMN `created_by` INT NULL COMMENT 'ID ВебПользователя кто создавал запись. Техническое поле'  AFTER `created_at`,
    ADD COLUMN `modified_at` DATETIME NULL COMMENT 'Дата редактирования записи. Техническое поле'  AFTER `created_by`,
    ADD COLUMN `modified_by` INT NULL COMMENT 'ID ВебПользователя кто вносил изменения. Техническое поле'  AFTER `modified_at`;
    
ALTER TABLE `emails_raw_corrupted`
    CHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT;
