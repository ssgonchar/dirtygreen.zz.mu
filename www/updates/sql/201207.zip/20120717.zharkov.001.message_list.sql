-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 18.07.2012 3:21:29
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_message_get_list$$
CREATE PROCEDURE sp_message_get_list(param_user_id INT, param_role_id INT, param_message_id INT)
sp:
BEGIN

    DECLARE ROLE_ADMIN      TINYINT DEFAULT 2;
    DECLARE ROLE_MODERATOR  TINYINT DEFAULT 4;
    DECLARE ROLE_STAFF      TINYINT DEFAULT 6;
    
    
    IF param_message_id = 0
    THEN        
        SET param_message_id = sf_chat_get_today_first_message();
    ELSE        
        SET param_message_id = param_message_id + 1;    # because of using greater or equal    
    END IF;


    IF param_role_id <= ROLE_ADMIN
    THEN

        SELECT
            id AS message_id
        FROM messages
        WHERE id >= param_message_id
        AND role_id >= param_role_id
        ORDER BY id DESC;
            
    ELSEIF param_role_id <= ROLE_STAFF
    THEN

        SELECT DISTINCT
            m.id AS message_id
        FROM messages AS m
        LEFT JOIN message_users AS mu ON m.id = mu.message_id
        WHERE m.id >= param_message_id
        AND m.role_id >= param_role_id
        AND (
            m.type_id != 1
            OR m.sender_id = param_user_id
            OR (m.type_id = 1 AND mu.user_id = param_user_id)
        )
        ORDER BY m.id DESC;            
        
    ELSE
            
        SELECT DISTINCT
            message_id
        FROM message_users
        WHERE message_id >= param_message_id
        AND role_id >= param_role_id
        AND (
            sender_id = param_user_id
            OR user_id = param_user_id
        )
        ORDER BY message_id DESC;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_message_get_list_for_object$$
CREATE PROCEDURE sp_message_get_list_for_object(param_user_id INT, param_role_id INT, param_object_alias CHAR(20), param_object_id INT, param_message_id INT, param_from INT, param_count INT)
sp:
BEGIN

    DECLARE ROLE_ADMIN              TINYINT DEFAULT 2;
    DECLARE ROLE_MODERATOR          TINYINT DEFAULT 4;
    DECLARE ROLE_STAFF              TINYINT DEFAULT 6;


    DROP TEMPORARY TABLE IF EXISTS t_message_ids;
    CREATE TEMPORARY TABLE t_message_ids(message_id INT, INDEX ix_t_message_ids (message_id));


    SET @var_user_id        = param_user_id;
    SET @var_role_id        = param_role_id;
    SET @var_object_alias   = param_object_alias;
    SET @var_object_id      = param_object_id;
    SET @var_from           = param_from;
    SET @var_count          = param_count;


    IF param_role_id <= ROLE_ADMIN
    THEN

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT 
                message_id
            FROM message_objects
            WHERE object_alias = ?
            AND object_id = ?
            AND role_id >= ?
            AND sender_id != 1
            ", IF(param_message_id > 0, CONCAT(" AND message_id > ", param_message_id), ""), 
        ";");
    
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id, @var_role_id;
            
    ELSEIF param_role_id <= ROLE_STAFF
    THEN

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT DISTINCT
                mo.message_id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = ?
            AND object_id = ?
            AND mo.role_id >= ?
            AND (
                mo.type_id != 1
                OR mo.sender_id = ?
                OR (mo.type_id = 1 AND user_id = ?)
            )
            AND mo.sender_id != 1
            ", IF(param_message_id > 0, CONCAT(" AND mo.message_id > ", param_message_id), ""), 
        ";");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id, @var_role_id, @var_user_id, @var_user_id;
        
    ELSE

        SET @var_stmt = CONCAT("   
            INSERT INTO t_message_ids(message_id)
            SELECT DISTINCT
                mo.message_id
            FROM message_objects AS mo
            JOIN message_users AS mu USING(message_id)
            WHERE object_alias = ?
            AND object_id = ?
            AND mo.role_id >= ?
            AND (
                mo.sender_id = ?
                OR (mu.user_id = ? AND mo.sender_id != 1)
            )
            ", IF(param_message_id > 0, CONCAT(" AND mo.message_id > ", param_message_id), ""), 
        ";");

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt USING @var_object_alias, @var_object_id, @var_role_id, @var_user_id, @var_user_id;

    END IF;



    SET @var_stmt = "
    SELECT
        *
    FROM t_message_ids
    ORDER BY message_id DESC
    LIMIT ?, ?;";
    

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @var_from, @var_count;


    SELECT 
        COUNT(*) AS count
    FROM t_message_ids;


    DROP TEMPORARY TABLE IF EXISTS t_message_ids;

END
$$

DELIMITER ;
