SET NAMES 'utf8';

ALTER TABLE `emails` ADD COLUMN `description_html` TEXT NULL COMMENT 'Тело письма в формате HTML' AFTER `description`;
