SET NAMES 'utf8';

DROP TABLE IF EXISTS `email_vocablurary`;
CREATE TABLE `email_vocablurary` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `word_set` VARCHAR(1000) NOT NULL COMMENT 'Ключевое слово и/или фраза для поиска',
    `associated_objects` VARCHAR(1000) DEFAULT NULL COMMENT 'Сериализованный массив объектов (alias,id), с которыми связана запись',
    PRIMARY KEY (`id`) )
ENGINE = MyISAM 
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci
COMMENT = 'Словарь ключевых слов и/или фраз для поиска и выделения сущностей в теле email-сообщения';
