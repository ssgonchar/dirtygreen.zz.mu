SET NAMES 'utf8';

DROP TABLE IF EXISTS `emails_raw`;
CREATE TABLE `emails_raw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mailbox_name` varchar(200) DEFAULT NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])',
  `message_num` int(11) DEFAULT NULL COMMENT 'Номер на почтовом сервере',
  `sender_email` varchar(200) DEFAULT NULL COMMENT 'Адрес электронной почты (email) отправителя',
  `recipient_email` varchar(200) DEFAULT NULL COMMENT 'Адрес электронной почты (email) получателя',
  `date` datetime DEFAULT NULL COMMENT 'Дата отправления (предположительно). Значение $objectStdClassHeaderInfo->date',
  `date_mail` datetime DEFAULT NULL COMMENT 'Дата получения (предположительно). Значение $objectStdClassHeaderInfo->MailDate',
  `udate` int(11) DEFAULT NULL COMMENT 'Параметр  пока не понятен (формат: 1339998599). Значение $objectStdClassHeaderInfo->udate',
  `subject` varchar(1000) DEFAULT NULL COMMENT 'Тема (заголовок)',
  `text_plain` text COMMENT 'Контент в тела в формате "Простой текст" (text/plain)',
  `text_html` text COMMENT 'Контент в тела в формате HTML (text/html)',
  `size_plain` int(11) DEFAULT '0' COMMENT 'Размер тела в формате "Простой текст" (text/plain), байты',
  `size_html` int(11) DEFAULT '0' COMMENT 'Размер тела в формате HTML (text/html), байты',
  `recent` tinyint(4) DEFAULT '0' COMMENT 'Параметр "Последнее и прочитано" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Recent',
  `unseen` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Просмотрено" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Unseen',
  `flagged` tinyint(4) DEFAULT '0' COMMENT 'Параметр "Установлен флаг" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Flagged',
  `answered` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "На сообщение ответили" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Answered',
  `deleted` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Удалено" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Deleted',
  `draft` tinyint(4) DEFAULT '0' COMMENT 'Параметр   "Отложено/Черновик" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Draft',
  `is_parsed` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Проанализировано ли" (Да/Нет 1/0 соответственно).',
  `has_attachments` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Есть ли вложенные файлы" (Да/Нет 1/0 соответственно).',
  `status_id` tinyint(4) DEFAULT '0' COMMENT 'Статус записи. Набор значений пока не определен.',
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания записи. Техническое поле',
  `created_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто создавал запись. Техническое поле',
  `modified_at` datetime DEFAULT NULL COMMENT 'Дата редактирования записи. Техническое поле',
  `modified_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто вносил изменения. Техническое поле',
  PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8
COMMENT='Преобразованные, но не проанализированные письма. "Сырые"';



DROP TABLE IF EXISTS `email_objects`;
CREATE TABLE `email_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` int(11) DEFAULT NULL COMMENT 'ID (emails.id) письма',
  `object_alias` varchar(20) DEFAULT NULL COMMENT 'ALIAS объекта, для которого прикрепляется письмо [biz,person,company]',
  `object_id` int(11) DEFAULT NULL COMMENT 'ID объекта, для которого прикрепляется письмо',
  PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARSET=utf8
COMMENT='Таблица для связи email-сообщений с сущностями(BIZes,Persons,Companies)';



ALTER TABLE `emails`
    ADD COLUMN `email_raw_id` INT NULL COMMENT 'ID \"сырого\" письма (emails_raw.id)' AFTER `sent_by`,
    ADD COLUMN `mailbox_name` VARCHAR(200) NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])' AFTER `email_raw_id`,
    ADD COLUMN `message_num` INT NULL COMMENT 'Номер на почтовом сервере' AFTER `mailbox_name`,
    ADD COLUMN `date_mail` INT NULL COMMENT 'Дата получения. Значение $objectStdClassHeaderInfo->MailDate' AFTER `message_num`,
    ADD COLUMN `recent` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Последнее и прочитано\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Recent' AFTER `date_mail`,
    ADD COLUMN `unseen` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Просмотрено\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Unseen' AFTER `recent`,
    ADD COLUMN `flagged` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Установлен флаг\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Flagged' AFTER `unseen`,
    ADD COLUMN `answered` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"На сообщение ответили\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Answered' AFTER `flagged`,
    ADD COLUMN `deleted` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Удалено\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Deleted' AFTER `answered`,
    ADD COLUMN `draft` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Отложено/Черновик\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Draft' AFTER `deleted`,
    ADD COLUMN `has_attachments` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Есть ли вложенные файлы\" (Да/Нет 1/0 соответственно).' AFTER `draft`
    ADD COLUMN `type_id` TINYINT DEFAULT NULL COMMENT 'Тип письма [INBOX/OUTBOX/DRAFT 1/2/3]' AFTER `has_attachments`;

ALTER TABLE `emails`
    CHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT, ADD PRIMARY KEY (`id`);
