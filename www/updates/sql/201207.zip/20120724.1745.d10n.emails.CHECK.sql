SET NAMES 'utf8';

DROP TABLE IF EXISTS `email_accounts`;
CREATE TABLE `email_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_domain` varchar(200) DEFAULT NULL COMMENT 'Наименование почтового домена',
  `username` varchar(200) DEFAULT NULL COMMENT 'Наименование конкретного email-аккаунта',
  `password` varchar(200) DEFAULT NULL COMMENT 'Пароль конкретного email-аккаунта',
  `port` int(11) DEFAULT NULL COMMENT 'Порт для доступа по IMAP',
  `flags` varchar(200) DEFAULT NULL COMMENT 'Дополнительные опции для доступа',
  `is_active` tinyint(4) DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица-справочник доступных почтовых адресов (mailboxes)';

--
-- Dumping data for table `email_accounts`
--
INSERT INTO `email_accounts` (`id`, `mail_domain`, `username`, `password`, `port`, `flags`, `is_active`, `title`) VALUES
(1, 'steelemotion.com', 'buy', 'Wise0pini0n', 143, '/imap/norsh', 1, NULL),
(2, 'steelemotion.com', 'direction', NULL, 143, '/imap/norsh', 0, NULL),
(3, 'steelemotion.com', 'equipment', 'C0ntractTime', 143, '/imap/norsh', 1, NULL),
(4, 'steelemotion.com', 'emotion', 'Key4Inspiration', 143, '/imap/norsh', 1, NULL),
(5, 'steelemotion.com', 'fax', '5MinuteD3cision', 143, '/imap/norsh', 1, NULL),
(6, 'steelemotion.com', 'gang', 'Window2China', 143, '/imap/norsh', 1, NULL),
(7, 'steelemotion.com', 'lamiere', 'Optima1Strategy', 143, '/imap/norsh', 1, NULL),
(8, 'steelemotion.com', 'mam', 'N3xtGeneration', 143, '/imap/norsh', 1, NULL),
(9, 'steelemotion.com', 'marking', 'L0ngTermPlan', 143, '/imap/norsh', 1, NULL),
(10, 'steelemotion.com', 'mycareer', 'Be3tRe3ult', 143, '/imap/norsh', 1, NULL),
(11, 'steelemotion.com', 'news', NULL, 143, '/imap/norsh', 0, NULL),
(12, 'steelemotion.com', 'plates', 'STEELstyle25', 143, '/imap/norsh', 1, NULL),
(13, 'steelemotion.com', 'platesahead', NULL, 143, '/imap/norsh', 0, NULL),
(14, 'steelemotion.com', 'steel', 'HighSpeed77', 143, '/imap/norsh', 1, NULL);



DROP TABLE IF EXISTS `email_delivered`;
CREATE TABLE `email_delivered` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `email_objects`;
CREATE TABLE `email_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` int(11) DEFAULT NULL COMMENT 'ID (emails.id) письма',
  `object_alias` varchar(20) DEFAULT NULL COMMENT 'ALIAS объекта, для которого прикрепляется письмо [biz,person,company]',
  `object_id` int(11) DEFAULT NULL COMMENT 'ID объекта, для которого прикрепляется письмо',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_email_objects` (`object_id`,`object_alias`,`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица для связи email-сообщений с сущностями(BIZes,Persons';



DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_raw_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) DEFAULT NULL COMMENT '1 - INBOX, 2 - OUTBOX, 3 - DRAFT',
  `object_alias` char(20) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `sender_address` varchar(250) DEFAULT NULL,
  `recipient_address` varchar(1000) DEFAULT NULL,
  `to` varchar(250) DEFAULT NULL COMMENT 'Company title',
  `attention` varchar(250) DEFAULT NULL COMMENT 'Person name',
  `subject` varchar(250) DEFAULT NULL,
  `our_ref` varchar(250) DEFAULT NULL COMMENT 'Biz ref',
  `your_ref` varchar(250) DEFAULT NULL COMMENT 'Customer ref',
  `title` varchar(1000) DEFAULT NULL,
  `description` text,
  `signature` varchar(250) DEFAULT NULL,
  `number` int(11) DEFAULT NULL COMMENT 'Author email number',
  `date_mail` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `sent_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `emails_raw`;
CREATE TABLE `emails_raw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL COMMENT 'Наименование email-аккаунта',
  `mailbox_name` varchar(200) DEFAULT NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])',
  `message_num` int(11) DEFAULT NULL COMMENT 'Номер на почтовом сервере',
  `sender_email` varchar(200) DEFAULT NULL COMMENT 'Адрес электронной почты (email) отправителя',
  `recipient_email` varchar(200) DEFAULT NULL COMMENT 'Адрес электронной почты (email) получателя',
  `date` datetime DEFAULT NULL COMMENT 'Дата отправления (предположительно). Значение $objectStdClassHeaderInfo->date',
  `date_mail` datetime DEFAULT NULL COMMENT 'Дата получения (предположительно). Значение $objectStdClassHeaderInfo->MailDate',
  `udate` int(11) DEFAULT NULL COMMENT 'Параметр  пока не понятен (формат: 1339998599). Значение $objectStdClassHeaderInfo->udate',
  `subject` varchar(1000) DEFAULT NULL COMMENT 'Тема (заголовок)',
  `text_plain` text COMMENT 'Контент в тела в формате "Простой текст" (text/plain)',
  `text_html` text COMMENT 'Контент в тела в формате HTML (text/html)',
  `size_plain` int(11) DEFAULT '0' COMMENT 'Размер тела в формате "Простой текст" (text/plain), байты',
  `size_html` int(11) DEFAULT '0' COMMENT 'Размер тела в формате HTML (text/html), байты',
  `recent` tinyint(4) DEFAULT '0' COMMENT 'Параметр "Последнее и прочитано" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Recent',
  `unseen` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Просмотрено" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Unseen',
  `flagged` tinyint(4) DEFAULT '0' COMMENT 'Параметр "Установлен флаг" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Flagged',
  `answered` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "На сообщение ответили" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Answered',
  `deleted` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Удалено" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Deleted',
  `draft` tinyint(4) DEFAULT '0' COMMENT 'Параметр   "Отложено/Черновик" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Draft',
  `is_parsed` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Проанализировано ли" (Да/Нет 1/0 соответственно).',
  `has_attachments` tinyint(4) DEFAULT '0' COMMENT 'Параметр  "Есть ли вложенные файлы" (Да/Нет 1/0 соответственно).',
  `status_id` tinyint(4) DEFAULT '0' COMMENT 'Статус записи. Набор значений пока не определен.',
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания записи. Техническое поле',
  `created_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто создавал запись. Техническое поле',
  `modified_at` datetime DEFAULT NULL COMMENT 'Дата редактирования записи. Техническое поле',
  `modified_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто вносил изменения. Техническое поле',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Преобразованные, но не проанализированные письма. "Сырые"';



DROP TABLE IF EXISTS `emails_raw_corrupted`;
CREATE TABLE `emails_raw_corrupted` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL COMMENT 'Наименование email-аккаунта',
  `mailbox_name` varchar(200) DEFAULT NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])',
  `message_num` int(11) DEFAULT NULL COMMENT 'Номер сообщения на почтовом сервере',
  `error_message` text,
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания записи. Техническое поле',
  `created_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто создавал запись. Техническое поле',
  `modified_at` datetime DEFAULT NULL COMMENT 'Дата редактирования записи. Техническое поле',
  `modified_by` int(11) DEFAULT NULL COMMENT 'ID ВебПользователя кто вносил изменения. Техническое поле',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Данные о тех письмах, которые ''отграббились'' с ошибкой и не помещаются в emails_raw';


