ALTER TABLE `attachments` ADD INDEX `ix-obj-alias-id` ( `object_id` , `object_alias` ) ;

/*
CREATE TABLE email_accounts(
    id INT(11) NOT NULL AUTO_INCREMENT,
    title VARCHAR(50) DEFAULT NULL,
    email VARCHAR(50) DEFAULT NULL,
    PRIMARY KEY (id))
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;


CREATE TABLE email_objects(
    id INT(11) NOT NULL AUTO_INCREMENT,
    object_alias CHAR(20) DEFAULT NULL,
    object_id INT(11) DEFAULT NULL,
    email_account_id INT(11) DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    created_by INT(11) DEFAULT NULL,
    PRIMARY KEY (id),
    INDEX IX_email_objects (object_id, object_alias, email_account_id))
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;
*/

CREATE TABLE user_email_accounts(
    id INT(11) NOT NULL AUTO_INCREMENT,
    user_id INT(11) NOT NULL,
    email_account_id INT(11) DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    created_by INT(11) DEFAULT NULL,
    PRIMARY KEY (id),
    INDEX IX_user_email_accounts_user_id (user_id))
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;