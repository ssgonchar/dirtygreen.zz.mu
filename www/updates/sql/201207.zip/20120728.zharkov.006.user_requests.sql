-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 28.07.2012 10:00:02
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DROP TABLE IF EXISTS user_requests;
CREATE TABLE user_requests(
    id INT(11) NOT NULL AUTO_INCREMENT,
    domain CHAR(10) DEFAULT NULL,
    login VARCHAR(20) DEFAULT NULL,
    `password` VARCHAR(32) DEFAULT NULL,
    email VARCHAR(250) DEFAULT NULL,
    title CHAR(5) DEFAULT NULL,
    first_name VARCHAR(50) DEFAULT NULL,
    last_name VARCHAR(50) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    skype VARCHAR(100) DEFAULT NULL,
    company_name VARCHAR(250) DEFAULT NULL,
    website VARCHAR(1000) DEFAULT NULL,
    country_id INT(11) DEFAULT NULL,
    is_confirmed TINYINT(4) DEFAULT NULL,
    status TINYINT(4) DEFAULT NULL,
    secret_code VARCHAR(32) DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP NULL DEFAULT NULL,
    status_at TIMESTAMP NULL DEFAULT NULL,
    status_by INT(11) DEFAULT NULL,
    PRIMARY KEY (id))
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_user_request_add$$
CREATE PROCEDURE sp_user_request_add(param_domain CHAR(10), param_login VARCHAR(20), param_password VARCHAR(32), param_email VARCHAR(250), 
                                        param_title CHAR(5), param_first_name VARCHAR(50), param_last_name VARCHAR(50), param_phone VARCHAR(20),
                                        param_skype VARCHAR(100), param_company_name VARCHAR(250), param_website VARCHAR(1000),
                                        param_country_id INT(11))
sp:
BEGIN

    DECLARE var_secret_code VARCHAR(32) DEFAULT '';
    
    IF EXISTS (SELECT * FROM users WHERE login = param_login AND `password` = param_password AND email = param_email) 
    THEN
        SELECT -1 AS ErrorCode, 'sp_user_request_add' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_secret_code = CONCAT(sf_gen_secret_code(26), IFNULL((SELECT MAX(id) FROM user_requests), 0) + 1);

    INSERT INTO user_requests
    SET
        domain          = param_domain,
        login           = param_login,
        `password`      = param_password,
        email           = param_email,
        title           = param_title,
        first_name      = param_first_name,
        last_name       = param_last_name,
        phone           = param_phone,
        skype           = param_skype,
        company_name    = param_company_name,
        website         = param_website,
        country_id      = param_country_id,
        is_confirmed    = 0,
        is_processed    = 0,
        secret_code     = var_secret_code,
        created_at      = NOW();
        
    SELECT var_secret_code AS secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_confirm$$
CREATE PROCEDURE sp_user_request_confirm(param_secret_code VARCHAR(32))
BEGIN

    UPDATE user_requests
    SET
        is_confirmed    = 1,
        confirmed_at    = NOW()
    WHERE secret_code = param_secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_get$$
CREATE PROCEDURE sp_user_request_get(param_secret_code VARCHAR(32))
BEGIN

    SELECT 
        *
    FROM user_requests
    WHERE secret_code = param_secret_code;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_get_by_login$$
CREATE PROCEDURE sp_user_request_get_by_login(param_login VARCHAR(20), param_password VARCHAR(32))
BEGIN

    SELECT 
        *
    FROM user_requests
    WHERE login = param_login
    AND `password` = param_password;

END
$$

DROP PROCEDURE IF EXISTS sp_user_request_get_list$$
CREATE PROCEDURE sp_user_request_get_list()
BEGIN

    SELECT
        *
    FROM user_requests
    ORDER BY created_at DESC;

END
$$

DELIMITER ;
