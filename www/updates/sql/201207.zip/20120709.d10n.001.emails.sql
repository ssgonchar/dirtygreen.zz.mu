SET NAMES 'utf8';

ALTER TABLE `emails_raw`
    CHANGE COLUMN `has_attachments` `has_attachments` TINYINT(4) NULL DEFAULT '0' COMMENT 'Параметр \"Есть ли вложенные файлы\" (Да/Нет 1/0 соответственно).';

ALTER TABLE `emails`
    ADD COLUMN `email_raw_id` INT NULL COMMENT 'ID \"сырого\" письма (emails_raw.id)' AFTER `sent_by`,
    ADD COLUMN `mailbox_name` VARCHAR(200) NULL COMMENT 'Наименование МеилБокса почтового аккаунта. ({hostname:port/options}mboxname [{steelemotion.com:143/imap/norsh}EMOTION])' AFTER `email_raw_id`,
    ADD COLUMN `message_num` INT NULL COMMENT 'Номер на почтовом сервере' AFTER `mailbox_name`,
    ADD COLUMN `date_mail` INT NULL COMMENT 'Дата получения. Значение $objectStdClassHeaderInfo->MailDate' AFTER `message_num`,
    ADD COLUMN `recent` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Последнее и прочитано\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Recent' AFTER `date_mail`,
    ADD COLUMN `unseen` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Просмотрено\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Unseen' AFTER `recent`,
    ADD COLUMN `flagged` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Установлен флаг\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Flagged' AFTER `unseen`,
    ADD COLUMN `answered` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"На сообщение ответили\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Answered' AFTER `flagged`,
    ADD COLUMN `deleted` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Удалено\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Deleted' AFTER `answered`,
    ADD COLUMN `draft` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Отложено/Черновик\" (Да/Нет 1/0 соответственно). Значение $objectStdClassHeaderInfo->Draft' AFTER `deleted`,
    ADD COLUMN `has_attachments` TINYINT NULL DEFAULT 0 COMMENT 'Параметр \"Есть ли вложенные файлы\" (Да/Нет 1/0 соответственно).' AFTER `draft`;

ALTER TABLE `emails`
    CHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT, ADD PRIMARY KEY (`id`);
    
ALTER TABLE `email_objects`
    CHANGE COLUMN `emails_raw_id` `email_id` INT(11) NULL DEFAULT NULL COMMENT 'ID (emails.id) письма';
