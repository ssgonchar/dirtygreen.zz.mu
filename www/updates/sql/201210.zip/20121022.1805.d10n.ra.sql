delimiter $$

DROP PROCEDURE IF EXISTS `sp_ra_get_by_id`$$
CREATE PROCEDURE `sp_ra_get_by_id`(IN param_id INT)
BEGIN
    SELECT ra.* FROM ra WHERE ra.id = param_id;
END$$


DROP PROCEDURE IF EXISTS `sp_ra_remove_item`$$
CREATE PROCEDURE `sp_ra_remove_item`(
	IN param_user_id INT,
	IN param_ra_id INT,
	IN param_ra_item_id INT
)
sp:
BEGIN
	DECLARE var_parent_id 			INT 	DEFAULT -1;
	DECLARE var_item_id 			INT 	DEFAULT -1;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT -1;
	DECLARE var_steelitem_order_id	INT		DEFAULT -1;

	DECLARE ITEM_STATUS_PRODUCTION	TINYINT DEFAULT 1;
	DECLARE ITEM_STATUS_STOCK 		TINYINT DEFAULT 2;
	DECLARE ITEM_STATUS_ORDERED 	TINYINT DEFAULT 3;
	DECLARE ITEM_STATUS_RELEASED 	TINYINT DEFAULT 4;
	DECLARE ITEM_STATUS_DELIVERED 	TINYINT DEFAULT 5;
	DECLARE ITEM_STATUS_INVOICED 	TINYINT DEFAULT 6;

    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

	SELECT
		IFNULL(parent_id, -1),
		IFNULL(steelitem_id, -1)
	INTO
		var_parent_id,
		var_item_id
	FROM ra_items
	WHERE
			id = param_ra_item_id
		AND ra_id = param_ra_id
	;

	IF var_parent_id = -1
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;
	
	START TRANSACTION;
		IF var_parent_id = 0
		THEN
			SELECT
				IFNULL(status_id, -1),
				IFNULL(order_id, -1)
			INTO
				var_steelitem_status_id,
				var_steelitem_order_id
			FROM steelitems
			WHERE
				id = var_item_id
			;

			IF var_steelitem_status_id = ITEM_STATUS_RELEASED
			THEN
				UPDATE steelitems
				SET
					status_id	= (CASE WHEN var_steelitem_order_id > 0 THEN ITEM_STATUS_ORDERED ELSE ITEM_STATUS_STOCK END),
					modified_at	= NOW(),
					modified_by	= param_user_id
				WHERE
					id = var_item_id
				;
			END IF;

			DELETE FROM attachment_objects WHERE object_alias = 'ra' AND object_id = param_ra_id;
			
			DELETE FROM ra_items WHERE ra_id = param_ra_id AND parent_id = var_parent_id;
		END IF;
		
		DELETE FROM ra_items WHERE id = param_ra_item_id;
	COMMIT;
    
    SELECT param_ra_item_id AS id;

    
END$$


DROP PROCEDURE IF EXISTS `sp_ra_set_primary_item`$$
CREATE PROCEDURE `sp_ra_set_primary_item`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_item_id INT
)
sp:
BEGIN
	IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primay_item' AS ErrorAt;
        LEAVE sp;
    END IF;

	START TRANSACTION;
		UPDATE ra_items SET parent_id = param_ra_item_id WHERE ra_id = param_id;

		UPDATE ra_items
		SET
			parent_id = 0,
			modified_at	= NOW(),
			modified_by	= param_user_id
		WHERE
				id = param_ra_item_id
			AND ra_id = param_id
		;

		DELETE FROM attachment_objects WHERE object_alias = 'ra' AND object_id = param_id;
	COMMIT;

	SELECT param_ra_item_id AS ra_item_id;
END$$

delimiter ;
