DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_ra_get_by_id`$$
CREATE PROCEDURE `sp_ra_get_by_id`(IN param_id INT)
BEGIN

    SELECT
        ra.*
    FROM ra
    WHERE
		ra.id = param_id
	;

END$$

DROP PROCEDURE IF EXISTS `sp_ra_get_list_by_ids`$$
CREATE PROCEDURE `sp_ra_get_list_by_ids`(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            ra.*
        FROM ra
        WHERE
			ra.id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END$$

DROP PROCEDURE IF EXISTS `sp_ra_save`$$
CREATE PROCEDURE `sp_ra_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_stockholder_id INT,
	IN param_company_id INT,
	IN param_truck_number VARCHAR(50),
	IN param_marking TEXT,
	IN param_dunnaging TEXT,
	IN param_max_weight DECIMAL(10,4),
	IN param_weighed_weight DECIMAL(10,4),
	IN param_ddt_id INT
)
sp:
BEGIN
	IF param_id = 0
	THEN
		START TRANSACTION;
			INSERT INTO ra
			SET
				`number`			= IFNULL((SELECT MAX(`ra2`.`number`) FROM ra AS ra2), 1),
				`stockholder_id`	= param_stockholder_id,
				`company_id`		= param_company_id,
				`truck_number`		= param_truck_number,
				`marking`			= param_marking,
				`dunnaging`			= param_dunnaging,
				`status_id`			= param_status_id,
				`max_weight`		= param_max_weight,
				`weighed_weight`	= param_weighed_weight,
				`ddt_id`			= param_ddt_id,
				`created_at`		= NOW(),
				`created_by`		= param_user_id,
				`modified_at`		= NOW(),
				`modified_by`		= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra WHERE `created_by` = param_user_id);
		COMMIT;
	ELSE
		UPDATE ra
		SET
			`stockholder_id`	= param_stockholder_id,
			`company_id`		= param_company_id,
			`truck_number`		= param_truck_number,
			`marking`			= param_marking,
			`dunnaging`			= param_dunnaging,
			`status_id`			= param_status_id,
			`max_weight`		= param_max_weight,
			`weighed_weight`	= param_weighed_weight,
			`ddt_id`			= param_ddt_id,
			`modified_at`		= NOW(),
			`modified_by`		= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ra_id;
END$$


DELIMITER ;
