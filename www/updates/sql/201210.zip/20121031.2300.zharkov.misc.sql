ALTER TABLE `steelpositions_reserved` ADD INDEX `is-steelpotion_id` ( `steelposition_id` );
ALTER TABLE `steelitems` ADD INDEX `ix-steelposition_id` ( `steelposition_id` );
ALTER TABLE `ra_items` ADD UNIQUE `ix-ra_items-items` ( `ra_id` , `steelitem_id` , `parent_id` );

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_ra_remove_item$$
DROP PROCEDURE IF EXISTS sp_ra_item_save$$
DROP PROCEDURE IF EXISTS sp_ra_items_add_from_stock$$

DROP PROCEDURE IF EXISTS sp_steelposition_get_quick_by_ids$$
CREATE PROCEDURE sp_steelposition_get_quick_by_ids(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelposition_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT SUM(qtty) FROM steelpositions_reserved WHERE steelposition_id = steelpositions.id) AS reserved,
            IFNULL((SELECT GROUP_CONCAT(guid SEPARATOR \", \") FROM steelitems WHERE is_locked = 0 AND is_available = 1 AND steelposition_id = steelpositions.id AND guid NOT IN ('')), '') AS plate_ids,
            IFNULL((SELECT GROUP_CONCAT(DISTINCT title SEPARATOR \", \") FROM locations WHERE id IN (SELECT location_id FROM steelitems WHERE is_locked = 0 AND is_available = 1 AND steelposition_id = steelpositions.id)), '') AS locations,
            IFNULL((SELECT GROUP_CONCAT(DISTINCT supplier_id SEPARATOR \", \") FROM steelitems WHERE is_locked = 0 AND is_available = 1 AND steelposition_id = steelpositions.id AND supplier_id NOT IN (0)), '') AS supplier_ids
        FROM steelpositions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DROP PROCEDURE IF EXISTS sp_order_add_item$$
CREATE PROCEDURE sp_order_add_item(param_user_id INT, param_order_id INT, param_position_id INT, param_item_id INT, param_status_id TINYINT)
sp:
BEGIN

    DECLARE var_parent_id       INT DEFAULT 0;
    DECLARE var_is_locked       TINYINT DEFAULT 0;
    DECLARE var_is_conflicted   TINYINT DEFAULT 0;

    
    IF param_item_id = 0
    THEN
    
        SET param_item_id = sf_create_order_position_item(param_user_id, param_order_id, param_position_id);

        
        SELECT
            param_item_id       AS steelitem_id,
            param_position_id   AS steelposition_id;

    ELSE

        IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id)
        THEN
            SELECT -1 AS ErrorCode, 'sp_order_add_item' AS ErrorAt;
            LEAVE sp;
        END IF;
    
        
        SELECT
            parent_id,
            is_locked
        INTO
            var_parent_id,
            var_is_locked
        FROM steelitems
        WHERE id = param_item_id;


        UPDATE steelitems
        SET
            is_available    = 0,
            is_conflicted   = var_is_locked,
            order_id        = param_order_id,
            is_locked       = 1,
            status_id       = param_status_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_item_id;
    
    
        IF var_is_locked = 0
        THEN
    
            IF var_parent_id = 0
            THEN
    
                UPDATE steelitems
                SET
                    is_locked = 1
                WHERE parent_id = param_item_id
                AND is_available = 1;
    
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id 
                OR (parent_id = param_item_id AND is_available = 1);
    
            ELSE
    
                UPDATE steelitems
                SET
                    is_locked = 1
                WHERE (parent_id = var_parent_id OR id = var_parent_id)
                AND is_available = 1;
    
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id
                OR (
                    (parent_id = var_parent_id OR id = var_parent_id) 
                    AND is_available = 1
                );
    
            END IF;        
    
        ELSE
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id; 
                
        END IF;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_item_add$$
CREATE PROCEDURE sp_ra_item_add(param_user_id INT, param_parent_id INT, param_ra_id INT, param_item_id INT, param_status_id TINYINT)
sp:
BEGIN

    START TRANSACTION;

        SET @var_parent_id  = param_parent_id;
        SET @var_ra_id      = param_ra_id;
        SET @var_user_id    = param_user_id;
        SET @var_status_id  = param_status_id;
        
        INSERT IGNORE INTO ra_items
        SET
            ra_id           = param_ra_id, 
            parent_id       = param_parent_id, 
            steelitem_id    = param_item_id, 
            created_at      = NOW(), 
            created_by      = param_user_id, 
            modified_at     = NOW(), 
            modified_by     = param_user_id;


        IF param_parent_id = 0
        THEN
            
            UPDATE steelitems
            SET
                status_id   = param_status_id,
                modified_at = NOW(),
                modified_by = param_user_id
            WHERE id = param_item_id AND order_id > 0;

            INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
            SELECT
                attachment_id,
                `type`,
                'steelitem',
                param_item_id,
                NOW(),
                param_user_id
            FROM attachment_objects
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id;
        
        END IF;
    
    COMMIT;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_item_remove$$
CREATE PROCEDURE sp_ra_item_remove(param_user_id INT, param_ra_id INT, param_ra_item_id INT, param_status_id TINYINT)
sp:
BEGIN
	DECLARE var_parent_id 			INT 	DEFAULT 0;
	DECLARE var_steelitem_id 		INT 	DEFAULT 0;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT 0;
	DECLARE var_steelitem_order_id	INT		DEFAULT 0;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 4;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';


    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT
        *
    FROM ra_items
    WHERE id = param_ra_item_id;


	SELECT
		parent_id,
		steelitem_id
	INTO
		var_parent_id,
		var_steelitem_id
	FROM ra_items
	WHERE id = param_ra_item_id;

    IF var_parent_id = 0
    THEN
    
        DELETE FROM ra_items 
        WHERE ra_id = param_ra_id 
        AND parent_id = param_ra_item_id;

        
        UPDATE steelitems
        SET
            status_id   = param_status_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = var_steelitem_id
        AND order_id > 0
        AND status_id = ITEM_STATUS_RELEASED;

        
        SET var_attachment_ids = (
            SELECT 
                GROUP_CONCAT(attachment_id SEPARATOR ",") 
            FROM attachment_objects 
            WHERE object_alias = 'ra'
            AND object_id = param_ra_id
        );

        SET @var_stmt := CONCAT("
            DELETE FROM attachment_objects 
            WHERE object_alias = 'steelitem'
            AND object_id = " , var_steelitem_id, 
            " AND attachment_id IN (", var_attachment_ids, ")
        ");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;    

    END IF;
    
    DELETE FROM ra_items 
    WHERE id = param_ra_item_id;
    
END
$$

DROP PROCEDURE IF EXISTS sp_ra_set_primary_item$$
CREATE PROCEDURE sp_ra_set_primary_item(param_user_id INT, param_ra_id INT, param_ra_item_id INT)
sp:
BEGIN

    DECLARE var_parent_id           INT DEFAULT 0;
    DECLARE var_prev_steelitem_id   INT DEFAULT 0;
    DECLARE var_new_steelitem_id    INT DEFAULT 0;
    DECLARE var_attachment_ids      VARCHAR(1100) DEFAULT '';

    IF NOT EXISTS (SELECT * FROM ra_items WHERE ra_id = param_ra_id AND id = param_ra_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    SET var_parent_id = (SELECT parent_id FROM ra_items WHERE id = param_ra_item_id);

    IF var_parent_id = 0 
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_set_primary_item' AS ErrorAt;
        LEAVE sp;        
    END IF;


    SET var_prev_steelitem_id   = (SELECT steelitem_id FROM ra_items WHERE id = var_parent_id);
    SET var_new_steelitem_id    = (SELECT steelitem_id FROM ra_items WHERE id = param_ra_item_id);

    
    UPDATE ra_items
    SET 
        parent_id = 0 
    WHERE id = param_ra_item_id;
    
    UPDATE ra_items 
    SET 
        parent_id = param_ra_item_id 
    WHERE id = var_parent_id;

    UPDATE ra_items 
    SET 
        parent_id = param_ra_item_id 
    WHERE parent_id = var_parent_id
    AND ra_id = param_ra_id;


    SET var_attachment_ids = (
        SELECT 
            GROUP_CONCAT(attachment_id SEPARATOR ",") 
        FROM attachment_objects 
        WHERE object_alias = 'ra'
        AND object_id = param_ra_id
    );

    SET @var_stmt := CONCAT("
        DELETE FROM attachment_objects 
        WHERE object_alias = 'steelitem'
        AND object_id = " , var_prev_steelitem_id, 
        " AND attachment_id IN (", var_attachment_ids, ")
    ");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

    INSERT IGNORE INTO attachment_objects(attachment_id, `type`, object_alias, object_id, created_at, created_by)
    SELECT
        attachment_id, 
        `type`,
        'steelitem',
        var_new_steelitem_id,
        NOW(),
        param_user_id
    FROM attachment_objects
    WHERE object_alias = 'ra'
    AND object_id = param_ra_id;

    
    SELECT 
        var_prev_steelitem_id   AS prev_steelitem_id,
        var_new_steelitem_id    AS new_steelitem_id;

END
$$

DELIMITER ;
