DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_ra_items_add_from_stock`$$
CREATE PROCEDURE `sp_ra_items_add_from_stock`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_object_alias VARCHAR(10),
	IN param_object_ids VARCHAR(1100)
)
sp:
BEGIN

    IF NOT EXISTS (SELECT id FROM ra WHERE id = param_id)
	THEN
		SELECT -1 AS ErrorCode, 'sp_ra_items_add_from_stock' AS ErrorAt;
		LEAVE sp;
	END IF;

	IF param_object_alias NOT IN ('item', 'position')
	THEN
		SELECT -2 AS ErrorCode, 'sp_ra_items_add_from_stock' AS ErrorAt;
		LEAVE sp;
	END IF;

	IF param_object_alias = 'item'
	THEN
		SET @var_stmt = CONCAT(
			"INSERT IGNORE INTO ra_items
			(
				ra_id,
				parent_id,
				steelitem_id,
				created_at,
				created_by,
				modified_at,
				modified_by
			)
			SELECT 
				", param_id, ",
				0,
				id,
				NOW(),
				", param_user_id, ",
				NOW(),
				", param_user_id, "
			FROM steelitems
			WHERE
					id IN (", param_object_ids, ")
				AND is_locked = 0;"
		);
	ELSEIF  param_object_alias = 'position'
	THEN
		SET @var_stmt = CONCAT(
			"INSERT INTO ra_items
			(
				ra_id,
				parent_id,
				steelitem_id,
				created_at,
				created_by,
				modified_at,
				modified_by
			)
			SELECT 
				", param_id, ",
				0,
				id,
				NOW(),
				", param_user_id, ",
				NOW(),
				", param_user_id, "
			FROM steelitems
			WHERE
					steelposition_id IN (", param_object_ids, ")
				AND is_locked = 0;"
		);
		
	END IF;
    
    PREPARE stmt FROM @var_stmt;
	EXECUTE stmt;

END$$


DROP PROCEDURE IF EXISTS `sp_ra_remove_item`$$
CREATE PROCEDURE `sp_ra_remove_item`(
	IN param_user_id INT,
	IN param_ra_id INT,
	IN param_ra_item_id INT
)
sp:
BEGIN
	DECLARE var_parent_id 			INT 	DEFAULT -1;
	DECLARE var_item_id 			INT 	DEFAULT -1;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT -1;
	DECLARE var_steelitem_order_id	INT		DEFAULT -1;

	DECLARE ITEM_STATUS_PRODUCTION	TINYINT DEFAULT 1;
	DECLARE ITEM_STATUS_STOCK 		TINYINT DEFAULT 2;
	DECLARE ITEM_STATUS_ORDERED 	TINYINT DEFAULT 3;
	DECLARE ITEM_STATUS_RELEASED 	TINYINT DEFAULT 4;
	DECLARE ITEM_STATUS_DELIVERED 	TINYINT DEFAULT 5;
	DECLARE ITEM_STATUS_INVOICED 	TINYINT DEFAULT 6;

    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

	SELECT
		IFNULL(parent_id, -1),
		IFNULL(steelitem_id, -1)
	INTO
		var_parent_id,
		var_item_id
	FROM ra_items
	WHERE
			id = param_ra_item_id
		AND ra_id = param_ra_id
	;
	
	IF var_parent_id = -1
    THEN
        SELECT -2 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;
	
	START TRANSACTION;
		IF var_parent_id = 0
		THEN
			SELECT
				IFNULL(status_id, -1),
				IFNULL(order_id, -1)
			INTO
				var_steelitem_status_id,
				var_steelitem_order_id
			FROM steelitems
			WHERE
				id = var_item_id
			;

			IF var_steelitem_status_id = ITEM_STATUS_RELEASED
			THEN
				UPDATE steelitems
				SET
					status_id	= (CASE WHEN var_steelitem_order_id > 0 THEN ITEM_STATUS_ORDERED ELSE ITEM_STATUS_STOCK END),
					modified_at	= NOW(),
					modified_by	= param_user_id
				WHERE
					id = var_item_id
				;
			END IF;

			DROP TEMPORARY TABLE IF EXISTS tmp_att_objects;
			CREATE TEMPORARY TABLE tmp_att_objects(
				id INT(11) NOT NULL PRIMARY KEY,
				KEY `IX_ID` (`id`)
			) ENGINE MyISAM;

			INSERT INTO tmp_att_objects (id)
			SELECT attachment_id
			FROM attachment_objects
			WHERE
					object_alias = 'ra'
				AND object_id = param_ra_id;

			DELETE FROM attachment_objects
			WHERE
					object_alias = 'steelitem'
				AND object_id = var_item_id
				AND attachment_id IN (SELECT id FROM tmp_att_objects);
			
			DROP TEMPORARY TABLE IF EXISTS tmp_att_objects;
			
			DELETE FROM ra_items WHERE ra_id = param_ra_id AND parent_id = param_ra_item_id;
		END IF;
		
		DELETE FROM ra_items WHERE id = param_ra_item_id;
	COMMIT;
    
    SELECT param_ra_item_id AS id;

    
END$$


DROP PROCEDURE IF EXISTS `sp_ra_set_primary_item`$$
CREATE PROCEDURE `sp_ra_set_primary_item`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_ra_item_id INT
)
sp:
BEGIN
	DECLARE ITEM_STATUS_PRODUCTION	TINYINT DEFAULT 1;
	DECLARE ITEM_STATUS_STOCK 		TINYINT DEFAULT 2;
	DECLARE ITEM_STATUS_ORDERED 	TINYINT DEFAULT 3;
	DECLARE ITEM_STATUS_RELEASED 	TINYINT DEFAULT 4;
	DECLARE ITEM_STATUS_DELIVERED 	TINYINT DEFAULT 5;
	DECLARE ITEM_STATUS_INVOICED 	TINYINT DEFAULT 6;

	DECLARE var_prev_parent_id 		INT 	DEFAULT -1;
	DECLARE var_steelitem_id 		INT 	DEFAULT -1;
	DECLARE var_steelitem_status_id TINYINT	DEFAULT -1;
	DECLARE var_steelitem_order_id	INT		DEFAULT -1;

	IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_set_primay_item' AS ErrorAt;
        LEAVE sp;
    END IF;

	START TRANSACTION;
		SET var_prev_parent_id = IFNULL((SELECT parent_id FROM ra_items WHERE id = param_ra_item_id AND ra_id = param_id), 0);

		UPDATE ra_items
		SET parent_id = param_ra_item_id
		WHERE
				(id = var_prev_parent_id OR parent_id = var_prev_parent_id)
			AND ra_id = param_id
		;

		UPDATE ra_items
		SET
			parent_id = 0,
			modified_at	= NOW(),
			modified_by	= param_user_id
		WHERE
				id = param_ra_item_id
			AND ra_id = param_id
		;

		DROP TEMPORARY TABLE IF EXISTS tmp_att_objects;
		CREATE TEMPORARY TABLE tmp_att_objects(
			id INT(11) NOT NULL PRIMARY KEY,
			KEY `IX_ID` (`id`)
		) ENGINE MyISAM;

		INSERT INTO tmp_att_objects (id)
		SELECT attachment_id
		FROM attachment_objects
		WHERE
				object_alias = 'ra'
			AND object_id = param_id;

		DELETE FROM attachment_objects
		WHERE
				object_alias = 'steelitem'
			AND object_id = param_ra_item_id
			AND attachment_id IN (SELECT id FROM tmp_att_objects);

		DROP TEMPORARY TABLE IF EXISTS tmp_att_objects;
	COMMIT;

	SELECT param_ra_item_id AS ra_item_id;
END$$


DELIMITER ;
