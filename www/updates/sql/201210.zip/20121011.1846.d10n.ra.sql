DROP TABLE IF EXISTS `ra`;
CREATE TABLE `ra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) DEFAULT NULL,
  `stockholder_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `truck_number` varchar(50) DEFAULT NULL,
  `marking` text,
  `dunnaging` text,
  `status_id` tinyint(4) DEFAULT NULL COMMENT '[1 - RA_STATUS_OPEN, 2 - RA_STATUS_CLOSED]',
  `max_weight` decimal(10,4) DEFAULT NULL COMMENT 'максимальный вес, unitweight всех айтемов x0.06',
  `weighed_weight` decimal(10,4) DEFAULT NULL,
  `ddt_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='Release Advices';

DROP TABLE IF EXISTS `ra_items`;
CREATE TABLE `ra_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `ra_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Release Advice Items';
