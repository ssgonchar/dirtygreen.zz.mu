DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_steelitem_get_list_by_ids`$$
CREATE PROCEDURE `sp_steelitem_get_list_by_ids`(param_ids VARCHAR(1100), param_revision VARCHAR(12))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_get_list_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            *,
            DATEDIFF(NOW(), in_ddt_date)   AS ddt_days_on_stock, 
            DATEDIFF(NOW(), created_at) AS days_on_stock,
			(SELECT stock_id FROM steelpositions WHERE id = si.steelposition_id) AS stock_id
        FROM steelitems", IF(TRIM(param_revision), CONCAT("_history_", param_revision), ""), " AS si 
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END$$

DELIMITER ;
