delimiter $$

DROP PROCEDURE IF EXISTS `sp_email_mark_as_unread`$$
CREATE PROCEDURE `sp_email_mark_as_unread`(
	IN param_user_id INT,
	IN param_email_id INT
)
BEGIN

    DELETE FROM email_delivered WHERE email_id = param_email_id AND user_id = param_user_id;

END$$

delimiter ;
