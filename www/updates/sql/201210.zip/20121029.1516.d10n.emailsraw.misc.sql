#ALTER TABLE `emails_raw` CHANGE COLUMN `is_parsed` `is_parsed` TINYINT(4) NULL DEFAULT '0' COMMENT 'Параметр \\\"Проанализировано ли\\\" (Нет/ВОбработке/Успех/НеУспех 0/1/2/3 соответственно).';
#ALTER TABLE `emails_raw` ADD INDEX `ix_isparsed_modat_modby` (`is_parsed` ASC, `modified_at` ASC, `modified_by` ASC);



DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_email_create_from_raw`$$
CREATE PROCEDURE `sp_email_create_from_raw`(param_email_raw_id INT, param_type_id INT, param_sender_address VARCHAR(250),
	                                        param_recipient_address VARCHAR(1000), param_cc_address VARCHAR(1000), param_title VARCHAR(1000), 
	                                        param_description TEXT, param_description_html TEXT, param_date_mail TIMESTAMP,
                                            param_mailbox_ids VARCHAR(1000))
sp:
BEGIN

    DECLARE var_email_id INT DEFAULT 0;
    
    IF EXISTS (SELECT * FROM emails WHERE email_raw_id = param_email_raw_id)
    THEN 
        SELECT -1 AS ErrorCode, 'sp_email_create_from_raw' AS ErrorAt;
        LEAVE sp;
    END IF;


    START TRANSACTION;

        INSERT INTO emails
        SET
            email_raw_id        = param_email_raw_id,
            type_id             = param_type_id,
            sender_address      = param_sender_address,
            recipient_address   = param_recipient_address,
            cc_address          = param_cc_address,
            title               = param_title,
            description         = param_description,
            description_html    = param_description_html,
            date_mail           = param_date_mail,
            created_at          = NOW(),
            created_by          = 0;
        
        SET var_email_id = (SELECT MAX(id) AS email_id FROM emails);

    COMMIT;


    IF TRIM(param_mailbox_ids) != ''
    THEN

        SET @var_stmt := CONCAT("
            INSERT IGNORE INTO email_mailboxes(email_id, mailbox_id, created_at, created_by)        
            SELECT 
                ", var_email_id, ", 
                id, 
                NOW(), 
                0                     
            FROM mailboxes 
            WHERE id IN (", param_mailbox_ids, ");");
        
        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;

    END IF;

    
    INSERT IGNORE INTO attachment_objects (`attachment_id`,`type`,`object_alias`,`object_id`,`created_at`,`created_by`)
    SELECT 
        ao.attachment_id,
        ao.type,
        CASE WHEN a.description != '' THEN 'emailhtml' ELSE 'email' END,
        var_email_id,
        NOW(),
        0
    FROM attachment_objects AS ao
    LEFT JOIN attachments AS a ON a.id = ao.attachment_id
    WHERE ao.type = 'file' AND ao.object_alias = 'emailraw' AND ao.object_id = param_email_raw_id;

    
    UPDATE emails_raw
    SET
		is_parsed   = 2,
        #is_parsed   = 1,
        modified_at = NOW(),
        modified_by = 0
    WHERE id = param_email_raw_id;


    
    SELECT var_email_id AS email_id;

END$$



DROP PROCEDURE IF EXISTS `sp_email_raw_get_list_for_parsing`$$
CREATE PROCEDURE `sp_email_raw_get_list_for_parsing`(
	IN param_user_id INT,
	IN param_is_parsed TINYINT,
	IN param_count INT
)
sp:
BEGIN
	DECLARE var_timestamp DATETIME DEFAULT NOW();

	START TRANSACTION;
	
		SET @var_stmt = CONCAT(
			"UPDATE emails_raw
			SET
				is_parsed 	= 1,
				modified_at	= ?,
				modified_by = ?
			WHERE is_parsed = ?
			LIMIT ?
        ;");

		PREPARE stmt FROM @var_stmt;
		SET
			@stmt_var_timestamp  	= var_timestamp,
			@stmt_param_user_id  	= param_user_id,
			@stmt_param_is_parsed  	= param_is_parsed,
			@stmt_param_count		= param_count
		;

		EXECUTE stmt
		USING
			@stmt_var_timestamp,
			@stmt_param_user_id,
			@stmt_param_is_parsed,
			@stmt_param_count
		;

		SELECT *
		FROM emails_raw
		WHERE
				is_parsed = 1
			AND modified_at = var_timestamp
			AND modified_by = param_user_id
		;

	COMMIT;

END$$


DELIMITER ;
