ALTER TABLE `emails_raw` ADD INDEX `ix_emails_raw-udate-message_id-subject` ( `udate` , `message_id` , `subject` ) ;

-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 05.10.2012 1:53:48
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_email_raw_save$$
CREATE PROCEDURE sp_email_raw_save(
    IN param_user_id INT,
    IN param_username VARCHAR(200),
    IN param_mailbox_name VARCHAR(1000),
    IN param_message_num INT(11),
    IN param_message_id VARCHAR(1000),
    IN param_sender_email VARCHAR(1000),
    IN param_recipient_email VARCHAR(1000),
    IN param_cc VARCHAR(1000),
    IN param_reply_to VARCHAR(1000),
    IN param_sender VARCHAR(1000),
    IN param_date DATETIME,
    IN param_date_mail DATETIME,
    IN param_udate INT(11),
    IN param_subject VARCHAR(1000),
    IN param_text_plain TEXT,
    IN param_text_html TEXT,
    IN param_size_plain INT(11),
    IN param_size_html INT(11),
    IN param_recent TINYINT(4),
    IN param_unseen TINYINT(4),
    IN param_flagged TINYINT(4),
    IN param_answered TINYINT(4),
    IN param_deleted TINYINT(4),
    IN param_draft TINYINT(4),
    IN param_is_parsed TINYINT(4),
    IN param_has_attachments TINYINT(4),
    IN param_status_id TINYINT(4)
)
sp:
BEGIN
        
    IF EXISTS (SELECT * FROM emails_raw WHERE udate = param_udate AND message_id = param_message_id AND `subject` = param_subject)
    THEN
    
        SELECT -1 AS ErrorCode, 'email_raw_save' AS ErrorAlias;
        LEAVE sp;        
    
    END IF;
    
    
    START TRANSACTION;
    
        INSERT INTO emails_raw
        SET
            username        = param_username,
            mailbox_name    = param_mailbox_name,
            message_num     = param_message_num,
            message_id      = param_message_id,
            sender_email    = param_sender_email,
            recipient_email = param_recipient_email,
            cc              = param_cc,
            reply_to        = param_reply_to,
            sender          = param_sender,
            `date`          = param_date,
            date_mail       = param_date_mail,
            udate           = param_udate,
            `subject`       = param_subject,
            text_plain      = param_text_plain,
            text_html       = param_text_html,
            size_plain      = param_size_plain,
            size_html       = param_size_html,
            recent          = param_recent,
            unseen          = param_unseen,
            flagged         = param_flagged,
            answered        = param_answered,
            deleted         = param_deleted,
            draft           = param_draft,
            is_parsed       = param_is_parsed,
            has_attachments = param_has_attachments,
            status_id       = param_status_id,
            created_at      = NOW(),
            created_by      = param_user_id,
            modified_at     = NOW(),
            modified_by     = param_user_id
        ;

        SELECT * FROM emails_raw ORDER BY id DESC LIMIT 1;

    COMMIT;

END
$$

DELIMITER ;

