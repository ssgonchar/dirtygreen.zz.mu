DROP TRIGGER IF EXISTS `t_stock_location_insert`;
DELIMITER //
CREATE TRIGGER `t_stock_location_insert` AFTER INSERT ON `stock_locations`
 FOR EACH ROW BEGIN
    INSERT INTO stock_locations_history
    SET
        act             = 'a',
        stock_id        = new.stock_id,
        company_id      = new.company_id,
        created_at      = new.created_at,
        created_by      = new.created_by,
        modified_at     = new.modified_at,
        modified_by     = new.modified_by,
        record_at       = NOW(),
        record_by       = new.created_by;
END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_stock_location_update`;
DELIMITER //
CREATE TRIGGER `t_stock_location_update` AFTER UPDATE ON `stock_locations`
 FOR EACH ROW BEGIN

    IF old.stock_id != new.stock_id OR old.company_id != new.company_id
    THEN
    
        INSERT INTO stock_locations_history
        SET
            act             = 'e',
            stock_id        = new.stock_id,
            company_id      = new.company_id,
            created_at      = new.created_at,
            created_by      = new.created_by,
            modified_at     = new.modified_at,
            modified_by     = new.modified_by,
            record_at       = NOW(),
            record_by       = new.modified_by;

    END IF;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_stock_location_delete`;
DELIMITER //
CREATE TRIGGER `t_stock_location_delete` BEFORE DELETE ON `stock_locations`
 FOR EACH ROW BEGIN

    INSERT INTO stock_locations_history
    SET
        act             = 'd',
        stock_id        = old.stock_id,
        company_id      = old.company_id,
        created_at      = old.created_at,
        created_by      = old.created_by,
        modified_at     = old.modified_at,
        modified_by     = old.modified_by,
        record_at       = NOW(),
        record_by       = old.modified_by;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelposition_items_insert`;
DELIMITER //
CREATE TRIGGER `t_steelposition_items_insert` AFTER INSERT ON `steelposition_items`
 FOR EACH ROW BEGIN

    INSERT INTO steelposition_items_history
    SET
        act                 = 'a',
        steelposition_id    = new.steelposition_id,
        steelitem_id        = new.steelitem_id,
        created_at          = new.created_at,
        created_by          = new.created_by,
        modified_at         = new.modified_at,
        modified_by         = new.modified_by,
        record_at           = new.created_at,
        record_by           = new.created_by;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelposition_items_delete`;
DELIMITER //
CREATE TRIGGER `t_steelposition_items_delete` BEFORE DELETE ON `steelposition_items`
 FOR EACH ROW BEGIN

    INSERT INTO steelposition_items_history
    SET
        act                 = 'd',
        steelposition_id    = old.steelposition_id,
        steelitem_id        = old.steelitem_id,
        created_at          = old.created_at,
        created_by          = old.created_by,
        modified_at         = old.modified_at,
        modified_by         = old.modified_by,
        record_at           = old.modified_at,
        record_by           = old.modified_by;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_insert`;
DELIMITER //
CREATE TRIGGER `t_steelitem_insert` AFTER INSERT ON `steelitems`
 FOR EACH ROW BEGIN

    IF @ENABLE_TRIGGERS = TRUE
    THEN
    
        INSERT INTO steelitems_history
        SET
            steelitem_id            = new.id,
            guid                    = new.guid,
			alias					= new.alias,
            steelposition_id        = new.steelposition_id,
            product_id              = new.product_id,
            biz_id                  = new.biz_id,
            stockholder_id          = new.stockholder_id,
            location_id             = new.location_id,
            dimension_unit          = new.dimension_unit,
            weight_unit             = new.weight_unit,
            currency                = new.currency,
            parent_id               = new.parent_id,
            rel                     = new.rel,
            steelgrade_id           = new.steelgrade_id,
            thickness               = new.thickness,
            thickness_mm            = new.thickness_mm,
            thickness_measured      = new.thickness_measured,
            width                   = new.width,
            width_mm                = new.width_mm,
            width_measured          = new.width_measured,
            width_max               = new.width_max,
            `length`                = new.`length`,
            length_mm               = new.length_mm,
            length_measured         = new.length_measured,
            length_max              = new.length_max,
            unitweight              = new.unitweight,
            unitweight_ton          = new.unitweight_ton,
            price                   = new.price,
            `value`                 = new.`value`,
            supplier_id             = new.supplier_id,
            supplier_invoice_no     = new.supplier_invoice_no,
            supplier_invoice_date   = new.supplier_invoice_date,
            purchase_price          = new.purchase_price,
            purchase_value          = new.purchase_value,
			purchase_currency		= new.purchase_currency,
            in_ddt_number           = new.in_ddt_number,
            in_ddt_date             = new.in_ddt_date,
			in_ddt_company_id      	= new.in_ddt_company_id,
            ddt_number              = new.ddt_number,
            ddt_date                = new.ddt_date,
			ddt_company_id      	= new.ddt_company_id,
            deliverytime_id         = new.deliverytime_id,
            notes                   = new.notes,
            internal_notes          = new.internal_notes,
            owner_id                = new.owner_id,
            status_id               = new.status_id,
            mill                    = new.mill,
            system                  = new.system,
            unitweight_measured     = new.unitweight_measured,
            unitweight_weighed      = new.unitweight_weighed,
            current_cost            = new.current_cost,
            pl                      = new.pl,
            load_ready              = new.load_ready,
			is_from_order           = new.is_from_order,
			order_id                = new.order_id,
			is_available            = new.is_available, 
			is_virtual              = new.is_virtual,            
            is_deleted              = new.is_deleted,
			is_conflicted           = new.is_conflicted,
			is_locked           	= new.is_locked,
            tech_action             = 'add',
            tech_object_alias       = new.tech_object_alias,
            tech_object_id          = new.tech_object_id,
            tech_data               = new.tech_data,
            created_at              = new.created_at,
            created_by              = new.created_by,
            modified_at             = new.modified_at,
            modified_by             = new.modified_by,
            record_at               = new.created_at,
            record_by               = new.created_by;

    END IF;
    
END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_update`;
DELIMITER //
CREATE TRIGGER `t_steelitem_update` AFTER UPDATE ON `steelitems`
 FOR EACH ROW BEGIN

    IF  @ENABLE_TRIGGERS = TRUE AND
    (
        old.guid                       != new.guid
		OR old.alias                   != new.alias
        OR old.steelposition_id        != new.steelposition_id
        OR old.product_id              != new.product_id
        OR old.biz_id                  != new.biz_id
        OR old.stockholder_id          != new.stockholder_id
        OR old.location_id             != new.location_id
        OR old.dimension_unit          != new.dimension_unit
        OR old.weight_unit             != new.weight_unit
        OR old.currency                != new.currency
        OR old.parent_id               != new.parent_id
        OR old.rel                     != new.rel
        OR old.steelgrade_id           != new.steelgrade_id
        OR old.thickness               != new.thickness
        OR old.thickness_mm            != new.thickness_mm
        OR old.thickness_measured      != new.thickness_measured
        OR old.width                   != new.width
        OR old.width_mm                != new.width_mm
        OR old.width_measured          != new.width_measured
        OR old.width_max               != new.width_max
        OR old.`length`                != new.`length`
        OR old.length_mm               != new.length_mm
        OR old.length_measured         != new.length_measured
        OR old.length_max              != new.length_max
        OR old.unitweight              != new.unitweight
        OR old.unitweight_ton          != new.unitweight_ton
        OR old.price                   != new.price
        OR old.`value`                 != new.`value`
        OR old.supplier_id             != new.supplier_id
        OR old.supplier_invoice_no     != new.supplier_invoice_no
        OR old.supplier_invoice_date   != new.supplier_invoice_date
        OR old.purchase_price          != new.purchase_price
        OR old.purchase_value          != new.purchase_value
		OR old.purchase_currency       != new.purchase_currency
        OR old.in_ddt_number           != new.in_ddt_number
        OR old.in_ddt_date             != new.in_ddt_date
		OR old.in_ddt_company_id       != new.in_ddt_company_id
        OR old.ddt_number              != new.ddt_number
        OR old.ddt_date                != new.ddt_date
		OR old.ddt_company_id          != new.ddt_company_id
        OR old.deliverytime_id         != new.deliverytime_id
        OR old.notes                   != new.notes
        OR old.internal_notes          != new.internal_notes
        OR old.owner_id                != new.owner_id
        OR old.status_id               != new.status_id
        OR old.mill                    != new.mill
        OR old.system                  != new.system
        OR old.unitweight_measured     != new.unitweight_measured
        OR old.unitweight_weighed      != new.unitweight_weighed
        OR old.current_cost            != new.current_cost
        OR old.pl                      != new.pl
        OR old.load_ready              != new.load_ready
        OR old.order_id                != new.order_id
        OR old.is_available            != new.is_available
		OR old.is_virtual              != new.is_virtual        
        OR old.is_deleted              != new.is_deleted
		OR old.is_conflicted           != new.is_conflicted
		OR old.is_locked           	   != new.is_locked
        OR old.tech_action             != new.tech_action
    )
    THEN

        INSERT INTO steelitems_history
        SET
            steelitem_id            = new.id,
            guid                    = new.guid,
			alias                   = new.alias,
            steelposition_id        = new.steelposition_id,
            product_id              = new.product_id,
            biz_id                  = new.biz_id,
            stockholder_id          = new.stockholder_id,
            location_id             = new.location_id,
            dimension_unit          = new.dimension_unit,
            weight_unit             = new.weight_unit,
            currency                = new.currency,
            parent_id               = new.parent_id,
            rel                     = new.rel,
            steelgrade_id           = new.steelgrade_id,
            thickness               = new.thickness,
            thickness_mm            = new.thickness_mm,
            thickness_measured      = new.thickness_measured,
            width                   = new.width,
            width_mm                = new.width_mm,
            width_measured          = new.width_measured,
            width_max               = new.width_max,
            `length`                = new.`length`,
            length_mm               = new.length_mm,
            length_measured         = new.length_measured,
            length_max              = new.length_max,
            unitweight              = new.unitweight,
            unitweight_ton          = new.unitweight_ton,
            price                   = new.price,
            `value`                 = new.`value`,
            supplier_id             = new.supplier_id,
            supplier_invoice_no     = new.supplier_invoice_no,
            supplier_invoice_date   = new.supplier_invoice_date,
            purchase_price          = new.purchase_price,
            purchase_value          = new.purchase_value,
			purchase_currency       = new.purchase_currency,
            in_ddt_number           = new.in_ddt_number,
            in_ddt_date             = new.in_ddt_date,
			in_ddt_company_id       = new.in_ddt_company_id,
            ddt_number              = new.ddt_number,
            ddt_date                = new.ddt_date,
			ddt_company_id       	= new.ddt_company_id,
            deliverytime_id         = new.deliverytime_id,
            notes                   = new.notes,
            internal_notes          = new.internal_notes,
            owner_id                = new.owner_id,
            status_id               = new.status_id,
            mill                    = new.mill,
            system                  = new.system,
            unitweight_measured     = new.unitweight_measured,
            unitweight_weighed      = new.unitweight_weighed,
            current_cost            = new.current_cost,
            pl                      = new.pl,
            load_ready              = new.load_ready,
            is_from_order           = new.is_from_order,
            order_id                = new.order_id,
            is_available            = new.is_available, 
            is_virtual              = new.is_virtual,
            is_deleted              = new.is_deleted,
			is_conflicted          	= new.is_conflicted,
			is_locked          		= new.is_locked,
            tech_action             = CASE 
                                        WHEN old.is_deleted = 0 AND new.is_deleted = 1 THEN 'delete' 
                                        WHEN old.order_id = 0 AND new.order_id > 0 THEN 'toorder' 
                                        WHEN old.order_id > 0 AND new.order_id = 0 THEN 'fromorder' 
                                        WHEN old.steelposition_id != new.steelposition_id THEN 'move' 
                                        ELSE IF(new.tech_action = '', 'edit', new.tech_action) END,
            tech_object_alias       = new.tech_object_alias,
            tech_object_id          = new.tech_object_id,
            tech_data               = new.tech_data,
            created_at              = new.created_at,
            created_by              = new.created_by,
            modified_at             = new.modified_at,
            modified_by             = new.modified_by,
            record_at               = new.modified_at,
            record_by               = new.modified_by;

     END IF;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_delete`;
DELIMITER //
CREATE TRIGGER `t_steelitem_delete` BEFORE DELETE ON `steelitems`
 FOR EACH ROW BEGIN

    IF @ENABLE_TRIGGERS = TRUE
    THEN
    
        INSERT INTO steelitems_history
        SET
            steelitem_id            = old.id,
            guid                    = old.guid,
			alias                   = old.alias,
            steelposition_id        = old.steelposition_id,
            product_id              = old.product_id,
            biz_id                  = old.biz_id,
            stockholder_id          = old.stockholder_id,
            location_id             = old.location_id,
            dimension_unit          = old.dimension_unit,
            weight_unit             = old.weight_unit,
            currency                = old.currency,
            parent_id               = old.parent_id,
            rel                     = old.rel,
            steelgrade_id           = old.steelgrade_id,
            thickness               = old.thickness,
            thickness_mm            = old.thickness_mm,
            thickness_measured      = old.thickness_measured,
            width                   = old.width,
            width_mm                = old.width_mm,
            width_measured          = old.width_measured,
            width_max               = old.width_max,
            `length`                = old.`length`,
            length_mm               = old.length_mm,
            length_measured         = old.length_measured,
            length_max              = old.length_max,
            unitweight              = old.unitweight,
            unitweight_ton          = old.unitweight_ton,
            price                   = old.price,
            `value`                 = old.`value`,
            supplier_id             = old.supplier_id,
            supplier_invoice_no     = old.supplier_invoice_no,
            supplier_invoice_date   = old.supplier_invoice_date,
            purchase_price          = old.purchase_price,
            purchase_value          = old.purchase_value,
			purchase_currency       = old.purchase_currency,
            in_ddt_number           = old.in_ddt_number,
            in_ddt_date             = old.in_ddt_date,
			in_ddt_company_id       = old.in_ddt_company_id,
            ddt_number              = old.ddt_number,
            ddt_date                = old.ddt_date,
			ddt_company_id       	= old.ddt_company_id,
            deliverytime_id         = old.deliverytime_id,
            notes                   = old.notes,
            internal_notes          = old.internal_notes,
            owner_id                = old.owner_id,
            status_id               = old.status_id,
            mill                    = old.mill,
            system                  = old.system,
            unitweight_measured     = old.unitweight_measured,
            unitweight_weighed      = old.unitweight_weighed,
            current_cost            = old.current_cost,
            pl                      = old.pl,
            load_ready              = old.load_ready,
            is_from_order           = old.is_from_order,        
            order_id                = old.order_id,        
            is_available            = old.is_available,             
			is_virtual              = old.is_virtual,
            is_deleted              = old.is_deleted,
			is_conflicted           = old.is_conflicted,
			is_locked           	= old.is_locked,
            tech_action             = 'delete',
            tech_object_alias       = old.tech_object_alias,
            tech_object_id          = old.tech_object_id,
            tech_data               = old.tech_data,
            created_at              = old.created_at,
            created_by              = old.created_by,
            modified_at             = old.modified_at,
            modified_by             = old.modified_by,
            record_at               = old.modified_at,
            record_by               = old.modified_by;

    END IF; 
       
END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelposition_insert`;
DELIMITER //
CREATE TRIGGER `t_steelposition_insert` AFTER INSERT ON `steelpositions`
 FOR EACH ROW BEGIN

    IF @ENABLE_TRIGGERS = TRUE
    THEN

        INSERT INTO steelpositions_history
        SET
            steelposition_id    = new.id,
            stock_id            = new.stock_id,
            product_id          = new.product_id,
            biz_id              = new.biz_id,
            dimension_unit      = new.dimension_unit,
            weight_unit         = new.weight_unit,
            currency            = new.currency,
            steelgrade_id       = new.steelgrade_id,
            thickness           = new.thickness,
            thickness_mm        = new.thickness_mm,
            width               = new.width,
            width_mm            = new.width_mm,
            `length`            = new.`length`,
            length_mm           = new.length_mm,
            unitweight          = new.unitweight,
            unitweight_ton      = new.unitweight_ton,
            qtty                = new.qtty,
            weight              = new.weight,
            weight_ton          = new.weight_ton,
            price               = new.price,
            `value`             = new.`value`,
            deliverytime_id     = new.deliverytime_id,
            notes               = new.notes,
            internal_notes      = new.internal_notes,
            is_from_order       = new.is_from_order,
            is_deleted          = new.is_deleted,
            is_reserved         = new.is_reserved,
			is_locked         	= new.is_locked,
            tech_action         = 'add',
            tech_object_alias   = new.tech_object_alias,
            tech_object_id      = new.tech_object_id,
            tech_data           = new.tech_data,
            created_at          = new.created_at,
            created_by          = new.created_by,
            modified_at         = new.modified_at,
            modified_by         = new.modified_by,
            record_at           = new.created_at,
            record_by           = new.created_by;

    END IF;        
END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelposition_update`;
DELIMITER //
CREATE TRIGGER `t_steelposition_update` AFTER UPDATE ON `steelpositions`
 FOR EACH ROW BEGIN

    IF  @ENABLE_TRIGGERS = TRUE AND
    (
        old.stock_id            != new.stock_id
        OR old.product_id       != new.product_id
        OR old.biz_id           != new.biz_id
        OR old.dimension_unit   != new.dimension_unit
        OR old.weight_unit      != new.weight_unit
        OR old.currency         != new.currency
        OR old.steelgrade_id    != new.steelgrade_id
        OR old.thickness        != new.thickness
        OR old.width            != new.width
        OR old.`length`         != new.`length`
        OR old.unitweight       != new.unitweight
        OR old.qtty             != new.qtty
        OR old.weight           != new.weight
        OR old.price            != new.price
        OR old.`value`          != new.`value`
        OR old.deliverytime_id  != new.deliverytime_id
        OR old.notes            != new.notes
        OR old.internal_notes   != new.internal_notes
        OR old.is_deleted       != new.is_deleted
		OR old.is_reserved      != new.is_reserved
		OR old.is_locked      	!= new.is_locked
        OR old.tech_action      != new.tech_action
    )
    THEN
    
        INSERT INTO steelpositions_history
        SET
            steelposition_id    = new.id,
            stock_id            = new.stock_id,
            product_id          = new.product_id,
            biz_id              = new.biz_id,
            dimension_unit      = new.dimension_unit,
            weight_unit         = new.weight_unit,
            currency            = new.currency,
            steelgrade_id       = new.steelgrade_id,
            thickness           = new.thickness,
            thickness_mm        = new.thickness_mm,
            width               = new.width,
            width_mm            = new.width_mm,
            `length`            = new.`length`,
            length_mm           = new.length_mm,
            unitweight          = new.unitweight,
            unitweight_ton      = new.unitweight_ton,
            qtty                = new.qtty,
            weight              = new.weight,
            weight_ton          = new.weight_ton,
            price               = new.price,
            `value`             = new.`value`,
            deliverytime_id     = new.deliverytime_id,
            notes               = new.notes,
            internal_notes      = new.internal_notes,
            is_from_order       = new.is_from_order,
            is_deleted          = new.is_deleted,
			is_reserved         = new.is_reserved,
			is_locked         	= new.is_locked,
            tech_action         = CASE WHEN old.is_deleted = 0 AND new.is_deleted = 1 THEN 'delete' ELSE IF(new.tech_action = '', 'edit', old.tech_action) END,
            tech_object_alias   = new.tech_object_alias,
            tech_object_id      = new.tech_object_id,
            tech_data           = new.tech_data,
            created_at          = new.created_at,
            created_by          = new.created_by,
            modified_at         = new.modified_at,
            modified_by         = new.modified_by,
            record_at           = new.modified_at,
            record_by           = new.modified_by;

    END IF;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelposition_delete`;
DELIMITER //
CREATE TRIGGER `t_steelposition_delete` BEFORE DELETE ON `steelpositions`
 FOR EACH ROW BEGIN

    IF @ENABLE_TRIGGERS = TRUE
    THEN

        INSERT INTO steelpositions_history
        SET
            steelposition_id    = old.id,
            stock_id            = old.stock_id,
            product_id          = old.product_id,
            biz_id              = old.biz_id,
            dimension_unit      = old.dimension_unit,
            weight_unit         = old.weight_unit,
            currency            = old.currency,
            steelgrade_id       = old.steelgrade_id,
            thickness           = old.thickness,
            thickness_mm        = old.thickness_mm,
            width               = old.width,
            width_mm            = old.width_mm,
            `length`            = old.`length`,
            length_mm           = old.length_mm,
            unitweight          = old.unitweight,
            unitweight_ton      = old.unitweight_ton,
            qtty                = old.qtty,
            weight              = old.weight,
            weight_ton          = old.weight_ton,
            price               = old.price,
            `value`             = old.`value`,
            deliverytime_id     = old.deliverytime_id,
            notes               = old.notes,
            internal_notes      = old.internal_notes,
            is_from_order       = old.is_from_order,
            is_deleted          = old.is_deleted,
			is_reserved         = old.is_reserved,
			is_locked         	= old.is_locked,
            tech_action         = 'delete',
            tech_object_alias   = old.tech_object_alias,
            tech_object_id      = old.tech_object_id,
            tech_data           = old.tech_data,
            created_at          = old.created_at,
            created_by          = old.created_by,
            modified_at         = old.modified_at,
            modified_by         = old.modified_by,
            record_at           = old.modified_at,
            record_by           = old.modified_by;
    
    END IF;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_properties_insert`;
DELIMITER //
CREATE TRIGGER `t_steelitem_properties_insert` AFTER INSERT ON `steelitem_properties`
 FOR EACH ROW BEGIN

    IF @ENABLE_TRIGGERS = TRUE
    THEN

        INSERT INTO steelitem_properties_history
        SET
            act                         = 'a',
            item_id                     = new.item_id,
            heat_lot                    = new.heat_lot,
            c                           = new.c,
            si                          = new.si,
            mn                          = new.mn,
            p                           = new.p,
            s                           = new.s,
            cr                          = new.cr,
            ni                          = new.ni,
            cu                          = new.cu,
            al                          = new.al,
            mo                          = new.mo,
            nb                          = new.nb,
            v                           = new.v,
            n                           = new.n,
            ti                          = new.ti,
            sn                          = new.sn,
            b                           = new.b,
            ceq                         = new.ceq,
            tensile_sample_direction    = new.tensile_sample_direction,
            tensile_strength            = new.tensile_strength,
            yeild_point                 = new.yeild_point,
            elongation                  = new.elongation,
            reduction_of_area           = new.reduction_of_area,
            test_temp                   = new.test_temp,
            impact_strength             = new.impact_strength,
            hardness                    = new.hardness,
            ust                         = new.ust,
            sample_direction            = new.sample_direction,
            stress_relieving_temp       = new.stress_relieving_temp,
            heating_rate_per_hour       = new.heating_rate_per_hour,
            holding_time                = new.holding_time,
            cooling_down_rate           = new.cooling_down_rate,
            `condition`                 = new.`condition`,
            normalizing_temp            = new.normalizing_temp,
            created_at                  = new.created_at,
            created_by                  = new.created_by,
            modified_at                 = new.modified_at,
            modified_by                 = new.modified_by,
            record_at                   = new.created_at,
            record_by                   = new.created_by;
    END IF;    

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_properties_update`;
DELIMITER //
CREATE TRIGGER `t_steelitem_properties_update` AFTER UPDATE ON `steelitem_properties`
 FOR EACH ROW BEGIN

    IF  @ENABLE_TRIGGERS = TRUE 
    THEN
        
        IF  old.heat_lot                    != new.heat_lot
            OR old.c                        != new.c
            OR old.si                       != new.si
            OR old.mn                       != new.mn
            OR old.p                        != new.p
            OR old.s                        != new.s
            OR old.cr                       != new.cr
            OR old.ni                       != new.ni
            OR old.cu                       != new.cu
            OR old.al                       != new.al
            OR old.mo                       != new.mo
            OR old.nb                       != new.nb
            OR old.v                        != new.v
            OR old.n                        != new.n
            OR old.ti                       != new.ti
            OR old.sn                       != new.sn
            OR old.b                        != new.b
            OR old.ceq                      != new.ceq
            OR old.tensile_sample_direction != new.tensile_sample_direction
            OR old.tensile_strength         != new.tensile_strength
            OR old.yeild_point              != new.yeild_point
            OR old.elongation               != new.elongation
            OR old.reduction_of_area        != new.reduction_of_area
            OR old.test_temp                != new.test_temp
            OR old.impact_strength          != new.impact_strength
            OR old.hardness                 != new.hardness
            OR old.ust                      != new.ust
            OR old.sample_direction         != new.sample_direction
            OR old.stress_relieving_temp    != new.stress_relieving_temp
            OR old.heating_rate_per_hour    != new.heating_rate_per_hour
            OR old.holding_time             != new.holding_time
            OR old.cooling_down_rate        != new.cooling_down_rate
            OR old.`condition`              != new.`condition`
            OR old.normalizing_temp         != new.normalizing_temp
            OR old.tech_action              != new.tech_action
    
        THEN
    
            INSERT INTO steelitem_properties_history
            SET
                act                         = 'e',
                item_id                     = new.item_id,
                heat_lot                    = new.heat_lot,
                c                           = new.c,
                si                          = new.si,
                mn                          = new.mn,
                p                           = new.p,
                s                           = new.s,
                cr                          = new.cr,
                ni                          = new.ni,
                cu                          = new.cu,
                al                          = new.al,
                mo                          = new.mo,
                nb                          = new.nb,
                v                           = new.v,
                n                           = new.n,
                ti                          = new.ti,
                sn                          = new.sn,
                b                           = new.b,
                ceq                         = new.ceq,
                tensile_sample_direction    = new.tensile_sample_direction,
                tensile_strength            = new.tensile_strength,
                yeild_point                 = new.yeild_point,
                elongation                  = new.elongation,
                reduction_of_area           = new.reduction_of_area,
                test_temp                   = new.test_temp,
                impact_strength             = new.impact_strength,
                hardness                    = new.hardness,
                ust                         = new.ust,
                sample_direction            = new.sample_direction,
                stress_relieving_temp       = new.stress_relieving_temp,
                heating_rate_per_hour       = new.heating_rate_per_hour,
                holding_time                = new.holding_time,
                cooling_down_rate           = new.cooling_down_rate,
                `condition`                 = new.`condition`,
                normalizing_temp            = new.normalizing_temp,
                created_at                  = new.created_at,
                created_by                  = new.created_by,
                modified_at                 = new.modified_at,
                modified_by                 = new.modified_by,
                record_at                   = new.modified_at,
                record_by                   = new.modified_by;

        END IF;
        
    END IF;

END
//
DELIMITER ;

DROP TRIGGER IF EXISTS `t_steelitem_properties_delete`;
DELIMITER //
CREATE TRIGGER `t_steelitem_properties_delete` BEFORE DELETE ON `steelitem_properties`
 FOR EACH ROW BEGIN

    INSERT INTO steelitem_properties_history
    SET
        act                         = 'd',
        item_id                     = old.item_id,
        heat_lot                    = old.heat_lot,
        c                           = old.c,
        si                          = old.si,
        mn                          = old.mn,
        p                           = old.p,
        s                           = old.s,
        cr                          = old.cr,
        ni                          = old.ni,
        cu                          = old.cu,
        al                          = old.al,
        mo                          = old.mo,
        nb                          = old.nb,
        v                           = old.v,
        n                           = old.n,
        ti                          = old.ti,
        sn                          = old.sn,
        b                           = old.b,
        ceq                         = old.ceq,
        tensile_sample_direction    = old.tensile_sample_direction,
        tensile_strength            = old.tensile_strength,
        yeild_point                 = old.yeild_point,
        elongation                  = old.elongation,
        reduction_of_area           = old.reduction_of_area,
        test_temp                   = old.test_temp,
        impact_strength             = old.impact_strength,
        hardness                    = old.hardness,
        ust                         = old.ust,
        sample_direction            = old.sample_direction,
        stress_relieving_temp       = old.stress_relieving_temp,
        heating_rate_per_hour       = old.heating_rate_per_hour,
        holding_time                = old.holding_time,
        cooling_down_rate           = old.cooling_down_rate,
        `condition`                 = old.`condition`,
        normalizing_temp            = old.normalizing_temp,
        created_at                  = old.created_at,
        created_by                  = old.created_by,
        modified_at                 = old.modified_at,
        modified_by                 = old.modified_by,
        record_at                   = old.modified_at,
        record_by                   = old.modified_by;

END
//
DELIMITER ;
