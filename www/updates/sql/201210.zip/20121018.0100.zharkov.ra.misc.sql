ALTER TABLE `ra_items` CHANGE `item_id` `steelitem_id` INT( 11 ) NULL DEFAULT NULL ;
ALTER TABLE `ra` ADD `ddt_instructions` TEXT NOT NULL AFTER `ddt_date`;
ALTER TABLE `ra` ADD `attachment_id` INT NOT NULL AFTER `ddt_instructions`;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_set_status$$
CREATE PROCEDURE sp_steelitem_set_status(param_user_id INT, param_item_id INT, param_status_id INT)
sp:
BEGIN

    DECLARE var_order_id        INT DEFAULT 0;
    DECLARE ITEM_STATUS_ORDERED INT DEFAULT 3;
    
    
    SET var_order_id = (SELECT order_id FROM steelitems WHERE id = param_item_id);

    IF (var_order_id > 0 AND param_status_id < ITEM_STATUS_ORDERED)
    OR (var_order_id = 0 AND param_status_id >= ITEM_STATUS_ORDERED)
    THEN
        SELECT -1 AS ErrorCode, 'sp_item_set_status' AS ErrorAt;
        LEAVE sp;
    END IF;


    SELECT * FROM steelitems WHERE id = param_item_id;

    
    IF var_order_id > 0
    THEN

        CALL sp_order_update_item_status(param_user_id, var_order_id, param_item_id, param_status_id);

    ELSE

        UPDATE steelitems
        SET
            status_id   = param_status_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_item_id;

    END IF;

END
$$


DROP PROCEDURE IF EXISTS sp_ra_get_items$$
CREATE PROCEDURE sp_ra_get_items(param_user_id INT, param_ra_id INT)
BEGIN

    SELECT 
        *
    FROM ra_items
    WHERE ra_id = param_ra_id;

END
$$

DROP PROCEDURE IF EXISTS sp_ra_save$$
CREATE PROCEDURE sp_ra_save(
	IN param_user_id INT,
	IN param_id INT,
	IN param_stockholder_id INT,
	IN param_company_id INT,
	IN param_truck_number VARCHAR(50),
	IN param_destination VARCHAR(200),
	IN param_loading_date VARCHAR(200),
	IN param_marking TEXT,
	IN param_dunnaging TEXT,
	IN param_status_id TINYINT,
	IN param_max_weight DECIMAL(10,4),
	IN param_weighed_weight DECIMAL(10,4),
	IN param_ddt_number VARCHAR(50),
	IN param_ddt_date TIMESTAMP,
    IN param_ddt_instructions TEXT
)
sp:
BEGIN
	IF param_id = 0
	THEN
		START TRANSACTION;
			INSERT INTO ra
			SET
				`number`			= IFNULL((SELECT MAX(ra2.`number`)+1 FROM ra AS ra2 LIMIT 1), 1),
				`stockholder_id`	= param_stockholder_id,
				`company_id`		= param_company_id,
				`truck_number`		= param_truck_number,
				`destination`		= param_destination,
				`loading_date`		= param_loading_date,
				`marking`			= param_marking,
				`dunnaging`			= param_dunnaging,
				`status_id`			= param_status_id,
				`max_weight`		= param_max_weight,
				`weighed_weight`	= param_weighed_weight,
				`ddt_number`		= param_ddt_number,
				`ddt_date`			= param_ddt_date,
                ddt_instructions    = param_ddt_instructions,
				attachment_id		= 0,
				`created_at`		= NOW(),
				`created_by`		= param_user_id,
				`modified_at`		= NOW(),
				`modified_by`		= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra WHERE `created_by` = param_user_id);
		COMMIT;
	ELSE
		UPDATE ra
		SET
			`company_id`		= param_company_id,
			`truck_number`		= param_truck_number,
			`destination`		= param_destination,
			`loading_date`		= param_loading_date,
			`marking`			= param_marking,
			`dunnaging`			= param_dunnaging,
			`max_weight`		= param_max_weight,
			`weighed_weight`	= param_weighed_weight,
			`ddt_number`		= param_ddt_number,
			`ddt_date`			= param_ddt_date,
            ddt_instructions    = param_ddt_instructions,
			`modified_at`		= NOW(),
			`modified_by`		= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ra_id;
END
$$

DROP PROCEDURE IF EXISTS sp_ra_item_save$$
CREATE PROCEDURE sp_ra_item_save(IN param_user_id INT, IN param_id INT, IN param_parent_id INT, IN param_ra_id INT, IN param_item_id INT)
sp:
BEGIN
	IF param_id = 0
	THEN
		START TRANSACTION;
			INSERT INTO ra_items
			SET
				`parent_id`		= param_parent_id,
				`ra_id`			= param_ra_id,
				`steelitem_id`	= param_item_id,
				`created_at`	= NOW(),
				`created_by`	= param_user_id,
				`modified_at`	= NOW(),
				`modified_by`	= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra_items WHERE `created_by` = param_user_id);
		COMMIT;
	ELSE
		UPDATE ra_items
		SET
			`parent_id`		= param_parent_id,
			`ra_id`			= param_ra_id,
			`steelitem_id`	= param_item_id,
			`modified_at`	= NOW(),
			`modified_by`	= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ra_item_id;
END
$$

DROP PROCEDURE IF EXISTS sp_ra_remove_item$$
CREATE PROCEDURE sp_ra_remove_item(param_user_id INT, param_ra_id INT, param_item_id INT)
sp:
BEGIN

    IF NOT EXISTS (SELECT * FROM ra_items WHERE id = param_item_id AND ra_id = param_ra_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_ra_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

    DELETE FROM ra_items WHERE id = param_item_id;
	
	SELECT param_item_id AS id;
    
END
$$


DELIMITER ;

