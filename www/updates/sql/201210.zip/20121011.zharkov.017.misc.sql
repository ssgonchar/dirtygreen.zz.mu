ALTER TABLE `emails` ADD `signature2` VARCHAR( 250 ) NULL ;

-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 11.10.2012 13:51:45
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_email_save$$
CREATE PROCEDURE sp_email_save(
	IN param_user_id INT,
	IN param_id INT,
	IN param_object_alias CHAR(20),
	IN param_object_id INT,
	IN param_sender_address VARCHAR(250),
	IN param_recipient_address VARCHAR(1000),
	IN param_cc_address VARCHAR(1000), 
	IN param_to VARCHAR(250),
	IN param_attention VARCHAR(250),
	IN param_subject VARCHAR(250),
	IN param_our_ref VARCHAR(250),
	IN param_your_ref VARCHAR(250),
	IN param_title VARCHAR(1000), 
	IN param_description TEXT,
	IN param_signature VARCHAR(250),
	IN param_approve_by INT(11),
	IN param_approve_deadline TIMESTAMP,
	IN param_doc_type TINYINT(4),
	IN param_seek_response TIMESTAMP,
    param_mailbox_id INT,
    param_parent_id INT,
    param_signature2 VARCHAR(250)
)
BEGIN

    DECLARE var_number          INT DEFAULT 0;
    DECLARE EMAIL_TYPE_DRAFT    INT DEFAULT 3;

    IF param_id > 0
    THEN
        
        UPDATE emails
        SET
            sender_address      = param_sender_address,
            recipient_address   = param_recipient_address,
            cc_address          = param_cc_address,
            `to`                = param_to,
            attention           = param_attention,
            `subject`           = param_subject,
            our_ref             = param_our_ref,
            your_ref            = param_your_ref,
            title               = param_title,
            description         = param_description,
            signature           = param_signature,
            signature2          = param_signature2,
            modified_at         = NOW(),
            modified_by         = param_user_id,
            date_mail           = NOW(),
			approve_by			= param_approve_by,
			approve_deadline	= param_approve_deadline,
			doc_type			= param_doc_type,
			seek_response		= param_seek_response
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            SET var_number = IFNULL((SELECT MAX(number) FROM emails WHERE created_by = param_user_id), 0) + 1;
            
            INSERT INTO emails
            SET                
                email_raw_id        = 0,
                type_id             = EMAIL_TYPE_DRAFT,
                object_alias        = param_object_alias,
                object_id           = param_object_id,
                sender_address      = param_sender_address,
                recipient_address   = param_recipient_address,
                cc_address          = param_cc_address,
                `to`                = param_to,
                attention           = param_attention,
                `subject`           = param_subject,
                our_ref             = param_our_ref,
                your_ref            = param_your_ref,
                title               = param_title,
                description         = param_description,
                signature           = param_signature,
                signature2          = param_signature2,
                number              = var_number,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id,
                date_mail           = NOW(),
				approve_by			= param_approve_by,
				approve_deadline	= param_approve_deadline,
				doc_type			= param_doc_type,
				seek_response		= param_seek_response,
                parent_id           = param_parent_id
			;

            SET param_id = (SELECT MAX(id) FROM emails WHERE created_by = param_user_id);

        COMMIT;

    END IF;

    
    DELETE FROM email_objects 
    WHERE email_id = param_id;

    DELETE FROM email_mailboxes
    WHERE email_id = param_id;

    INSERT INTO email_mailboxes
    SET
        email_id = param_id,
        mailbox_id  = param_mailbox_id,
        created_at  = NOW(),
        created_by  = param_user_id;

    
    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_biz_get_list_by_company$$
CREATE PROCEDURE sp_biz_get_list_by_company(param_company_id INT, param_role CHAR(5))
BEGIN

    SELECT DISTINCT
        bizes.id AS biz_id
    FROM bizes
    JOIN biz_companies ON biz_companies.biz_id = bizes.id
    WHERE biz_companies.company_id = param_company_id
    AND biz_companies.role = param_role
    ORDER BY bizes.number, bizes.suffix;

END
$$

DELIMITER ;

