DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_ra_item_get_by_id`$$
CREATE PROCEDURE `sp_ra_item_get_by_id`(IN param_id INT)
BEGIN

    SELECT
        ra_i.*,

		IFNULL((
			SELECT COUNT(ra_iv.id)
			FROM ra_items AS ra_iv
			WHERE ra_iv.parent_id = ra_i.id
		), 0) AS children_count
    FROM ra_items AS ra_i
    WHERE
		ra_i.id = param_id
	;

END$$



DROP PROCEDURE IF EXISTS `sp_ra_item_get_list_by_ids`$$
CREATE PROCEDURE `sp_ra_item_get_list_by_ids`(IN param_ids VARCHAR(1100))
sp:
BEGIN

    IF param_ids = '' 
    THEN
        LEAVE sp;
    END IF;
    
    SET @var_stmt = CONCAT(  
        "SELECT 
            ra_i.*,

			IFNULL((
				SELECT COUNT(ra_iv.id)
				FROM ra_items AS ra_iv
				WHERE ra_iv.parent_id = ra_i.id
			), 0) AS children_count
        FROM ra_items AS ra_i
        WHERE
			ra_i.id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END$$

DELIMITER ;


