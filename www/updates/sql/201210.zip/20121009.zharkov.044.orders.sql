-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 09.10.2012 18:43:00
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_order_add_item$$
CREATE PROCEDURE sp_order_add_item(param_user_id INT, param_order_id INT, param_position_id INT, param_item_id INT)
sp:
BEGIN

    DECLARE var_parent_id       INT DEFAULT 0;
    DECLARE var_is_locked       TINYINT DEFAULT 0;
    DECLARE var_is_conflicted   TINYINT DEFAULT 0;
    DECLARE ITEM_STATUS_ORDERED TINYINT DEFAULT 3;

    
    IF param_item_id = 0
    THEN
    
        SET param_item_id = sf_create_order_position_item(param_user_id, param_order_id, param_position_id);

        
        SELECT
            param_item_id       AS steelitem_id,
            param_position_id   AS steelposition_id;

    ELSE

        IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id)
        THEN
            SELECT -1 AS ErrorCode, 'sp_order_add_item' AS ErrorAt;
            LEAVE sp;
        END IF;
    
        
        SELECT
            parent_id,
            is_locked
        INTO
            var_parent_id,
            var_is_locked
        FROM steelitems
        WHERE id = param_item_id;


        UPDATE steelitems
        SET
            is_available    = 0,
            is_conflicted   = var_is_locked,
            order_id        = param_order_id,
            is_locked       = 1,
            status_id       = ITEM_STATUS_ORDERED,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_item_id;
    
    
        IF var_is_locked = 0
        THEN
    
            IF var_parent_id = 0
            THEN
    
                UPDATE steelitems
                SET
                    is_locked = 1
                WHERE parent_id = param_item_id
                AND is_available = 1;
    
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id 
                OR (parent_id = param_item_id AND is_available = 1);
    
            ELSE
    
                UPDATE steelitems
                SET
                    is_locked = 1
                WHERE (parent_id = var_parent_id OR id = var_parent_id)
                AND is_available = 1;
    
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id
                OR (
                    (parent_id = var_parent_id OR id = var_parent_id) 
                    AND is_available = 1
                );
    
            END IF;        
    
        ELSE
    
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id; 
                
        END IF;

    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_get_list$$
CREATE PROCEDURE sp_order_get_list(param_user_id INT, param_order_for CHAR(5), param_biz_id INT, param_company_id INT, 
                                   param_period_from TIMESTAMP, param_period_to TIMESTAMP, param_status CHAR(2), 
                                   param_steelgrade_id INT, param_thickness_from DECIMAL(10,4), 
                                   param_thickness_to DECIMAL(10,4), param_width_from DECIMAL(10,4), 
                                   param_width_to DECIMAL(10,4), param_keyword VARCHAR(100), param_type CHAR(2))
sp:
BEGIN

    DECLARE var_where       VARCHAR(4000) DEFAULT '';
    DECLARE var_prefix      VARCHAR(100) DEFAULT '';
    DECLARE var_order_ids   VARCHAR(4000) DEFAULT '';
    

    IF param_steelgrade_id > 0 OR param_thickness_from > 0 OR param_thickness_to > 0 OR param_width_from > 0 OR param_width_to > 0
    THEN

        SET var_where = '';
        
        IF param_steelgrade_id > 0
        THEN 
            SET var_where = CONCAT(var_where, "steelgrade_id = ", param_steelgrade_id); 
        END IF;


        IF param_thickness_from > 0 OR param_thickness_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");
            
            IF param_thickness_from > 0 AND param_thickness_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(thickness_mm >= ", param_thickness_from, " AND thickness_mm <= ", param_thickness_to, ")"); 
            ELSEIF param_thickness_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm >= ", param_thickness_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm <= ", param_thickness_to); 
            END IF;
                    
        END IF;
        
        IF param_width_from > 0 OR param_width_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");

            IF param_width_from > 0 AND param_width_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(width_mm >= ", param_width_from, " AND width_mm <= ", param_width_to, ")"); 
            ELSEIF param_width_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "width_mm >= ", param_width_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "width_mm <= ", param_width_to); 
            END IF;
                    
        END IF;
    
    
        DROP TEMPORARY TABLE IF EXISTS t_orders;
        CREATE TEMPORARY TABLE t_orders(id INT);
        
        SET @var_stmt := CONCAT("   
            INSERT INTO t_orders(id)
            SELECT 
                order_id
            FROM order_positions 
        ", IF(var_where = "", "", " WHERE "), var_where);

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;


        SET var_order_ids = IFNULL((SELECT GROUP_CONCAT(id SEPARATOR ",") FROM t_orders), '');
        
        IF TRIM(var_order_ids) = ''
        THEN
            SET var_order_ids = '-1';
        END IF;

    END IF;

    
    SET var_where = '';
    
    
    IF TRIM(param_order_for) != ''
    THEN        
        SET var_where = CONCAT("o.order_for = '", param_order_for, "'");
    END IF;
    
    IF param_biz_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.biz_id = ", param_biz_id);
    END IF;

    IF param_company_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.company_id = ", param_company_id);
    END IF;

    IF TRIM(param_order_for) = '' AND param_biz_id = 0 AND param_company_id = 0 AND year(param_period_from) <= 1900
        AND year(param_period_to) <= 1900 AND TRIM(param_status) = '' AND param_steelgrade_id = 0 AND param_thickness_from = 0
        AND param_thickness_to = 0 AND param_width_from = 0 AND param_width_to = 0 AND TRIM(param_keyword) = '' AND TRIM(param_type) = ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status IN ('nw', 'ip', 'de')");
    ELSEIF TRIM(param_status) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status = '", param_status, "'");        
    END IF;

    IF TRIM(param_type) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.type = '", param_type, "'");
    END IF;

    IF year(param_period_from) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at >= ", param_period_from, "'");
    END IF;

    IF year(param_period_to) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at <= '", param_period_to, "'");

    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET param_keyword   = CONCAT('%', param_keyword, '%');
        SET var_prefix      = IF(var_where = "", "", " AND ");
        SET var_where       = CONCAT(var_where, var_prefix, "(o.buyer_ref LIKE '", param_keyword, "' OR o.supplier_ref LIKE '", param_keyword, "' OR o.description LIKE '", param_keyword, "')");
    END IF;

    IF var_order_ids != ''
    THEN    
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "id IN (", var_order_ids, ")");
    END IF;

    SET @var_stmt = CONCAT("
        SELECT
            o.id AS order_id
        FROM orders AS o 
    ", IF(var_where = "", "", " WHERE "), var_where, 
    " ORDER BY id");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DROP PROCEDURE IF EXISTS sp_order_position_add_from_stock$$
CREATE PROCEDURE sp_order_position_add_from_stock(param_user_id INT, param_order_id INT, param_position_id INT, param_qtty INT)
sp:
BEGIN

    DECLARE var_biz_id          INT DEFAULT 0;
    DECLARE var_order_status    CHAR(2) DEFAULT '';
    DECLARE var_dimension_unit  CHAR(10) DEFAULT '';
    DECLARE var_weight_unit     CHAR(10) DEFAULT '';
    DECLARE var_currency        CHAR(3) DEFAULT '';


    SELECT 
        biz_id,
        `status`
    INTO
        var_biz_id,
        var_order_status
    FROM orders 
    WHERE id = param_order_id;


    SELECT 
        dimension_unit,
        weight_unit,
        currency
    INTO
        var_dimension_unit,
        var_weight_unit,
        var_currency
    FROM steelpositions 
    WHERE id = param_position_id;


    IF EXISTS (SELECT * FROM order_positions WHERE order_id = param_order_id AND position_id = param_position_id)
    THEN

        SELECT
            var_biz_id          AS biz_id,
            var_order_status    AS order_status,
            var_dimension_unit  AS dimension_unit,
            var_weight_unit     AS weight_unit,
            var_currency        AS currency,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            `length`,
            length_mm,
            unitweight,
            unitweight_ton,
            (qtty + param_qtty) AS qtty,
            ((qtty + param_qtty) * unitweight) AS weight,
            ((qtty + param_qtty) * unitweight_ton) AS weight_ton,
            price,
            ((qtty + param_qtty) * unitweight) * price AS `value`,
            deliverytime,
            internal_notes
        FROM order_positions
        WHERE order_id = param_order_id
        AND position_id = param_position_id;

    ELSE

        SELECT
            var_biz_id          AS biz_id,
            var_order_status    AS order_status,
            var_dimension_unit  AS dimension_unit,
            var_weight_unit     AS weight_unit,
            var_currency        AS currency,
            steelgrade_id,
            thickness,
            thickness_mm,
            width,
            width_mm,
            `length`,
            length_mm,
            unitweight,
            unitweight_ton,
            param_qtty AS qtty,
            param_qtty * unitweight AS weight,
            param_qtty * unitweight_ton AS weight_ton,
            price,
            param_qtty * unitweight * price AS `value`,
            '' AS deliverytime,
            '' AS internal_notes
        FROM steelpositions
        WHERE id = param_position_id;
        
    END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_order_remove_item$$
CREATE PROCEDURE sp_order_remove_item(param_user_id INT, param_order_id INT, param_item_id INT, param_leave_history BOOLEAN)
sp:
BEGIN


    DECLARE var_position_id     INT DEFAULT 0;
    DECLARE var_parent_id       INT DEFAULT 0;
    DECLARE var_is_from_order   INT DEFAULT 0;
    DECLARE ITEM_STATUS_STOCK   TINYINT DEFAULT 2;


    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_order_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND order_id = param_order_id)
    THEN
        SELECT -2 AS ErrorCode, 'sp_order_remove_item' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SELECT 
        steelposition_id,
        parent_id,
        is_from_order
    INTO
        var_position_id,
        var_parent_id,
        var_is_from_order
    FROM steelitems 
    WHERE id = param_item_id;


    IF var_is_from_order > 0
    THEN
        
        
        SELECT
            id AS steelitem_id,
            steelposition_id
        FROM steelitems
        WHERE id = param_item_id;


        UPDATE steelitem_properties SET modified_at = NOW(), modified_by = param_user_id WHERE item_id = param_item_id;
        DELETE FROM steelitem_properties WHERE item_id = param_item_id;
            
        UPDATE steelitems SET modified_at = NOW(), modified_by = param_user_id WHERE id = param_item_id;
        DELETE FROM steelitems WHERE id = param_item_id;

    ELSE
        
        UPDATE steelitems
        SET
            is_available    = 1,
            order_id        = 0,
            status_id       = ITEM_STATUS_STOCK,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_item_id;


        IF var_parent_id = 0
        THEN

            IF NOT EXISTS (SELECT * FROM steelitems WHERE parent_id = param_item_id AND order_id > 0)
            THEN
                
                UPDATE steelitems
                SET
                    is_locked       = sf_item_check_lock(id, parent_id),
                    is_conflicted   = sf_item_check_conflict(id, parent_id)
                WHERE id = param_item_id
                OR parent_id = param_item_id;


                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE id = param_item_id
                OR parent_id = param_item_id;

            END IF;

        ELSE

            IF NOT EXISTS (SELECT * FROM steelitems WHERE (parent_id = var_parent_id OR id = var_parent_id) AND order_id > 0)
            THEN                
                
                UPDATE steelitems
                SET
                    is_locked       = sf_item_check_lock(id, parent_id),
                    is_conflicted   = sf_item_check_conflict(id, parent_id)
                WHERE parent_id = var_parent_id 
                OR id = var_parent_id;

                
                
                SELECT
                    id AS steelitem_id,
                    steelposition_id
                FROM steelitems
                WHERE parent_id = var_parent_id 
                OR id = var_parent_id;

            END IF;

        END IF;

    END IF;


    IF param_leave_history = FALSE AND NOT EXISTS (SELECT * FROM steelitems WHERE steelposition_id = var_position_id AND order_id = param_order_id)
    THEN

        DELETE FROM order_positions 
        WHERE order_id = param_order_id 
        AND position_id = var_position_id;

    END IF;

END
$$

DELIMITER ;

