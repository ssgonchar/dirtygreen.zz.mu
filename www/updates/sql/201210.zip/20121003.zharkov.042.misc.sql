UPDATE ddt SET number_full = CONCAT(number, '/', ddt_year);

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_user_save$$
CREATE PROCEDURE sp_user_save(param_user_id INT, param_id INT, param_login VARCHAR(20), param_nickname VARCHAR(2), param_password VARCHAR(32),
                                param_email VARCHAR(250), param_role_id TINYINT, param_status_id TINYINT, param_person_id INT, 
                                param_color VARCHAR(20), param_is_mam TINYINT, param_se_access TINYINT, param_pa_access TINYINT,
                                param_chat_icon_park TINYINT)
sp: 
BEGIN

    IF param_id > 0
    THEN

        UPDATE users
        SET
            login           = param_login,
            nickname        = param_nickname,
            `password`      = param_password,
            email           = param_email,
            role_id         = param_role_id,
            status_id       = param_status_id,
            person_id       = param_person_id,
            color           = param_color,
            is_mam          = param_is_mam,
            se_access       = param_se_access,
            pa_access       = param_pa_access,
            chat_icon_park  = param_chat_icon_park,
            modified_at     = NOW(),
            modified_by     = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO users
            SET
                login           = param_login,
                nickname        = param_nickname,
                `password`      = param_password,
                email           = param_email,
                role_id         = param_role_id,
                status_id       = param_status_id,
                person_id       = param_person_id,
                color           = param_color,
                is_mam          = param_is_mam,
                se_access       = param_se_access,
                pa_access       = param_pa_access,
                chat_icon_park  = param_chat_icon_park,
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;

            SET param_id = (SELECT MAX(id) FROM users WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$

DROP PROCEDURE IF EXISTS sp_invoice_save$$
CREATE PROCEDURE sp_invoice_save(param_user_id INT, param_id INT, param_order_id INT, param_biz_id INT, param_company_id INT, param_owner_id INT, 
                                    param_number VARCHAR(20), param_date TIMESTAMP)
BEGIN

    DECLARE var_iva_number  INT DEFAULT 0;
    DECLARE var_year4       INT DEFAULT 0;
    DECLARE var_year2       INT DEFAULT 0;
    
    SET var_year4 = DATE_FORMAT(NOW(), '%Y');
    SET var_year2 = DATE_FORMAT(NOW(), '%y');

    IF param_id > 0
    THEN

        UPDATE invoices
        SET
            biz_id      = param_biz_id,
            company_id  = param_company_id,
            number      = param_number,
            `date`      = param_date,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
        
            SET var_iva_number = IFNULL((SELECT MAX(iva_number) FROM invoices WHERE owner_id = param_owner_id AND iva_year = var_year4), 0) + 1;
            
            INSERT invoices
            SET
                order_id        = param_order_id,
                biz_id          = param_biz_id,
                company_id      = param_company_id,
                owner_id        = param_owner_id,
                number          = param_number,
                `date`          = param_date,
                iva_number      = var_iva_number,
                iva_number_full = CONCAT(var_iva_number, '/', var_year4),
                iva_year        = var_year4,
                created_at      = NOW(),
                created_by      = param_user_id;

            SET param_id = (SELECT MAX(id) FROM invoices WHERE created_by  = param_user_id);

        COMMIT;

    END IF;

    
    SELECT param_id AS id;    
    
    SELECT * FROM invoice_items WHERE invoice_id = param_id;
    
    DELETE FROM invoice_items WHERE invoice_id = param_id;

END
$$

DROP PROCEDURE IF EXISTS sp_ddt_save$$
CREATE PROCEDURE sp_ddt_save(param_user_id INT, param_id INT, param_order_id INT, param_owner_id INT, param_date TIMESTAMP, param_invoice_id INT)
BEGIN

    DECLARE var_year4   INT DEFAULT 0;
    DECLARE var_number  INT DEFAULT 0;
    
    SET var_year4 = DATE_FORMAT(param_date, '%Y');

    IF param_id > 0
    THEN

        UPDATE ddt
        SET
            `date`      = param_date,
            invoice_id  = param_invoice_id,
            modified_at = NOW(),
            modified_by = param_user_id
        WHERE id = param_id;

    ELSE

        START TRANSACTION;
        
            SET var_number = IFNULL((SELECT MAX(number) FROM ddt WHERE owner_id = param_owner_id AND ddt_year = var_year4), 0) + 1;
            
            INSERT ddt
            SET
                order_id    = param_order_id,
                company_id  = (SELECT company_id FROM orders WHERE id = param_order_id),
                number      = var_number,
                number_full = CONCAT(var_number, '/', var_year4),
                `date`      = param_date,
                owner_id    = param_owner_id,
                invoice_id  = param_invoice_id,
                ddt_year    = var_year4,
                created_at  = NOW(),
                created_by  = param_user_id,
                modified_at = NOW(),
                modified_by = param_user_id;

            SET param_id = (SELECT MAX(id) FROM ddt WHERE created_by  = param_user_id);

        COMMIT;

    END IF;

    
    SELECT param_id AS id;

END
$$

DELIMITER ;
