set names 'utf8';

ALTER TABLE `ra`
    CHANGE COLUMN `ddt_id` `ddt_number` VARCHAR(50) NULL DEFAULT NULL COMMENT 'Номер DDT от склада (stockholder-a)',
    ADD COLUMN `ddt_date` TIMESTAMP NULL COMMENT 'Дата DDT от склада (stockholder-a)' AFTER `ddt_number`
;
