SET NAMES 'utf8';

ALTER TABLE `ra` ADD COLUMN `ddt_instructions` TEXT NULL COMMENT 'Инструкции для DDT' AFTER `ddt_date`;



DELIMITER $$
DROP PROCEDURE IF EXISTS `sp_ra_save`$$
CREATE PROCEDURE `sp_ra_save`(
	IN param_user_id INT,
	IN param_id INT,
	IN param_stockholder_id INT,
	IN param_company_id INT,
	IN param_truck_number VARCHAR(50),
	IN param_destination VARCHAR(200),
	IN param_loading_date VARCHAR(200),
	IN param_marking TEXT,
	IN param_dunnaging TEXT,
	IN param_status_id TINYINT,
	IN param_max_weight DECIMAL(10,4),
	IN param_weighed_weight DECIMAL(10,4),
	IN param_ddt_number VARCHAR(50),
	IN param_ddt_date DATETIME,
	IN param_ddt_instructions TEXT
)
sp:
BEGIN
	IF param_id = 0
	THEN
		START TRANSACTION;
			INSERT INTO ra
			SET
				`number`			= IFNULL((SELECT MAX(ra2.`number`)+1 FROM ra AS ra2 LIMIT 1), 1),
				`stockholder_id`	= param_stockholder_id,
				`company_id`		= param_company_id,
				`truck_number`		= param_truck_number,
				`destination`		= param_destination,
				`loading_date`		= param_loading_date,
				`marking`			= param_marking,
				`dunnaging`			= param_dunnaging,
				`status_id`			= param_status_id,
				`max_weight`		= param_max_weight,
				`weighed_weight`	= param_weighed_weight,
				`ddt_number`		= param_ddt_number,
				`ddt_date`			= param_ddt_date,
				`ddt_instructions`  = param_ddt_instructions,
				`created_at`		= NOW(),
				`created_by`		= param_user_id,
				`modified_at`		= NOW(),
				`modified_by`		= param_user_id
			;

			SET param_id = (SELECT MAX(id) FROM ra WHERE `created_by` = param_user_id);
		COMMIT;
	ELSE
		UPDATE ra
		SET
			`stockholder_id`	= param_stockholder_id,
			`company_id`		= param_company_id,
			`truck_number`		= param_truck_number,
			`destination`		= param_destination,
			`loading_date`		= param_loading_date,
			`marking`			= param_marking,
			`dunnaging`			= param_dunnaging,
			`status_id`			= param_status_id,
			`max_weight`		= param_max_weight,
			`weighed_weight`	= param_weighed_weight,
			`ddt_number`		= param_ddt_number,
			`ddt_date`			= param_ddt_date,
			`ddt_instructions`  = param_ddt_instructions,
			`modified_at`		= NOW(),
			`modified_by`		= param_user_id
		WHERE
			id = param_id
		;
	END IF;

	SELECT param_id AS ra_id;
END$$

DELIMITER ;
