-- ������ ������������ Devart dbForge Studio for MySQL, ������ 5.0.97.1
-- �������� �������� ��������: http://www.devart.com/ru/dbforge/mysql/studio
-- ���� �������: 15/05/2013 14:30:18
-- ������ �������: 5.5.27
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_move$$
CREATE PROCEDURE sp_steelitem_move(param_user_id INT, param_id INT, param_dest_stockholder_id INT, param_dest_position_id INT, param_source_position_id INT)
sp:
BEGIN

    DECLARE var_location_id         INT DEFAULT 0;
    DECLARE var_stockholder_id      INT DEFAULT 0;
    DECLARE ITEM_STATUS_RELEASED    TINYINT DEFAULT 5;


    IF param_dest_position_id = param_source_position_id
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF EXISTS (SELECT * FROM steelitems WHERE id = param_id AND status_id >= ITEM_STATUS_RELEASED)
    THEN
        SELECT -2 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;

    IF param_source_position_id > 0 AND NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id AND steelposition_id = param_source_position_id)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_move' AS ErrorAt;
        LEAVE sp;
    END IF;
    

    SET var_location_id     = (SELECT location_id FROM companies WHERE id = param_dest_stockholder_id);
    SET var_stockholder_id  = (SELECT stockholder_id FROM steelitems WHERE id = param_id);

    
    SELECT 
        steelposition_id
    FROM steelitems 
    WHERE id = param_id
    AND (steelposition_id = param_source_position_id OR param_source_position_id = 0);


    
    UPDATE steelitems
    SET
        steelposition_id    = param_dest_position_id,
        biz_id              = (SELECT biz_id FROM steelpositions WHERE id = param_dest_position_id),
        stockholder_id      = param_dest_stockholder_id,
        location_id         = var_location_id,
        dimension_unit      = (SELECT dimension_unit FROM steelpositions WHERE id = param_dest_position_id),
        weight_unit         = (SELECT weight_unit FROM steelpositions WHERE id = param_dest_position_id),
        currency            = (SELECT currency FROM steelpositions WHERE id = param_dest_position_id),
        steelgrade_id       = (SELECT steelgrade_id FROM steelpositions WHERE id = param_dest_position_id),
        thickness           = (SELECT thickness FROM steelpositions WHERE id = param_dest_position_id),
        thickness_mm        = (SELECT thickness_mm FROM steelpositions WHERE id = param_dest_position_id),
        width               = (SELECT width FROM steelpositions WHERE id = param_dest_position_id),
        width_mm            = (SELECT width_mm FROM steelpositions WHERE id = param_dest_position_id),
        `length`            = (SELECT `length` FROM steelpositions WHERE id = param_dest_position_id),
        length_mm           = (SELECT length_mm FROM steelpositions WHERE id = param_dest_position_id),
        unitweight          = (SELECT unitweight FROM steelpositions WHERE id = param_dest_position_id),
        unitweight_ton      = (SELECT unitweight_ton FROM steelpositions WHERE id = param_dest_position_id),
        price               = (SELECT price FROM steelpositions WHERE id = param_dest_position_id),
        `value`             = (SELECT unitweight * price FROM steelpositions WHERE id = param_dest_position_id)
    WHERE id = param_id;

    
    IF var_stockholder_id != param_dest_stockholder_id
    THEN            
        CALL sp_steelitem_timeline_save(param_user_id, param_id, '', 0, '', NULL, 0, '', NULL, 0, param_dest_stockholder_id, 0, 0);
    END IF;


END
$$

DELIMITER ;
