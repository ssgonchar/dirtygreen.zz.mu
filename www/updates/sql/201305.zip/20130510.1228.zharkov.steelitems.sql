ALTER TABLE `steelitems` 
ADD `nominal_thickness_mm` DECIMAL(10,4) NULL AFTER `tech_data` ,
ADD `nominal_width_mm` DECIMAL(10,4) NULL AFTER `nominal_thickness_mm` ,
ADD `nominal_length_mm` DECIMAL(10,4) NULL AFTER `nominal_width_mm` ,
ADD `is_ce_mark` TINYINT NULL AFTER `nominal_length_mm` ,
ADD `is_mec_prop_not_required` TINYINT NULL AFTER `is_ce_mark` ;


ALTER TABLE steelitems_history 
ADD `nominal_thickness_mm` DECIMAL(10,4) NULL AFTER `tech_data` ,
ADD `nominal_width_mm` DECIMAL(10,4) NULL AFTER `nominal_thickness_mm` ,
ADD `nominal_length_mm` DECIMAL(10,4) NULL AFTER `nominal_width_mm` ,
ADD `is_ce_mark` TINYINT NULL AFTER `nominal_length_mm` ,
ADD `is_mec_prop_not_required` TINYINT NULL AFTER `is_ce_mark` ;


ALTER TABLE `steelitems_history` ADD INDEX `ix-steelitem_id` ( `steelitem_id` ) ;

ALTER TABLE `steelitem_properties_history` ADD INDEX `ix-item_id` ( `item_id` ) ;

update steelitems set nominal_thickness_mm = 0, nominal_width_mm = 0, nominal_length_mm = 0; 


DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_save$$
CREATE PROCEDURE sp_steelitem_save(param_user_id INT, param_id INT, param_position_id INT, param_guid VARCHAR(32), param_alias VARCHAR(32),
                                    param_product_id INT(11), param_biz_id INT(11), param_stockholder_id INT(11), param_dimension_unit CHAR(10), 
                                    param_weight_unit CHAR(10), param_currency CHAR(10), param_steelgrade_id INT, 
                                    param_thickness CHAR(10), param_thickness_mm DECIMAL(10, 4), param_thickness_measured CHAR(10), 
                                    param_width CHAR(10), param_width_mm DECIMAL(10, 4), param_width_measured CHAR(10), param_width_max CHAR(10), 
                                    param_length CHAR(10), param_length_mm DECIMAL(10, 4), param_length_measured CHAR(10), param_length_max CHAR(10), 
                                    param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10, 4), param_price DECIMAL(10, 4), 
                                    param_value DECIMAL(10, 4), param_supplier_id INT(11), param_supplier_invoice_no VARCHAR(50), 
                                    param_supplier_invoice_date TIMESTAMP, param_purchase_price DECIMAL(10, 4), param_purchase_value DECIMAL(10, 4), 
                                    param_in_ddt_number VARCHAR(50), param_in_ddt_date TIMESTAMP, 
                                    param_out_ddt_number VARCHAR(50), param_out_ddt_date TIMESTAMP, 
                                    param_deliverytime_id INT, param_notes TEXT, 
                                    param_internal_notes TEXT, param_owner_id INT(11), param_status_id TINYINT, param_is_virtual TINYINT(4), 
                                    param_mill VARCHAR(50), param_system VARCHAR(50), param_unitweight_measured DECIMAL(10, 4),
                                    param_unitweight_weighed DECIMAL(10, 4), param_current_cost DECIMAL(10,4),
                                    param_pl DECIMAL(10,4), param_load_ready VARCHAR(50), param_purchase_currency CHAR(10),
                                    param_in_ddt_company_id INT, param_ddt_company_id INT, 
                                    param_nominal_thickness_mm DECIMAL(10, 4), param_nominal_width_mm DECIMAL(10, 4), param_nominal_length_mm DECIMAL(10, 4), 
                                    param_is_ce_mark TINYINT, param_is_mec_prop_not_required TINYINT)
sp:
BEGIN

    DECLARE var_location_id     INT DEFAULT 0;
	DECLARE var_stockholder_id  INT DEFAULT 0;
    DECLARE var_status_id       TINYINT DEFAULT 0;


    IF TRIM(param_guid) != '' AND EXISTS (SELECT * FROM steelitems WHERE alias = param_alias AND id != param_id)
    THEN
        SELECT -1 AS ErrorCode, 'steelitem_save' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SET param_is_virtual    = IF(TRIM(param_guid) != '', 0, param_is_virtual);
    SET var_location_id     = IFNULL((SELECT location_id FROM companies WHERE id = param_stockholder_id), 0);
	

    IF param_id > 0
    THEN
		
        SET var_stockholder_id  = IFNULL((SELECT stockholder_id FROM steelitems WHERE id = param_id), 0);
        SET var_status_id       = IFNULL((SELECT status_id FROM steelitems WHERE id = param_id), 0);

        IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_id)
        THEN
            SELECT -2 AS ErrorCode, 'steelitem_save' AS ErrorAt;
            LEAVE sp;
        END IF;
    
        UPDATE steelitems
        SET
            guid                        = param_guid,
            alias                       = param_alias,
            product_id                  = param_product_id,
            biz_id                      = param_biz_id,
            stockholder_id              = IF(param_stockholder_id > 0, param_stockholder_id, stockholder_id),
            location_id                 = IF(param_stockholder_id > 0, var_location_id, location_id),
            dimension_unit              = IF(TRIM(param_dimension_unit) = '', dimension_unit, param_dimension_unit),
            weight_unit                 = IF(TRIM(param_weight_unit) = '', weight_unit, param_weight_unit),
            currency                    = IF(TRIM(param_currency) = '', currency, param_currency),
            steelgrade_id               = param_steelgrade_id,
            thickness                   = param_thickness,
            thickness_mm                = param_thickness_mm,
            thickness_measured          = param_thickness_measured,
            width                       = param_width,
            width_mm                    = param_width_mm,
            width_measured              = param_width_measured,
            width_max                   = param_width_max,
            `length`                    = param_length,
            length_mm                   = param_length_mm,
            length_measured             = param_length_measured,
            length_max                  = param_length_max,
            unitweight                  = param_unitweight,
            unitweight_ton              = param_unitweight_ton,
            price                       = param_price,
            `value`                     = param_value,
            purchase_price              = IF(TRIM(param_purchase_price) = '', purchase_price, param_purchase_price),
            purchase_value              = IF(TRIM(param_purchase_value) = '', purchase_value, param_purchase_value),
            purchase_currency           = IF(TRIM(param_purchase_currency) = '', purchase_currency, param_purchase_currency),
            in_ddt_number               = IF(TRIM(param_in_ddt_number) != '', param_in_ddt_number, in_ddt_number),
            in_ddt_date                 = IF(param_in_ddt_date AND param_in_ddt_date != '', param_in_ddt_date, NULL),
            in_ddt_company_id           = IF(param_in_ddt_company_id > 0, param_in_ddt_company_id, in_ddt_company_id),
            ddt_number                  = IF(TRIM(param_out_ddt_number) != '', param_out_ddt_number, ddt_number),
            ddt_date                    = IF(param_out_ddt_date AND param_out_ddt_date != '', param_out_ddt_date, NULL),
            ddt_company_id              = IF(param_ddt_company_id > 0, param_ddt_company_id, ddt_company_id),
            deliverytime_id             = param_deliverytime_id,
            notes                       = param_notes,
            internal_notes              = param_internal_notes,
            owner_id                    = IF(param_owner_id > 0, param_owner_id, owner_id),
            status_id                   = IF(param_status_id > 0, param_status_id, status_id),
            is_virtual                  = param_is_virtual,
            mill                        = param_mill,
            system                      = param_system,
            unitweight_measured         = param_unitweight_measured,
            unitweight_weighed          = param_unitweight_weighed,
            current_cost                = param_current_cost,
            pl                          = param_pl,
            load_ready                  = param_load_ready,
            nominal_thickness_mm        = param_nominal_thickness_mm,
            nominal_width_mm            = param_nominal_width_mm,
            nominal_length_mm           = param_nominal_length_mm,
            is_ce_mark                  = param_is_ce_mark, 
            is_mec_prop_not_required    = param_is_mec_prop_not_required,
            modified_at                 = NOW(),
            modified_by                 = param_user_id
        WHERE id = param_id;

        IF var_status_id != param_status_id
        THEN            
            CALL sp_steelitem_timeline_save(param_user_id, param_id, '', 0, '', NULL, 0, '', NULL, 0, 0, param_status_id, 0);
        END IF;

    ELSE

        START TRANSACTION;
            
            INSERT INTO steelitems
            SET
                steelposition_id            = param_position_id,
                guid                        = param_guid,
                alias                       = param_alias,
                product_id                  = param_product_id,
                biz_id                      = param_biz_id,
                stockholder_id              = param_stockholder_id,
                location_id                 = var_location_id,
                dimension_unit              = param_dimension_unit,
                weight_unit                 = param_weight_unit,
                currency                    = param_currency,
                parent_id                   = 0,
                rel                         = '',
                steelgrade_id               = param_steelgrade_id,
                thickness                   = param_thickness,
                thickness_mm                = param_thickness_mm,
                thickness_measured          = param_thickness_measured,
                width                       = param_width,
                width_mm                    = param_width_mm,
                width_measured              = param_width_measured,
                width_max                   = param_width_max,
                `length`                    = param_length,
                length_mm                   = param_length_mm,
                length_measured             = param_length_measured,
                length_max                  = param_length_max,
                unitweight                  = param_unitweight,
                unitweight_ton              = param_unitweight_ton,
                price                       = param_price,
                `value`                     = param_value,
                purchase_price              = param_purchase_price,
                purchase_value              = param_purchase_value,
                purchase_currency           = param_purchase_currency,
                in_ddt_id                   = 0,
                in_ddt_number               = '',
                in_ddt_date                 = null,
                in_ddt_company_id           = param_in_ddt_company_id,
                ddt_number                  = '',
                ddt_date                    = null,
                ddt_company_id              = param_ddt_company_id,
                deliverytime_id             = param_deliverytime_id,
                notes                       = param_notes,
                internal_notes              = param_internal_notes,
                owner_id                    = param_owner_id,
                status_id                   = param_status_id,
                is_virtual                  = param_is_virtual,
                is_available                = 1,
                is_deleted                  = 0,
                is_conflicted               = 0,
                is_locked                   = 0,
                mill                        = param_mill,
                system                      = param_system,
                unitweight_measured         = param_unitweight_measured,
                unitweight_weighed          = param_unitweight_weighed,
                current_cost                = param_current_cost,
                pl                          = param_pl,
                load_ready                  = param_load_ready,
                is_from_order               = IF(param_stockholder_id > 0, 0, 1),
                order_id                    = 0,
                invoice_id                  = 0,
                tech_action                 = '',
                nominal_thickness_mm        = param_nominal_thickness_mm,
                nominal_width_mm            = param_nominal_width_mm,
                nominal_length_mm           = param_nominal_length_mm,
                is_ce_mark                  = param_is_ce_mark, 
                is_mec_prop_not_required    = param_is_mec_prop_not_required,
                created_at                  = NOW(),
                created_by                  = param_user_id,
                modified_at                 = NOW(),
                modified_by                 = param_user_id;
        
            SET param_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);

            CALL sp_steelitem_timeline_save(param_user_id, param_id, '', 0, '', NULL, 0, '', NULL, 0, param_stockholder_id, param_status_id, param_owner_id);

        COMMIT;

    END IF;

    SELECT param_id AS id;

END
$$

DELIMITER ;
