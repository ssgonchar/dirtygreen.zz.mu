-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 11.05.2013 10:56:30
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_qc_remove_item$$
CREATE PROCEDURE sp_qc_remove_item(
	IN param_user_id INT,
	IN param_qc_id INT,
	IN param_steelitem_id INT
)
sp:
BEGIN
	
    DECLARE var_attachment_ids VARCHAR(1100) DEFAULT '';

	
    DELETE FROM qc_items 
    WHERE qc_id = param_qc_id
    AND steelitem_id = param_steelitem_id;


	SET var_attachment_ids = (
		SELECT GROUP_CONCAT(attachment_id SEPARATOR ",") 
		FROM attachment_objects 
		WHERE object_alias = 'qc'
		AND object_id = param_qc_id
	);
	
	IF var_attachment_ids != ""
	THEN
		SET @var_stmt = CONCAT("
			DELETE FROM attachment_objects 
			WHERE object_alias = 'qc'
			AND object_id = " , param_steelitem_id, 
			" AND attachment_id IN (", var_attachment_ids, ")
		");
		
		PREPARE stmt FROM @var_stmt;
		EXECUTE stmt; 
	END IF;
	
END
$$

DROP PROCEDURE IF EXISTS sp_qc_save$$
CREATE PROCEDURE sp_qc_save(IN param_user_id INT, IN param_id INT, IN param_mam_co CHAR(5), IN param_stock_id INT, IN param_biz VARCHAR(100), IN param_biz_id INT(11), IN param_order_id INT(11), IN param_customer VARCHAR(100), IN param_customer_id INT(11), IN param_certification_standard VARCHAR(100), IN param_commodity_name VARCHAR(100), IN param_standard VARCHAR(100), IN param_customer_order_no VARCHAR(100), IN param_manufacturer VARCHAR(100), IN param_country_of_origin VARCHAR(100), IN param_surface_quality VARCHAR(100), IN param_tolerances_on_thickness VARCHAR(100), IN param_tolerances_on_flatness VARCHAR(100), IN param_steelmaking_process VARCHAR(100), IN param_delivery_conditions VARCHAR(100), IN param_ultrasonic_test VARCHAR(100), IN param_marking VARCHAR(100), IN param_visual_inspection VARCHAR(100), IN param_flattening VARCHAR(100), IN param_stress_relieving VARCHAR(100), IN param_elongation_in VARCHAR(50), IN param_sample_direction_in VARCHAR(50), IN param_ce_mark TINYINT, IN param_no_weld_repair TINYINT, IN param_units VARCHAR(20))
BEGIN

    DECLARE var_number INT DEFAULT 0;

    IF param_id = 0
    THEN
        
        START TRANSACTION;

            SET var_number = IFNULL((SELECT MAX(number) FROM qc), 0) + 1;
            
            INSERT INTO qc
            SET
                mam_co                  = param_mam_co,
                number                  = var_number,
                stock_id                = param_stock_id,
                biz                     = param_biz,
                biz_id                  = param_biz_id,
                order_id                = param_order_id,
                customer                = param_customer,
                customer_id             = param_customer_id,
                certification_standard  = param_certification_standard,
                commodity_name          = param_commodity_name,
                standard                = param_standard,
                customer_order_no       = param_customer_order_no,
                manufacturer            = param_manufacturer,
                country_of_origin       = param_country_of_origin,
                surface_quality         = param_surface_quality,
                tolerances_on_thickness = param_tolerances_on_thickness,
                tolerances_on_flatness  = param_tolerances_on_flatness,
                steelmaking_process     = param_steelmaking_process,
                delivery_conditions     = param_delivery_conditions,
                ultrasonic_test         = param_ultrasonic_test,
                marking                 = param_marking,
                visual_inspection       = param_visual_inspection,
                flattening              = param_flattening,
                stress_relieving        = param_stress_relieving,
                elongation_in           = param_elongation_in,
                sample_direction_in     = param_sample_direction_in,
                ce_mark                 = param_ce_mark,
                no_weld_repair          = param_no_weld_repair,
                units                   = param_units,
                attachment_id           = 0,
                created_at              = NOW(),
                created_by              = param_user_id,
                modified_at             = NOW(),
                modified_by             = param_user_id;

                SET param_id = (SELECT MAX(id) FROM qc WHERE created_by = param_user_id);
            
        COMMIT;

    ELSE

        UPDATE qc
        SET
            biz                     = param_biz,
            biz_id                  = param_biz_id,
            order_id                = param_order_id,
            customer                = param_customer,
            customer_id             = param_customer_id,
            certification_standard  = param_certification_standard,
            commodity_name          = param_commodity_name,
            standard                = param_standard,
            customer_order_no       = param_customer_order_no,
            manufacturer            = param_manufacturer,
            country_of_origin       = param_country_of_origin,
            surface_quality         = param_surface_quality,
            tolerances_on_thickness = param_tolerances_on_thickness,
            tolerances_on_flatness  = param_tolerances_on_flatness,
            steelmaking_process     = param_steelmaking_process,
            delivery_conditions     = param_delivery_conditions,
            ultrasonic_test         = param_ultrasonic_test,
            marking                 = param_marking,
            visual_inspection       = param_visual_inspection,
            flattening              = param_flattening,
            stress_relieving        = param_stress_relieving,
            elongation_in           = param_elongation_in,
            sample_direction_in     = param_sample_direction_in,
            ce_mark                 = param_ce_mark,
            no_weld_repair          = param_no_weld_repair,
            units                   = param_units,
            modified_at             = NOW(),
            modified_by             = param_user_id
        WHERE id = param_id;

    END IF;

    
    SELECT param_id AS id;

END
$$

DELIMITER ;
