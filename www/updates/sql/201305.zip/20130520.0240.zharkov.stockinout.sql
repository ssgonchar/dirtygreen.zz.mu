UPDATE steelitem_timeline SET modified_at = created_at WHERE modified_at IS NULL;
UPDATE steelitem_timeline SET modified_by = created_by WHERE modified_by = 0 OR modified_by IS NULL;

-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 20.05.2013 2:39:53
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_report_stockinout$$
CREATE PROCEDURE sp_report_stockinout(
    param_owner VARCHAR(50), 
    param_stockholder_id INT, 
    param_type_id INT, 
    param_date_from TIMESTAMP, 
    param_date_to TIMESTAMP, 
    param_steelgrade_id INT, 
    param_thickness_from DECIMAL(10,4), 
    param_thickness_to DECIMAL(10,4),
    param_width_from DECIMAL(10,4), 
    param_width_to DECIMAL(10,4),
    param_supplier_id INT, 
    param_buyer_id INT, 
    param_country_id INT
)
sp:
BEGIN
	DECLARE REPORT_INOUT_TYPE_IN    TINYINT DEFAULT 1;
	DECLARE REPORT_INOUT_TYPE_OUT   TINYINT DEFAULT 2;
    DECLARE REPORT_INOUT_TYPE_SOLD  TINYINT DEFAULT 3;
	DECLARE var_where               VARCHAR(1000) DEFAULT ' si.parent_id = 0 ';
	DECLARE var_date_select         VARCHAR(1000) DEFAULT ' si.id ';


    IF param_type_id = REPORT_INOUT_TYPE_IN
    THEN
        
	    SET @var_stmt = CONCAT("
            SELECT distinct
                steelitem_id,
                
                CASE WHEN s.order_id > 0
                THEN (SELECT price FROM order_positions WHERE order_id = s.order_id AND position_id = s.steelposition_id)
                ELSE s.price
                END AS stock_price,
                
                CASE WHEN s.order_id > 0
                THEN (SELECT currency FROM orders WHERE id = s.order_id)
                ELSE s.currency      
                END AS stock_currency
            FROM steelitem_timeline AS st
            JOIN steelitems AS s ON s.id = st.steelitem_id
            JOIN steelpositions AS p ON p.id = s.steelposition_id
            WHERE st.stockholder_id = ", param_stockholder_id, "
            AND st.prev_stockholder_id NOT IN (", param_stockholder_id, ")",
            IF(param_date_from > 0, CONCAT(" AND st.modified_at >= '", param_date_from, "'"), ""),
            IF(param_date_to > 0, CONCAT(" AND st.modified_at < '", param_date_to, "'"), ""),
            IF(param_owner != '', CONCAT(" AND s.owner_id IN (", param_owner, ")"), ""),
            IF(param_steelgrade_id > 0, CONCAT(" AND s.steelgrade_id = ", param_steelgrade_id), ""),
            IF(param_thickness_from > 0, CONCAT(" AND s.thickness_mm >= ", param_thickness_from), ""),
            IF(param_thickness_to > 0, CONCAT(" AND s.thickness_mm <= ", param_thickness_to), ""),
            IF(param_width_from > 0, CONCAT(" AND s.width_mm >= ", param_width_from), ""),
            IF(param_width_to > 0, CONCAT(" AND s.width_mm <= ", param_width_to), ""),
            IF(param_supplier_id > 0, CONCAT(" AND s.supplier_id = ", param_supplier_id), ""),
        ";");

    ELSEIF param_type_id = REPORT_INOUT_TYPE_OUT
    THEN
        
	    SET @var_stmt = CONCAT("
            SELECT distinct
                steelitem_id,

                CASE WHEN s.order_id > 0
                THEN (SELECT price FROM order_positions WHERE order_id = s.order_id AND position_id = s.steelposition_id)
                ELSE s.price
                END AS stock_price,
                
                CASE WHEN s.order_id > 0
                THEN (SELECT currency FROM orders WHERE id = s.order_id)
                ELSE s.currency      
                END AS stock_currency
            FROM steelitem_timeline AS st
            JOIN steelitems AS s ON s.id = st.steelitem_id
            JOIN steelpositions AS p ON p.id = s.steelposition_id
            WHERE st.prev_stockholder_id = ", param_stockholder_id, "
            AND st.stockholder_id NOT IN (", param_stockholder_id, ")",
            IF(param_date_from > 0, CONCAT(" AND st.modified_at >= '", param_date_from, "'"), ""),
            IF(param_date_to > 0, CONCAT(" AND st.modified_at < '", param_date_to, "'"), ""),
            IF(param_owner != '', CONCAT(" AND s.owner_id IN (", param_owner, ")"), ""),
            IF(param_steelgrade_id > 0, CONCAT(" AND s.steelgrade_id = ", param_steelgrade_id), ""),
            IF(param_thickness_from > 0, CONCAT(" AND s.thickness_mm >= ", param_thickness_from), ""),
            IF(param_thickness_to > 0, CONCAT(" AND s.thickness_mm <= ", param_thickness_to), ""),
            IF(param_width_from > 0, CONCAT(" AND s.width_mm >= ", param_width_from), ""),
            IF(param_width_to > 0, CONCAT(" AND s.width_mm <= ", param_width_to), ""),
            IF(param_supplier_id > 0, CONCAT(" AND s.supplier_id = ", param_supplier_id), ""),
        ";");

    ELSEIF param_type_id = REPORT_INOUT_TYPE_SOLD
    THEN
        
	    SET @var_stmt = CONCAT("
            SELECT
                s.id        AS steelitem_id,

                CASE WHEN s.order_id > 0
                THEN (SELECT price FROM order_positions WHERE order_id = s.order_id AND position_id = s.steelposition_id)
                ELSE s.price
                END AS stock_price,
                
                CASE WHEN s.order_id > 0
                THEN (SELECT currency FROM orders WHERE id = s.order_id)
                ELSE s.currency      
                END AS stock_currency
            FROM steelitems AS s
            JOIN steelpositions AS p ON p.id = s.steelposition_id
            JOIN orders AS o ON s.order_id = o.id
            JOIN companies AS c ON o.company_id = c.id
            WHERE s.stockholder_id = ", param_stockholder_id,
            IF(param_date_from > 0, CONCAT(" AND o.created_at >= '", param_date_from, "'"), ""),
            IF(param_date_to > 0, CONCAT(" AND o.created_at < '", param_date_to, "'"), ""),
            IF(param_owner != '', CONCAT(" AND s.owner_id IN (", param_owner, ")"), ""),
            IF(param_steelgrade_id > 0, CONCAT(" AND s.steelgrade_id = ", param_steelgrade_id), ""),
            IF(param_thickness_from > 0, CONCAT(" AND s.thickness_mm >= ", param_thickness_from), ""),
            IF(param_thickness_to > 0, CONCAT(" AND s.thickness_mm <= ", param_thickness_to), ""),
            IF(param_width_from > 0, CONCAT(" AND s.width_mm >= ", param_width_from), ""),
            IF(param_width_to > 0, CONCAT(" AND s.width_mm <= ", param_width_to), ""),
            IF(param_supplier_id > 0, CONCAT(" AND s.supplier_id = ", param_supplier_id), ""),
            IF(param_buyer_id > 0, CONCAT(" AND o.company_id = ", param_buyer_id), ""),
            IF(param_country_id > 0, CONCAT(" AND c.country_id = ", param_country_id), ""),
            " AND o.status IN ('nw', 'ip', 'de', 'co')", 
        ";");

    END IF;

	PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DELIMITER ;
