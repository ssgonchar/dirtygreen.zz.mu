ALTER TABLE `steelitem_timeline` ADD `prev_stockholder_id` INT NOT NULL AFTER `ddt_company_id` ;

DROP TABLE IF EXISTS steelitem_timeline_temp;
CREATE TABLE steelitem_timeline_temp LIKE steelitem_timeline;
INSERT INTO steelitem_timeline_temp SELECT * FROM steelitem_timeline;
ALTER TABLE `steelitem_timeline` ADD INDEX `ix-steelitem_id` ( `steelitem_id` );

UPDATE steelitem_timeline
SET 
	prev_stockholder_id = IFNULL((
		SELECT 
			stockholder_id 
		FROM steelitem_timeline_temp 
		WHERE steelitem_id = steelitem_timeline.steelitem_id
		AND id < steelitem_timeline.id
		ORDER BY id DESC 
		LIMIT 1
	), 0);

	
DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_cut$$
CREATE PROCEDURE sp_steelitem_cut(
    param_user_id INT, 
    param_id INT, 
    param_item_id INT, 
    param_stockholder_id INT, 
    param_position_id INT,
    param_width CHAR(10), 
    param_width_mm DECIMAL(10,4), 
    param_length CHAR(10), 
    param_length_mm DECIMAL(10, 4), 
    param_unitweight CHAR(10), 
    param_unitweight_ton DECIMAL(10, 4), 
    param_guid VARCHAR(32),
    param_alias VARCHAR(32),
    param_notes TEXT
)
sp:
BEGIN
    
    DECLARE var_item_id             INT DEFAULT 0;
    DECLARE var_stock_id            INT DEFAULT 0;
    DECLARE var_biz_id              INT DEFAULT 0;
    DECLARE var_location_id         INT DEFAULT 0;
    DECLARE var_dimension_unit      CHAR(10) DEFAULT '';
    DECLARE var_weight_unit         CHAR(10) DEFAULT '';
    DECLARE var_currency            CHAR(3) DEFAULT '';
    DECLARE var_steelgrade_id       INT DEFAULT 0;
    DECLARE var_thickness           CHAR(10) DEFAULT '';
    DECLARE var_thickness_mm        DECIMAL (10, 4) DEFAULT 0;

    DECLARE var_in_ddt_number       VARCHAR(50) DEFAULT '';
    DECLARE var_in_ddt_date         TIMESTAMP DEFAULT NULL;
    DECLARE var_in_ddt_company_id   INT DEFAULT 0;
    DECLARE var_ddt_number          VARCHAR(50) DEFAULT '';
    DECLARE var_ddt_date            TIMESTAMP DEFAULT NULL;
    DECLARE var_ddt_company_id      INT DEFAULT 0;
    DECLARE var_stockholder_id      INT DEFAULT 0;
    DECLARE var_status_id           INT DEFAULT 0;
    DECLARE var_owner_id            INT DEFAULT 0;



    CREATE TEMPORARY TABLE IF NOT EXISTS tmp_items LIKE steelitems;


    IF NOT EXISTS (SELECT * FROM steelitems WHERE id = param_item_id AND is_available = 1 AND is_deleted = 0 AND parent_id = 0)
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelitem_cut' AS ErrorAt;
        LEAVE sp;
    END IF;

    
    SELECT
        biz_id,
        dimension_unit,
        weight_unit,
        currency,
        steelgrade_id,
        thickness,
        thickness_mm
    INTO
        var_biz_id,
        var_dimension_unit,
        var_weight_unit,
        var_currency,
        var_steelgrade_id,
        var_thickness,
        var_thickness_mm
    FROM steelitems
    WHERE id = param_item_id;
    
    SET var_location_id = (SELECT location_id FROM companies WHERE id = param_stockholder_id);
    SET var_stock_id    = (SELECT stock_id FROM steelpositions WHERE id = (SELECT steelposition_id FROM steelitems WHERE id = param_item_id));

    
    START TRANSACTION;

        IF param_position_id = 0
        THEN
    
            INSERT INTO steelpositions 
            SET
                stock_id            = var_stock_id,
                product_id          = 92,
                biz_id              = var_biz_id,
                dimension_unit      = var_dimension_unit,
                weight_unit         = var_weight_unit,
                currency            = var_currency,
                steelgrade_id       = var_steelgrade_id,
                thickness           = var_thickness,
                thickness_mm        = var_thickness_mm,
                width               = param_width,
                width_mm            = param_width_mm,
                length              = param_length,
                length_mm           = param_length_mm,
                unitweight          = param_unitweight,
                unitweight_ton      = param_unitweight_ton,
                qtty                = 1,
                weight              = param_unitweight,
                weight_ton          = param_unitweight_ton,
                price               = 0,
                `value`             = 0,
                deliverytime_id     = 0,
                notes               = '',
                internal_notes      = param_notes,
                is_from_order       = 0,
                is_deleted          = 0,
                is_reserved         = 0,
                is_locked           = 0,
                tech_action         = '',
                tech_object_alias   = '',
                tech_object_id      = 0,
                tech_data           = '',
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id,
                mam_deliverytime    = '';

            SET param_position_id = (SELECT MAX(id) FROM steelpositions WHERE created_by = param_user_id);
    
        END IF;

    
        IF param_id > 0
        THEN
            
            INSERT INTO tmp_items 
            SELECT * FROM steelitems WHERE id = param_item_id;
            
            UPDATE tmp_items SET id = param_id;

            UPDATE steelitems AS s JOIN tmp_items AS t ON s.id = t.id 
            SET 
                s.guid                      = param_guid,
    			s.alias                     = param_alias,
                s.steelposition_id          = param_position_id,
                s.biz_id                    = t.biz_id,
                s.stockholder_id            = param_stockholder_id,
                s.location_id               = t.location_id,
                s.dimension_unit            = t.dimension_unit,
                s.weight_unit               = t.weight_unit,        
                s.currency                  = t.currency,
                s.parent_id                 = 0,
                s.rel                       = '',
                s.steelgrade_id             = t.steelgrade_id,
                s.thickness                 = t.thickness,
                s.thickness_mm              = t.thickness_mm,
                s.thickness_measured        = t.thickness_measured,
                s.width                     = param_width,
                s.width_mm                  = param_width_mm,
                s.width_measured            = 0,
                s.width_max                 = 0,
                s.`length`                  = param_length,
                s.length_mm                 = param_length_mm,
                s.length_measured           = 0,
                s.length_max                = 0,
                s.unitweight                = param_unitweight,
                s.unitweight_ton            = param_unitweight_ton,
                s.price                     = t.price,
                s.`value`                   = param_unitweight * t.price,
                s.supplier_id               = t.supplier_id,
                s.supplier_invoice_id       = t.supplier_invoice_id,
                s.purchase_price            = t.purchase_price,
                s.purchase_value            = param_unitweight * t.purchase_price,
                s.purchase_currency         = t.purchase_currency,
                
                s.in_ddt_id                 = t.in_ddt_id,
                s.in_ddt_number             = t.in_ddt_number,
                s.in_ddt_date               = t.in_ddt_date,
                s.in_ddt_company_id         = t.in_ddt_company_id,
                
                s.ddt_number                = t.ddt_number,
                s.ddt_date                  = t.ddt_date,
                s.ddt_company_id            = t.ddt_company_id,
                
                s.deliverytime_id           = t.deliverytime_id,
                s.notes                     = param_notes,
                s.internal_notes            = param_notes,
                s.owner_id                  = t.owner_id,
                s.mill                      = t.mill,
                s.system                    = t.system,
                s.current_cost              = t.current_cost,
                s.pl                        = t.pl,
                s.load_ready                = t.load_ready,

                s.is_virtual                = 0,
                
                s.modified_at               = NOW(),
                s.modified_by               = param_user_id
            WHERE s.id = param_id;

            DELETE FROM steelitem_properties WHERE item_id = param_id;

            SET var_item_id = param_id;
            
        ELSE

            INSERT INTO steelitems(
                guid,
                alias,
                steelposition_id,
                product_id,
                biz_id,
                stockholder_id,
                location_id,
                dimension_unit,
                weight_unit,
                currency,
                parent_id,
                rel,
                steelgrade_id,
                thickness,
                thickness_mm,
                thickness_measured,
                width,
                width_mm,
                width_measured,
                width_max,
                `length`,
                length_mm,
                length_measured,
                length_max,
                unitweight,
                unitweight_ton,
                price,
                `value`,
                supplier_id,
                supplier_invoice_id,
                purchase_price,
                purchase_value,
                purchase_currency,
                in_ddt_id,
                in_ddt_number,
                in_ddt_date,
                in_ddt_company_id,
                ddt_number,
                ddt_date,
                ddt_company_id,
                deliverytime_id,
                notes,
                internal_notes,
                owner_id,
                status_id,
                mill,
                system,
                unitweight_measured,
                unitweight_weighed,
                current_cost,
                pl,
                load_ready,
                is_from_order,
                order_id,
                invoice_id,
                is_available,
                is_virtual,
                is_deleted,
                is_conflicted,
                is_locked,
                tech_action,
                tech_object_alias,
                tech_object_id,
                tech_data,
                created_at,
                created_by,
                modified_at,
                modified_by            
            )
            SELECT
                param_guid,
                param_alias,
                param_position_id,
                product_id,
                biz_id,
                param_stockholder_id,
                location_id,
                dimension_unit,
                weight_unit,
                currency,
                0,
                '',
                steelgrade_id,
                thickness,
                thickness_mm,
                0,
                param_width,
                param_width_mm,
                0,
                0,
                param_length,
                param_length_mm,
                0,
                0,
                param_unitweight,
                param_unitweight_ton,
                price,
                price * param_unitweight,
                supplier_id,
                supplier_invoice_id,
                purchase_price,
                purchase_price * param_unitweight,
                purchase_currency,
                in_ddt_id,
                in_ddt_number,
                in_ddt_date,
                in_ddt_company_id,
                ddt_number,
                ddt_date,
                ddt_company_id,
                deliverytime_id,
                param_notes,
                param_notes,
                owner_id,
                status_id,
                mill,
                system,
                param_unitweight,
                param_unitweight,
                current_cost,
                pl,
                load_ready,
                is_from_order,
                0,
                invoice_id,
                1,
                0,
                0,
                0,
                0,
                '',
                '',
                0,
                '',
                NOW(),
                param_user_id,
                NOW(),
                param_user_id
            FROM steelitems
            WHERE id = param_item_id;

            SET var_item_id = (SELECT MAX(id) FROM steelitems WHERE created_by = param_user_id);
    
        END IF;


        INSERT INTO steelitem_properties(
            item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            var_item_id,
            heat_lot,
            c,
            si,
            mn,
            p,
            s,
            cr,
            ni,
            cu,
            al,
            mo,
            nb,
            v,
            n,
            ti,
            sn,
            b,
            ceq,
            tensile_sample_direction,
            tensile_strength,
            yeild_point,
            elongation,
            reduction_of_area,
            test_temp,
            impact_strength,
            hardness,
            ust,
            sample_direction,
            stress_relieving_temp,
            heating_rate_per_hour,
            holding_time,
            cooling_down_rate,
            `condition`,
            normalizing_temp,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id
        FROM steelitem_properties
        WHERE item_id = param_item_id;


        SELECT 
            in_ddt_number,
            in_ddt_date,
            in_ddt_company_id,
            ddt_number,
            ddt_date,
            ddt_company_id,
            stockholder_id,
            status_id,
            owner_id
        INTO
            var_in_ddt_number,
            var_in_ddt_date,
            var_in_ddt_company_id,
            var_ddt_number,
            var_ddt_date,
            var_ddt_company_id,
            var_stockholder_id,
            var_status_id,
            var_owner_id            
        FROM steelitems
        WHERE id = var_item_id;


        CALL sp_steelitem_timeline_save(param_user_id, var_item_id, '', 0, var_in_ddt_number, var_in_ddt_date, var_in_ddt_company_id,
	                                    var_ddt_number, var_ddt_date, var_ddt_company_id, var_stockholder_id, var_status_id, var_owner_id);

    COMMIT;


    SELECT 
        var_item_id         AS item_id,
        param_position_id   AS position_id;

    
    DROP TEMPORARY TABLE IF EXISTS tmp_items;   

END
$$


DROP PROCEDURE IF EXISTS sp_steelitem_timeline_save$$
CREATE PROCEDURE sp_steelitem_timeline_save(
	param_user_id INT,
	param_steelitem_id INT,
	param_object_alias VARCHAR(20),
	param_object_id INT,
	param_in_ddt_number VARCHAR(50),
	param_in_ddt_date TIMESTAMP,
	param_in_ddt_company_id INT,
	param_ddt_number VARCHAR(50),
	param_ddt_date TIMESTAMP,
	param_ddt_company_id INT,
	param_stockholder_id INT,
    param_status_id TINYINT,
    param_owner_id INT
)
sp:
BEGIN

    DECLARE var_stockholder_id  INT DEFAULT 0;
    DECLARE var_id              INT DEFAULT 0;

    SET var_id = IFNULL((
        SELECT 
            id 
        FROM steelitem_timeline 
        WHERE steelitem_id = param_steelitem_id 
        AND object_alias = param_object_alias 
        AND object_id = param_object_id
    ), 0);

	IF TRIM(param_object_alias) != '' AND var_id > 0
	THEN

		UPDATE steelitem_timeline
		SET
			in_ddt_number		= param_in_ddt_number,
			in_ddt_date			= param_in_ddt_date,
			in_ddt_company_id	= param_in_ddt_company_id,
			ddt_number			= param_ddt_number,
			ddt_date			= param_ddt_date,
			ddt_company_id		= param_ddt_company_id,
			stockholder_id		= param_stockholder_id,
			status_id		    = param_status_id,
            owner_id		    = param_owner_id,
			modified_at			= NOW(),
			modified_by			= param_user_id
		WHERE id = var_id;

        UPDATE steelitem_timeline
        SET
            prev_stockholder_id = param_stockholder_id
        WHERE steelitem_id = param_steelitem_id
        AND id > var_id
        ORDER BY id DESC
        LIMIT 1;

	ELSE

        SET var_stockholder_id = IFNULL((
            SELECT 
                stockholder_id
            FROM steelitem_timeline
            WHERE steelitem_id = param_steelitem_id
            ORDER BY id DESC 
            LIMIT 1
        ), 0);

		INSERT INTO steelitem_timeline
		SET
			steelitem_id		= param_steelitem_id,
			object_alias		= param_object_alias,
			object_id			= param_object_id,
			in_ddt_number		= param_in_ddt_number,
			in_ddt_date			= param_in_ddt_date,
			in_ddt_company_id	= param_in_ddt_company_id,
			ddt_number			= param_ddt_number,
			ddt_date			= param_ddt_date,
			ddt_company_id		= param_ddt_company_id,
            prev_stockholder_id = var_stockholder_id,
			stockholder_id		= param_stockholder_id,
            status_id		    = param_status_id,
            owner_id		    = param_owner_id,
			created_at			= NOW(),
			created_by			= param_user_id,
			modified_at			= NOW(),
			modified_by			= param_user_id
		;

	END IF;

END
$$

DROP PROCEDURE IF EXISTS sp_steelitem_timeline_remove$$
CREATE PROCEDURE sp_steelitem_timeline_remove(
	IN param_user_id INT,
	IN param_steelitem_id INT,
	IN param_object_alias VARCHAR(20),
	IN param_object_id INT
)
sp:
BEGIN

    DECLARE var_min_id          INT DEFAULT 0;
    DECLARE var_max_id          INT DEFAULT 0;
    DECLARE var_stockholder_id  INT DEFAULT 0;


    SET var_min_id = IFNULL((
        SELECT 
            MIN(id) 
        FROM steelitem_timeline 
        WHERE steelitem_id = param_steelitem_id 
        AND object_alias = param_object_alias 
        AND object_id = param_object_id
    ), 0);

    SET var_max_id = IFNULL((
        SELECT 
            MAX(id) 
        FROM steelitem_timeline 
        WHERE steelitem_id = param_steelitem_id 
        AND object_alias = param_object_alias 
        AND object_id = param_object_id
    ), 0);


    IF var_min_id > 0 AND var_max_id > 0
    THEN
        
        DELETE FROM steelitem_timeline
        WHERE steelitem_id = param_steelitem_id 
        AND object_alias = param_object_alias 
        AND object_id = param_object_id;


        SET var_stockholder_id = IFNULL((
            SELECT
                stockholder_id
            FROM steelitem_timeline
            WHERE steelitem_id = param_steelitem_id 
            AND id < var_min_id
            ORDER BY id DESC 
            LIMIT 1
        ), 0);

        UPDATE steelitem_timeline
        SET
            prev_stockholder_id = param_steelitem_id
        WHERE steelitem_id = param_steelitem_id 
        AND id > var_max_id
        ORDER BY id ASC 
        LIMIT 1;

    END IF;
    
END
$$

DELIMITER ;
