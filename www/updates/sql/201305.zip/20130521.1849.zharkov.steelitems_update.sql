
UPDATE steelitems
SET
    nominal_thickness_mm    = thickness,
    nominal_width_mm        = width,
    nominal_length_mm       = `length`
WHERE dimension_unit = 'mm'
AND (SELECT dimension_unit FROM steelpositions WHERE id = steelitems.steelposition_id) = 'in';


UPDATE steelitems
SET
    thickness       = (SELECT thickness FROM steelpositions WHERE id = steelitems.steelposition_id),
    width           = (SELECT width FROM steelpositions WHERE id = steelitems.steelposition_id),
    `length`        = (SELECT `length` FROM steelpositions WHERE id = steelitems.steelposition_id),
    dimension_unit  = (SELECT dimension_unit FROM steelpositions WHERE id = steelitems.steelposition_id),
    weight_unit     = (SELECT weight_unit FROM steelpositions WHERE id = steelitems.steelposition_id),
    currency        = (SELECT currency FROM steelpositions WHERE id = steelitems.steelposition_id),
    unitweight      = (SELECT unitweight FROM steelpositions WHERE id = steelitems.steelposition_id),
    price           = (SELECT price FROM steelpositions WHERE id = steelitems.steelposition_id),
    `value`         = (SELECT `value` FROM steelpositions WHERE id = steelitems.steelposition_id)
WHERE dimension_unit = 'mm'
AND (SELECT dimension_unit FROM steelpositions WHERE id = steelitems.steelposition_id) = 'in';
