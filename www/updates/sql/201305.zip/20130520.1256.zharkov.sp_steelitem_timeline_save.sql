-- ������ ������������ Devart dbForge Studio for MySQL, ������ 5.0.97.1
-- �������� �������� ��������: http://www.devart.com/ru/dbforge/mysql/studio
-- ���� �������: 20/05/2013 10:55:51
-- ������ �������: 5.5.27
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelitem_timeline_save$$
CREATE PROCEDURE sp_steelitem_timeline_save(
	param_user_id INT,
	param_steelitem_id INT,
	param_object_alias VARCHAR(20),
	param_object_id INT,
	param_in_ddt_number VARCHAR(50),
	param_in_ddt_date TIMESTAMP,
	param_in_ddt_company_id INT,
	param_ddt_number VARCHAR(50),
	param_ddt_date TIMESTAMP,
	param_ddt_company_id INT,
	param_stockholder_id INT,
    param_status_id TINYINT,
    param_owner_id INT
)
sp:
BEGIN

    DECLARE var_stockholder_id  INT DEFAULT 0;
    DECLARE var_id              INT DEFAULT 0;
    DECLARE var_proceed_insert  BOOLEAN DEFAULT TRUE;

    
    IF TRIM(param_object_alias) != '' AND EXISTS (SELECT * FROM steelitem_timeline WHERE steelitem_id = param_steelitem_id AND object_alias = param_object_alias AND object_id = param_object_id)
    THEN
        SET var_proceed_insert = FALSE;
    END IF;

    
    IF var_proceed_insert
    THEN

        SET var_stockholder_id = IFNULL((
            SELECT 
                stockholder_id
            FROM steelitem_timeline
            WHERE steelitem_id = param_steelitem_id
            ORDER BY id DESC 
            LIMIT 1
        ), 0);

		INSERT INTO steelitem_timeline
		SET
			steelitem_id		= param_steelitem_id,
			object_alias		= param_object_alias,
			object_id			= param_object_id,
			in_ddt_number		= param_in_ddt_number,
			in_ddt_date			= param_in_ddt_date,
			in_ddt_company_id	= param_in_ddt_company_id,
			ddt_number			= param_ddt_number,
			ddt_date			= param_ddt_date,
			ddt_company_id		= param_ddt_company_id,
            prev_stockholder_id = var_stockholder_id,
			stockholder_id		= param_stockholder_id,
            status_id		    = param_status_id,
            owner_id		    = param_owner_id,
			created_at			= NOW(),
			created_by			= param_user_id,
			modified_at			= NOW(),
			modified_by			= param_user_id
		;

    ELSE

        SET var_id = IFNULL((
            SELECT 
                id
            FROM steelitem_timeline 
            WHERE steelitem_id = param_steelitem_id 
            AND object_alias = param_object_alias 
            AND object_id = param_object_id
        ), 0);

		UPDATE steelitem_timeline
		SET
			in_ddt_number		= param_in_ddt_number,
			in_ddt_date			= param_in_ddt_date,
			in_ddt_company_id	= param_in_ddt_company_id,
			ddt_number			= param_ddt_number,
			ddt_date			= param_ddt_date,
			ddt_company_id		= param_ddt_company_id,
			stockholder_id		= param_stockholder_id,
			status_id		    = param_status_id,
            owner_id		    = param_owner_id,
			modified_at			= NOW(),
			modified_by			= param_user_id
		WHERE id = var_id;

        UPDATE steelitem_timeline
        SET
            prev_stockholder_id = param_stockholder_id
        WHERE steelitem_id = param_steelitem_id
        AND id > var_id
        ORDER BY id DESC
        LIMIT 1;

    END IF;

END
$$

DELIMITER ;
