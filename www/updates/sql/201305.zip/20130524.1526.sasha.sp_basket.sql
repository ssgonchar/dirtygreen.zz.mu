delimiter $$

DROP PROCEDURE IF EXISTS `sp_basket_proceed_order`$$
CREATE PROCEDURE `sp_basket_proceed_order`(param_user_id INT, param_basket_id INT, param_biz_id INT)
BEGIN

  
    DECLARE var_stock_id            INT DEFAULT 0;

    DECLARE var_company_id          INT DEFAULT 0;
    DECLARE var_person_id           INT DEFAULT 0;
    
    DECLARE var_invoicingtype_id    INT DEFAULT 0;
    DECLARE var_paymenttype_id      INT DEFAULT 0;
    DECLARE var_order_for           CHAR(5) DEFAULT '';
    DECLARE var_dimension_unit      CHAR(5) DEFAULT '';
    DECLARE var_weight_unit         CHAR(5) DEFAULT '';
    DECLARE var_currency            CHAR(3) DEFAULT '';

    SET var_stock_id    = (SELECT stock_id FROM baskets WHERE id = param_basket_id);
    SET var_person_id   = IFNULL((SELECT person_id FROM users WHERE id = param_user_id), 0);
    SET var_company_id  = IFNULL((SELECT company_id FROM persons WHERE id = var_person_id), 0);
    
    SELECT
        dimension_unit,
        weight_unit,
        currency,
        invoicingtype_id,
        paymenttype_id,
        order_for
    INTO
        var_dimension_unit,
        var_weight_unit,
        var_currency,
        var_invoicingtype_id,
        var_paymenttype_id,
        var_order_for
    FROM stocks
    WHERE id = var_stock_id;

    
    START TRANSACTION;

        INSERT INTO orders(
            order_for,
            number,
            biz_id,
            company_id,
            person_id,
            buyer_ref,
            delivery_point,
            delivery_town,
            delivery_date,
            invoicingtype_id,
            paymenttype_id,
            `type`,
            stock_id,
            `status`,
            dimension_unit,
            weight_unit,
            currency,
            description,
            created_at,
            created_by,
            modified_at,
            modified_by
        )
        SELECT
            var_order_for,
            0,
            param_biz_id,
            var_company_id,
            var_person_id,
            buyer_ref,
            delivery_point,
            delivery_town,
            delivery_date,
            var_invoicingtype_id,
            var_paymenttype_id,
            'so',
            var_stock_id,
            'nw',
            var_dimension_unit,
            var_weight_unit,
            var_currency,
            description,
            NOW(),
            param_user_id,
            NOW(),
            param_user_id        
        FROM baskets
        WHERE id = param_basket_id;
    
        SELECT MAX(id) AS order_id FROM orders WHERE created_by = param_user_id;
    
   COMMIT; 

END$$

DROP PROCEDURE IF EXISTS `sp_biz_get_last_for_company`$$
CREATE PROCEDURE `sp_biz_get_last_for_company`(IN param_user_id INT, 
                                                                          IN param_company_id INT, 
                                                                          IN param_role CHAR(20))
BEGIN

    SELECT
        MAX(bizes.id) AS biz_id
    FROM bizes
    JOIN biz_companies ON biz_companies.biz_id = bizes.id
    WHERE biz_companies.company_id = param_company_id
    AND biz_companies.role = param_role;
	
END$$

delimiter ;


