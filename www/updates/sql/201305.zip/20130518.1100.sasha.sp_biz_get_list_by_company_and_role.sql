delimiter $$

DROP PROCEDURE IF EXISTS `sp_biz_get_list_by_company_and_role`$$
CREATE PROCEDURE `sp_biz_get_list_by_company_and_role`(param_company_id INT, param_role CHAR(20))
BEGIN
    DECLARE var_role_undef CHAR DEFAULT '0';

    IF param_role = var_role_undef
    THEN
        SELECT DISTINCT biz_id 
        FROM biz_companies
        WHERE company_id = param_company_id;
    ELSE
        SELECT biz_id 
        FROM biz_companies
        WHERE company_id = param_company_id
        AND role = param_role;
    END IF;
    
END$$

delimiter ;
