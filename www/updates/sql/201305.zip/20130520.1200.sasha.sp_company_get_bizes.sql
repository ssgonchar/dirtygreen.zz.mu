DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_company_get_bizes` $$
CREATE PROCEDURE `sp_company_get_bizes`(param_company_id INT)
BEGIN

    SELECT
        biz_companies.biz_id,
        GROUP_CONCAT(biz_companies.role SEPARATOR ", ") AS role
    FROM biz_companies
    JOIN bizes ON biz_companies.biz_id = bizes.id
    WHERE company_id = param_company_id
    GROUP BY biz_id
    ORDER BY modified_at DESC
    LIMIT 10;


    SELECT 
        COUNT(distinct biz_id) AS `count`
    FROM biz_companies
    JOIN bizes ON biz_companies.biz_id = bizes.id
    WHERE company_id = param_company_id;

END$$

DELIMITER ;
