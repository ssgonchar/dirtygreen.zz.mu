delimiter $$

DROP PROCEDURE IF EXISTS `sp_product_get_list_from_bizes`$$
CREATE PROCEDURE `sp_product_get_list_from_bizes`(param_team_id INT, param_parent_id INT)
BEGIN
    SELECT
        DISTINCT bizes.product_id AS product_id
    FROM products
    INNER JOIN bizes ON products.id = bizes.product_id 
    WHERE (products.team_id = param_team_id OR param_team_id = 0)
    AND (products.parent_id = param_parent_id OR param_parent_id = -1)
    AND products.is_deleted = 0
    ORDER BY products.title;
END$$

DROP PROCEDURE IF EXISTS `sp_biz_get_list_by_company_and_role`$$
CREATE PROCEDURE `sp_biz_get_list_by_company_and_role`(param_company_id INT, param_role CHAR(20))
BEGIN
    DECLARE var_role_undef CHAR DEFAULT '0';

    IF param_role = var_role_undef
    THEN
        SELECT DISTINCT biz_id 
        FROM biz_companies
        WHERE company_id = param_company_id;
    ELSE
        SELECT biz_id 
        FROM biz_companies
        WHERE company_id = param_company_id
        AND role = param_role;
    END IF;
    
END$$

DROP PROCEDURE IF EXISTS `sp_biz_get_data_from_bizes`$$
CREATE PROCEDURE `sp_biz_get_data_from_bizes`()
BEGIN

    SET SESSION group_concat_max_len = 65535;
    
    SELECT 
        (SELECT GROUP_CONCAT(DISTINCT objective_id)
        FROM bizes 
        WHERE objective_id > 0) AS objective_ids ,
        
        (SELECT GROUP_CONCAT(DISTINCT team_id) 
        FROM bizes 
        WHERE team_id > 0) AS team_ids,
        
        (SELECT GROUP_CONCAT(DISTINCT status) 
        FROM bizes 
        WHERE status != '') AS status_list,

        (SELECT GROUP_CONCAT(DISTINCT market_id) 
        FROM bizes 
        WHERE market_id > 0) AS market_ids,
        
        (SELECT GROUP_CONCAT(DISTINCT biz_users.user_id ORDER BY users.is_mam DESC, users.login) 
        FROM biz_users
        INNER JOIN users ON biz_users.user_id = users.id
        WHERE biz_users.user_id > 0 ) AS user_ids;

END$$

delimiter ;
