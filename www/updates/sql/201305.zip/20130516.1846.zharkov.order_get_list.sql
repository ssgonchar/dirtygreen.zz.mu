-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.50.303.1
-- ����: 16.05.2013 18:46:38
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_order_get_list$$
CREATE PROCEDURE sp_order_get_list(param_user_id INT, param_order_for CHAR(5), param_biz_id INT, param_company_id INT, 
                                   param_period_from TIMESTAMP, param_period_to TIMESTAMP, param_status CHAR(2), 
                                   param_steelgrade_id INT, param_thickness_from DECIMAL(10,4), 
                                   param_thickness_to DECIMAL(10,4), param_width_from DECIMAL(10,4), 
                                   param_width_to DECIMAL(10,4), param_keyword VARCHAR(100), param_type CHAR(2), 
                                   param_from INT, param_count INT)
sp:
BEGIN

    DECLARE var_where       VARCHAR(4000) DEFAULT '';
    DECLARE var_prefix      VARCHAR(100) DEFAULT '';
    DECLARE var_order_ids   VARCHAR(4000) DEFAULT '';
    

    IF param_steelgrade_id > 0 OR param_thickness_from > 0 OR param_thickness_to > 0 OR param_width_from > 0 OR param_width_to > 0
    THEN

        SET var_where = '';
        
        IF param_steelgrade_id > 0
        THEN 
            SET var_where = CONCAT(var_where, "steelgrade_id = ", param_steelgrade_id); 
        END IF;


        IF param_thickness_from > 0 OR param_thickness_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");
            
            IF param_thickness_from > 0 AND param_thickness_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(thickness_mm >= ", param_thickness_from, " AND thickness_mm <= ", param_thickness_to, ")"); 
            ELSEIF param_thickness_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm >= ", param_thickness_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "thickness_mm <= ", param_thickness_to); 
            END IF;
                    
        END IF;
        
        IF param_width_from > 0 OR param_width_to > 0
        THEN 
            
            SET var_prefix = IF(var_where = "", "", " AND ");

            IF param_width_from > 0 AND param_width_to > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "(width_mm >= ", param_width_from, " AND width_mm <= ", param_width_to, ")"); 
            ELSEIF param_width_from > 0
            THEN
                SET var_where = CONCAT(var_where, var_prefix, "width_mm >= ", param_width_from); 
            ELSE
                SET var_where = CONCAT(var_where, var_prefix, "width_mm <= ", param_width_to); 
            END IF;
                    
        END IF;
    
    
        DROP TEMPORARY TABLE IF EXISTS t_orders;
        CREATE TEMPORARY TABLE t_orders(id INT);

        SET @var_stmt := CONCAT("   
            INSERT INTO t_orders(id)
            SELECT DISTINCT 
                order_id
            FROM order_positions 
        ", IF(var_where = "", "", " WHERE "), var_where);

        PREPARE stmt FROM @var_stmt;
        EXECUTE stmt;
        
        SET var_order_ids = IFNULL((SELECT GROUP_CONCAT(id SEPARATOR ",") FROM t_orders), '');

    END IF;

    
    SET var_where = '';
    
    
    IF TRIM(param_order_for) != ''
    THEN        
        SET var_where = CONCAT("o.order_for = '", param_order_for, "'");
    END IF;
    
    IF param_biz_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.biz_id = ", param_biz_id);
    END IF;

    IF param_company_id > 0
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.company_id = ", param_company_id);
    END IF;

    IF TRIM(param_order_for) = '' AND param_biz_id = 0 AND param_company_id = 0 AND year(param_period_from) <= 1900
        AND year(param_period_to) <= 1900 AND TRIM(param_status) = '' AND param_steelgrade_id = 0 AND param_thickness_from = 0
        AND param_thickness_to = 0 AND param_width_from = 0 AND param_width_to = 0 AND TRIM(param_keyword) = '' AND TRIM(param_type) = ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status IN ('nw', 'ip', 'de')");
    ELSEIF TRIM(param_status) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.status = '", param_status, "'");        
    END IF;

    IF TRIM(param_type) != ''
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.type = '", param_type, "'");
    END IF;

    IF year(param_period_from) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at >= '", param_period_from, "'");
    END IF;

    IF year(param_period_to) > 1900
    THEN
        SET var_prefix  = IF(var_where = "", "", " AND ");
        SET var_where   = CONCAT(var_where, var_prefix, "o.created_at <= '", param_period_to, "'");

    END IF;

    IF TRIM(param_keyword) != ''
    THEN
        SET param_keyword   = CONCAT('%', param_keyword, '%');
        SET var_prefix      = IF(var_where = "", "", " AND ");
        SET var_where       = CONCAT(var_where, var_prefix, "(o.buyer_ref LIKE '", param_keyword, "' OR o.supplier_ref LIKE '", param_keyword, "' OR o.description LIKE '", param_keyword, "')");
    END IF;
    
    SET @stmt_from  = param_from;
    SET @stmt_count = param_count;    
    SET @var_stmt   = CONCAT("
        SELECT
            o.id AS order_id,
            CASE status 
            WHEN 'nw' THEN 1 
            WHEN 'ip' THEN 2 
            WHEN 'de' THEN 3 
            WHEN 'co' THEN 4 
            WHEN 'ca' THEN 5
            ELSE 10 END AS status_id 
        FROM orders AS o ", 
        IF(TRIM(var_order_ids) = '', "", " JOIN t_orders USING (id)"), 
        IF(var_where = "", "", " WHERE "), var_where, 
        " ORDER BY status_id, created_at DESC LIMIT ?, ?;");

    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt USING @stmt_from, @stmt_count;


    SET @var_stmt   = CONCAT("
        SELECT
            COUNT(*) AS rows
        FROM orders AS o ", 
        IF(TRIM(var_order_ids) = '', "", " JOIN t_orders USING (id)"), 
        IF(var_where = "", "", " WHERE "), var_where, ";");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;

END
$$

DELIMITER ;
