DROP TABLE IF EXISTS `message_delivered_temp`;

CREATE TABLE message_delivered_temp LIKE message_delivered;
INSERT INTO message_delivered_temp SELECT * FROM message_delivered;

DROP TABLE IF EXISTS `message_delivered`;
CREATE TABLE IF NOT EXISTS `message_delivered` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `done_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix-message-user` (`message_id`,`user_id`) ,
  KEY `ix-message-done` (`message_id`,`done_at`)  
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=2730 AUTO_INCREMENT=1 ;

INSERT IGNORE INTO message_delivered
SELECT * FROM message_delivered_temp;