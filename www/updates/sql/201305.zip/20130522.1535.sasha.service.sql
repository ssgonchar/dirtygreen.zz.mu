ALTER TABLE `service` ADD COLUMN `old_attachment_id` INT(11) NULL DEFAULT NULL  AFTER `bizblog_message_id` ;

delimiter $$

DROP PROCEDURE IF EXISTS `sp_service_get_data`$$

delimiter ;
