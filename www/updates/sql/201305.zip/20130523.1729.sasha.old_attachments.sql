UPDATE service
SET 
	old_attachment_id 	= (SELECT MAX(id) FROM old_attachments) + 1,
	bizblog_message_id	= (SELECT MAX(id) FROM messages) + 1
WHERE id = 1;
