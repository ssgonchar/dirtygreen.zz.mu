-- ������ ������������ Devart dbForge Studio for MySQL, ������ 5.0.97.1
-- �������� �������� ��������: http://www.devart.com/ru/dbforge/mysql/studio
-- ���� �������: 20/05/2013 13:25:37
-- ������ �������: 5.5.27
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_steelposition_save$$
CREATE PROCEDURE sp_steelposition_save(param_user_id INT, param_id INT, param_stock_id INT, param_product_id INT, param_biz_id INT, 
                                param_dimension_unit CHAR(10), param_weight_unit CHAR(10), param_currency CHAR(3),
                                param_steelgrade_id INT, param_thickness CHAR(10), param_thickness_mm DECIMAL(10,4), 
                                param_width CHAR(10), param_width_mm DECIMAL(10,4), 
                                param_length CHAR(10), param_length_mm DECIMAL(10,4), 
                                param_unitweight CHAR(10), param_unitweight_ton DECIMAL(10,4), 
                                param_qtty INT, 
                                param_weight CHAR(10), param_weight_ton DECIMAL(10,4), 
                                param_price DECIMAL(10,4), param_value DECIMAL(10,4), 
                                param_deliverytime_id INT, 
                                param_notes VARCHAR(250), param_internal_notes VARCHAR(250))
sp:
BEGIN

    DECLARE var_qtty INT DEFAULT 0;
    
    IF param_id > 0
    THEN
        
        IF NOT EXISTS (SELECT * FROM steelpositions WHERE id = param_id)
        THEN 
            SELECT -1 as ErrorCode, 'sp_steelposition_save' AS ErrorAt;
            LEAVE sp;
        END IF;

        
        SET var_qtty    = sf_steelposition_get_qtty(param_id);
        SET param_value = param_price * param_unitweight * var_qtty;

        IF var_qtty = 0 
        THEN

            CALL sp_steelposition_remove(param_user_id, param_id);
            LEAVE sp;

        END IF;

        
        UPDATE steelpositions
        SET
            biz_id              = CASE WHEN param_biz_id = 0 THEN biz_id ELSE param_biz_id END,
            steelgrade_id       = param_steelgrade_id,
            thickness           = param_thickness,
            thickness_mm        = param_thickness_mm,
            width               = param_width,
            width_mm            = param_width_mm,
            `length`            = param_length,
            length_mm           = param_length_mm,
            unitweight          = param_unitweight,
            unitweight_ton      = param_unitweight_ton,
            weight              = param_unitweight * var_qtty, 
            weight_ton          = param_unitweight_ton * var_qtty, 
            price               = param_price,
            `value`             = param_value,
            deliverytime_id     = param_deliverytime_id,
            notes               = param_notes,
            internal_notes      = param_internal_notes,
            qtty                = var_qtty,
            modified_at         = NOW(),
            modified_by         = param_user_id
        WHERE id = param_id;

        
        UPDATE steelitems
        SET
            price   = param_price,
            `value` = param_value
        WHERE steelposition_id = param_id;
    
    ELSE

        START TRANSACTION;

            INSERT INTO steelpositions
            SET
                stock_id        = param_stock_id,
                product_id      = param_product_id,
                biz_id          = param_biz_id,
                dimension_unit  = param_dimension_unit,
                weight_unit     = param_weight_unit,
                currency        = param_currency,
                steelgrade_id   = param_steelgrade_id,
                thickness       = param_thickness,
                thickness_mm    = param_thickness_mm,
                width           = param_width,
                width_mm        = param_width_mm,
                length          = param_length,
                length_mm       = param_length_mm,
                unitweight      = param_unitweight,
                unitweight_ton  = param_unitweight_ton,
                qtty            = param_qtty,
                weight          = param_weight,
                weight_ton      = param_weight_ton,
                price           = param_price,
                `value`         = param_value,
                deliverytime_id = param_deliverytime_id,
                notes           = param_notes,
                internal_notes  = param_internal_notes,
                is_from_order   = IF(param_stock_id > 0, 0, 1),
                is_deleted      = 0,
                is_reserved     = 0,
                is_locked       = 0,
                tech_action     = '',
                created_at      = NOW(),
                created_by      = param_user_id,
                modified_at     = NOW(),
                modified_by     = param_user_id;
    
            SET param_id = (SELECT MAX(id) FROM steelpositions WHERE created_by = param_user_id);

        COMMIT;    

    END IF;


    SELECT param_id AS id;

END
$$

DELIMITER ;
