delimiter $$

DROP PROCEDURE IF EXISTS `sp_company_remove_prices` $$
CREATE PROCEDURE `sp_company_remove_prices`(IN param_id INT)
BEGIN
    DECLARE var_company_id INT DEFAULT 0;
    DECLARE var_date TIMESTAMP DEFAULT 0;
    
    SET var_company_id = (SELECT company_id FROM company_prices WHERE id = param_id);

    IF var_company_id > 0
    THEN
        START TRANSACTION;

        DELETE FROM company_prices WHERE id = param_id;
        
        SET var_date = (SELECT MAX(date) FROM company_prices WHERE company_id = var_company_id);

        INSERT INTO companies (id, handling_cost, storage_cost, currency)
            SELECT company_id, handling_cost, storage_cost, currency 
            FROM company_prices 
            WHERE date = var_date 
            AND company_id = var_company_id
            ON DUPLICATE KEY UPDATE
            handling_cost = VALUES(handling_cost),
            storage_cost = VALUES(storage_cost),
            currency = VALUES(currency);
        
        COMMIT;

        SELECT var_company_id as company_id;
        
        IF NOT EXISTS (SELECT company_id FROM company_prices WHERE company_id = var_company_id)
        THEN
            UPDATE companies
            SET 
               handling_cost = 0,
               storage_cost = 0,
               currency = NULL
            WHERE id = var_company_id;
        END IF;
    END IF;
END$$

delimiter $$
