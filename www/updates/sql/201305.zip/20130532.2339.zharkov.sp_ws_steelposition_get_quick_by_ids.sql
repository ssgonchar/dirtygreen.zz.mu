-- ������ ������������ Devart dbForge Studio for MySQL, ������ 4.0.224.1
-- ����: 30.05.2013 23:38:54
-- ������ �������: 5.1.41
-- ������ �������: 4.1

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_ws_steelposition_get_quick_by_ids$$
CREATE PROCEDURE sp_ws_steelposition_get_quick_by_ids(param_ids VARCHAR(1100), param_user_id INT)
sp:
BEGIN

    DECLARE var_company_id INT DEFAULT 0;

    IF param_ids = '' 
    THEN
        SELECT -1 AS ErrorCode, 'sp_steelposition_get_quick_by_ids' AS ErrorAt;
        LEAVE sp;
    END IF;


    SET var_company_id = IFNULL((SELECT company_id FROM persons JOIN users on users.person_id = persons.id WHERE users.id = param_user_id), 0);
    
    SET @var_stmt := CONCAT(  
        "SELECT 
            id,
            (SELECT SUM(qtty) FROM steelpositions_reserved WHERE steelposition_id = steelpositions.id AND company_id != ", var_company_id, ") AS reserved
        FROM steelpositions
        WHERE id IN (", param_ids, ")
        LIMIT 100;");
    
    PREPARE stmt FROM @var_stmt;
    EXECUTE stmt;    

END
$$

DELIMITER ;
