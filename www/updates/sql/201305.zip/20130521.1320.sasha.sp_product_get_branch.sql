delimiter $$

DROP PROCEDURE IF EXISTS `sp_product_get_branch`$$
CREATE PROCEDURE `sp_product_get_branch`(IN param_parent_id INT)
BEGIN
   
    DECLARE var_prev_count  INT DEFAULT 0;
    DECLARE var_count       INT DEFAULT 0;

    DROP TEMPORARY TABLE IF EXISTS tmp_ids;
    CREATE TEMPORARY TABLE tmp_ids(id INT(11), UNIQUE(id))ENGINE=MYISAM;
        
    DROP TEMPORARY TABLE IF EXISTS tmp_pids;
    CREATE TEMPORARY TABLE tmp_pids(id INT(11), UNIQUE(id))ENGINE=MYISAM;
        
    SET var_prev_count  := 0;
    SET var_count       := 1;
        
    INSERT INTO tmp_ids SELECT param_parent_id;
        
    WHILE var_prev_count != var_count 
        DO
            SET var_prev_count := var_count;
            
            INSERT IGNORE INTO tmp_pids
            SELECT id FROM tmp_ids;
            
            INSERT IGNORE INTO tmp_ids
            SELECT
                p.id
            FROM products p 
            INNER JOIN tmp_pids ON tmp_pids.id = p.parent_id;
            
            SET var_count := (SELECT COUNT(*) FROM tmp_ids);
        
     END WHILE;

     SELECT 
        id AS product_id 
     FROM tmp_ids;        
        
     DROP TEMPORARY TABLE IF EXISTS tmp_ids;
     DROP TEMPORARY TABLE IF EXISTS tmp_pids;
END$$

delimiter ;
