ALTER TABLE `users` ADD `last_email_number` INT NOT NULL ;
ALTER TABLE `sc` CHANGE `delivery_point` `delivery_point` VARCHAR( 1000 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_user_save$$
CREATE PROCEDURE sp_user_save(param_user_id INT, param_id INT, param_login VARCHAR(20), param_nickname VARCHAR(2), param_password VARCHAR(32),
                                param_email VARCHAR(250), param_role_id TINYINT, param_status_id TINYINT, param_person_id INT, 
                                param_color VARCHAR(20), param_is_mam TINYINT, param_se_access TINYINT, param_pa_access TINYINT,
                                param_chat_icon_park TINYINT, param_last_email_number INT)
sp: 
BEGIN

    DECLARE var_last_email_number INT DEFAULT 0;

    SET var_last_email_number = IFNULL((SELECT MAX(number) FROM emails WHERE created_by = param_id), 0);
    
    IF param_id > 0
    THEN

        UPDATE users
        SET
            login               = param_login,
            nickname            = param_nickname,
            `password`          = param_password,
            email               = param_email,
            role_id             = param_role_id,
            status_id           = param_status_id,
            person_id           = param_person_id,
            color               = param_color,
            is_mam              = param_is_mam,
            se_access           = param_se_access,
            pa_access           = param_pa_access,
            chat_icon_park      = param_chat_icon_park,
            modified_at         = NOW(),
            modified_by         = param_user_id,
            last_email_number   = GREATEST(var_last_email_number, param_last_email_number)
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO users
            SET
                login               = param_login,
                nickname            = param_nickname,
                `password`          = param_password,
                email               = param_email,
                role_id             = param_role_id,
                status_id           = param_status_id,
                person_id           = param_person_id,
                color               = param_color,
                is_mam              = param_is_mam,
                se_access           = param_se_access,
                pa_access           = param_pa_access,
                chat_icon_park      = param_chat_icon_park,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id,
                last_email_number   = GREATEST(var_last_email_number, param_last_email_number)
            ;

            SET param_id = (SELECT MAX(id) FROM users WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;

END
$$


DROP PROCEDURE IF EXISTS sp_email_get_last$$
CREATE PROCEDURE sp_email_get_last(param_user_id INT)
BEGIN

    SELECT 
        *,
        (SELECT last_email_number FROM users WHERE id = param_user_id) AS last_email_number
    FROM emails 
    WHERE created_by = param_user_id
    ORDER BY id DESC
    LIMIT 1;

END
$$

DROP PROCEDURE IF EXISTS sp_email_save$$
CREATE PROCEDURE sp_email_save(
	IN param_user_id INT,
	IN param_id INT,
	IN param_object_alias CHAR(20),
	IN param_object_id INT,
	IN param_sender_address VARCHAR(250),
	IN param_recipient_address VARCHAR(1000),
	IN param_cc_address VARCHAR(1000), 
	IN param_to VARCHAR(250),
	IN param_attention VARCHAR(250),
	IN param_subject VARCHAR(250),
	IN param_our_ref VARCHAR(250),
	IN param_your_ref VARCHAR(250),
	IN param_title VARCHAR(1000), 
	IN param_description TEXT,
	IN param_signature VARCHAR(250),
	IN param_approve_by INT(11),
	IN param_approve_deadline TIMESTAMP,
	IN param_doc_type TINYINT(4),
	IN param_seek_response TIMESTAMP,
    param_mailbox_id INT,
    param_parent_id INT,
    param_signature2 VARCHAR(250),
    param_signature3 VARCHAR(50)
)
BEGIN

    DECLARE var_number          INT DEFAULT 0;
    DECLARE EMAIL_TYPE_DRAFT    INT DEFAULT 3;

    IF param_id > 0
    THEN
        
        UPDATE emails
        SET
            sender_address      = param_sender_address,
            recipient_address   = param_recipient_address,
            cc_address          = param_cc_address,
            `to`                = param_to,
            attention           = param_attention,
            `subject`           = param_subject,
            our_ref             = param_our_ref,
            your_ref            = param_your_ref,
            title               = param_title,
            description         = param_description,
            signature           = param_signature,
            signature2          = param_signature2,
            modified_at         = NOW(),
            modified_by         = param_user_id,
            date_mail           = NOW(),
			approve_by			= param_approve_by,
			approve_deadline	= param_approve_deadline,
			doc_type			= param_doc_type,
			seek_response		= param_seek_response,
            signature3          = param_signature3
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            SET var_number = IFNULL((SELECT last_email_number FROM users WHERE id = param_user_id), 0) + 1;
            
            INSERT INTO emails
            SET                
                email_raw_id        = 0,
                type_id             = EMAIL_TYPE_DRAFT,
                object_alias        = param_object_alias,
                object_id           = param_object_id,
                sender_address      = param_sender_address,
                recipient_address   = param_recipient_address,
                cc_address          = param_cc_address,
                `to`                = param_to,
                attention           = param_attention,
                `subject`           = param_subject,
                our_ref             = param_our_ref,
                your_ref            = param_your_ref,
                title               = param_title,
                description         = param_description,
                signature           = param_signature,
                signature2          = param_signature2,
                number              = var_number,
                created_at          = NOW(),
                created_by          = param_user_id,
                modified_at         = NOW(),
                modified_by         = param_user_id,
                date_mail           = NOW(),
				approve_by			= param_approve_by,
				approve_deadline	= param_approve_deadline,
				doc_type			= param_doc_type,
				seek_response		= param_seek_response,
                parent_id           = param_parent_id,
                signature3          = param_signature3
			;

            SET param_id = (SELECT MAX(id) FROM emails WHERE created_by = param_user_id);

            UPDATE users
            SET
                last_email_number = var_number
            WHERE id = param_user_id;

        COMMIT;

    END IF;

    
    DELETE FROM email_objects 
    WHERE email_id = param_id;

    DELETE FROM email_mailboxes
    WHERE email_id = param_id;

    INSERT INTO email_mailboxes
    SET
        email_id = param_id,
        mailbox_id  = param_mailbox_id,
        created_at  = NOW(),
        created_by  = param_user_id;

    
    SELECT param_id AS id;

END
$$


DROP PROCEDURE IF EXISTS sp_sc_save$$
CREATE PROCEDURE sp_sc_save(param_user_id INT, param_id INT, param_order_id INT, param_person_id INT, param_delivery_point VARCHAR(1000),
                            param_delivery_date VARCHAR(250), param_chemical_composition TEXT, param_tolerances TEXT, 
                            param_hydrogen_control TEXT, param_surface_quality TEXT, param_surface_condition TEXT, param_side_edges TEXT,
                            param_marking TEXT, param_packing TEXT, param_stamping TEXT, param_ust_standard TEXT, param_dunnaging_requirements TEXT,
                            param_documents_supplied TEXT, param_front_and_back_ends TEXT, param_origin TEXT, param_inspection TEXT,
                            param_delivery_form TEXT, param_reduction_of_area TEXT, param_testing TEXT, param_delivery_cost VARCHAR(250),
                            param_qctype_id INT, param_notes TEXT, param_transport_mode VARCHAR(250))
BEGIN



    IF param_id > 0
    THEN
        
        UPDATE sc
        SET
            person_id               = param_person_id,
            delivery_point          = param_delivery_point,
            delivery_date           = param_delivery_date,
            chemical_composition    = param_chemical_composition,
            tolerances              = param_tolerances,
            hydrogen_control        = param_hydrogen_control,
            surface_quality         = param_surface_quality,
            surface_condition       = param_surface_condition,
            side_edges              = param_side_edges,
            marking                 = param_marking,
            packing                 = param_packing,
            stamping                = param_stamping,
            ust_standard            = param_ust_standard,
            dunnaging_requirements  = param_dunnaging_requirements,
            documents_supplied      = param_documents_supplied,
            front_and_back_ends     = param_front_and_back_ends,
            origin                  = param_origin,
            inspection              = param_inspection,
            delivery_form           = param_delivery_form,
            reduction_of_area       = param_reduction_of_area,
            testing                 = param_testing,
            delivery_cost           = param_delivery_cost,
            qctype_id               = param_qctype_id,
            notes                   = param_notes,
            transport_mode          = param_transport_mode,
            modified_at             = NOW(),
            modified_by             = param_user_id            
        WHERE id = param_id;

    ELSE

        START TRANSACTION;

            INSERT INTO sc
            SET
                order_id                = param_order_id,
                person_id               = param_person_id,
                delivery_point          = param_delivery_point,
                delivery_date           = param_delivery_date,                
                chemical_composition    = param_chemical_composition,
                tolerances              = param_tolerances,
                hydrogen_control        = param_hydrogen_control,
                surface_quality         = param_surface_quality,
                surface_condition       = param_surface_condition,
                side_edges              = param_side_edges,
                marking                 = param_marking,
                packing                 = param_packing,
                stamping                = param_stamping,
                ust_standard            = param_ust_standard,
                dunnaging_requirements  = param_dunnaging_requirements,
                documents_supplied      = param_documents_supplied,
                front_and_back_ends     = param_front_and_back_ends,
                origin                  = param_origin,
                inspection              = param_inspection,
                delivery_form           = param_delivery_form,
                reduction_of_area       = param_reduction_of_area,
                testing                 = param_testing,
                delivery_cost           = param_delivery_cost,
                qctype_id               = param_qctype_id,
                notes                   = param_notes,
                transport_mode          = param_transport_mode,
                is_sent                 = 0,
                is_returned             = 0,
                created_at              = NOW(),
                created_by              = param_user_id,
                modified_at             = NOW(),
                modified_by             = param_user_id;           

            SET param_id = (SELECT MAX(id) FROM sc WHERE created_by = param_user_id);

        COMMIT;

    END IF;


    SELECT param_id AS id;
    
END
$$

DELIMITER ;
