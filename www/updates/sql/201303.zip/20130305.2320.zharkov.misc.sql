ALTER TABLE `albums` ADD `alias` VARCHAR( 100 ) NOT NULL AFTER `description` ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_album_get_by_alias$$
CREATE PROCEDURE sp_album_get_by_alias(param_user_id INT, param_alias VARCHAR(100))
BEGIN

    DECLARE var_album_id INT DEFAULT 0;

    SET var_album_id = IFNULL((SELECT id FROM albums WHERE alias = param_alias), 0);

    IF var_album_id = 0
    THEN
    
        START TRANSACTION;

        INSERT INTO albums
        SET
            title       = param_alias,
            description = '',
            alias       = param_alias,
            created_at  = NOW(),
            created_by  = param_user_id;

        SET var_album_id = (SELECT MAX(id) FROM albums);

        COMMIT;
    
    END IF;

    
    SELECT var_album_id AS album_id;

END
$$

DROP PROCEDURE IF EXISTS sp_attachment_get_list$$
CREATE PROCEDURE sp_attachment_get_list(param_type CHAR(5), param_object_alias VARCHAR(100), param_object_id INT, param_from INT, param_count INT)
sp:
BEGIN
	DECLARE var_where VARCHAR(1000) DEFAULT ' 1=1 ';
	DECLARE var_ids VARCHAR(1000) DEFAULT '';

	SET var_where = CONCAT(var_where, ' AND ao.object_alias = "', param_object_alias, '" '); 
	SET var_where = CONCAT(var_where, ' AND ao.object_id = ', param_object_id); 

	IF param_type != ''
	THEN
		SET var_where = CONCAT(var_where, " AND ao.type = '", param_type, "'");
	END IF;

	CASE param_object_alias
		WHEN 'ra' THEN
			SET var_ids = IFNULL((
				SELECT GROUP_CONCAT(ao.attachment_id)
				FROM attachment_objects AS ao
				LEFT JOIN cmr ON ao.object_alias = 'cmr' AND ao.object_id = cmr.id AND cmr.ra_id = param_object_id
				LEFT JOIN ddt ON ao.object_alias = 'ddt' AND ao.object_id = ddt.id AND ddt.ra_id = param_object_id
				WHERE ao.object_alias IN ('cmr', 'ddt')
				AND ao.object_id IN (cmr.id, ddt.id)
			), '');
			IF var_ids != ''
			THEN
				SET var_where = CONCAT(var_where, ' OR ao.attachment_id IN (', var_ids, ') ');
			END IF;

		ELSE SET var_where = var_where;
	END CASE;

    SET @statement = CONCAT("
		SELECT ao.attachment_id
		FROM attachment_objects AS ao
		WHERE ", var_where,
		" ORDER BY created_at DESC 
		LIMIT ?, ?;");
    

    PREPARE stmt FROM @statement;

    SET
		@stmt_from 	= param_from
		,@stmt_count	= param_count;

	EXECUTE stmt USING @stmt_from, @stmt_count;

	SET @statement = CONCAT("
		SELECT COUNT(ao.id) AS rows
		FROM attachment_objects AS ao
		WHERE ", var_where);

	PREPARE stmt FROM @statement;
	EXECUTE stmt;

END
$$

DELIMITER ;
